// ORee MVP - 메인 애플리케이션
class OReeApp {
  constructor() {
    this.currentScreen = 'login'; // 최초 진입점: 로그인/가입
    this.user = null;
    this.showOnboarding = !localStorage.getItem('onboarding_completed');
    
    // 사용자 인증 상태 관리
    this.authState = {
      isLoggedIn: false,
      isPhoneVerified: false,
      loginType: null, // 'social', 'phone', 'guest'
      socialProvider: null, // 'kakao', 'naver'
      phoneNumber: null,
      isGuest: false
    };
    
    // 전화번호 인증 관련 상태
    this.phoneAuthState = {
      phoneNumber: '',
      verificationCode: '',
      codeSent: false,
      isVerifying: false,
      timer: 0,
      timerInterval: null
    };
    
    this.currentSocialType = null; // 현재 선택된 소셜 로그인 타입
    
    // 홈 화면 상태 관리 (STEP 5)
    this.homeState = {
      viewMode: 'map', // 'map' 또는 'list'
      showNotifications: false,
      selectedPin: null,
      searchQuery: '',
      filters: {
        reservationAvailable: false,
        sortBy: 'distance' // 'distance', 'rating', 'price'
      },
      notifications: [
        {
          id: 1,
          type: 'reservation',
          title: '예약 확정 안내',
          message: '강남 프라이빗 카페 예약이 확정되었습니다.',
          time: '2분 전',
          isRead: false
        },
        {
          id: 2,
          type: 'promotion',
          title: '신규 업장 오픈',
          message: '홍대 루프탑 카페가 새로 오픈했어요!',
          time: '1시간 전',
          isRead: true
        },
        {
          id: 3,
          type: 'reservation',
          title: '예약 취소 확인',
          message: '이태원 레스토랑 예약이 취소되었습니다.',
          time: '3시간 전',
          isRead: false
        }
      ],
      stores: [
        {
          id: 1,
          name: '강남 프라이빗 카페',
          category: '카페',
          categoryType: 'restaurant',
          capacity: '20-30명',
          location: '강남구 테헤란로',
          distance: '0.8km',
          rating: 4.8,
          availableToday: true,
          image: '/static/store1.jpg',
          priceRange: '시간당 15만원',
          description: '강남 중심가 프라이빗 카페. 대형 스크린과 음향시설 완비.',
          lat: 37.5665,
          lng: 126.9780
        },
        {
          id: 2,
          name: '홍대 루프탑 바',
          category: '레스토랑',
          categoryType: 'restaurant',
          capacity: '15-25명',
          location: '마포구 홍익로',
          distance: '1.2km',
          rating: 4.6,
          availableToday: true,
          image: '/static/store2.jpg',
          priceRange: '시간당 12만원',
          description: '홍대 루프탑 뷰 맛집. 야경이 아름다운 프라이빗 공간.',
          lat: 37.5563,
          lng: 126.9236
        },
        {
          id: 3,
          name: '이태원 파티룸',
          category: '파티룸',
          categoryType: 'leisure',
          capacity: '30-50명',
          location: '용산구 이태원로',
          distance: '2.1km',
          rating: 4.9,
          availableToday: false,
          image: '/static/store3.jpg',
          priceRange: '시간당 25만원',
          description: '이태원 대형 파티룸. 노래방과 게임 시설 완비.',
          lat: 37.5346,
          lng: 126.9946
        },
        {
          id: 4,
          name: '용산 게스트하우스',
          category: '게스트하우스',
          categoryType: 'accommodation',
          capacity: '10-20명',
          location: '용산구 한강대로',
          distance: '1.8km',
          rating: 4.7,
          availableToday: true,
          image: '/static/store4.jpg',
          priceRange: '1박 20만원',
          description: '한강뷰 게스트하우스. 단체 숙박 전용 공간.',
          lat: 37.5326,
          lng: 126.9906
        },
        {
          id: 5,
          name: '서울랜드 단체방',
          category: '테마파크',
          categoryType: 'leisure',
          capacity: '20-40명',
          location: '과천시 서울대공원로',
          distance: '15.5km',
          rating: 4.5,
          availableToday: true,
          image: '/static/store5.jpg',
          priceRange: '1인 5만원',
          description: '서울랜드 단체 이용 패키지. 놀이기구 무제한.',
          lat: 37.4338,
          lng: 127.0146
        },
        {
          id: 6,
          name: '제주 펜션',
          category: '펜션',
          categoryType: 'accommodation',
          capacity: '8-15명',
          location: '제주시 애월읍',
          distance: '432km',
          rating: 4.9,
          availableToday: true,
          image: '/static/store6.jpg',
          priceRange: '1박 35만원',
          description: '제주 바다뷰 펜션. BBQ 시설과 수영장 완비.',
          lat: 33.4996,
          lng: 126.5312
        }
      ],
      currentStore: null, // 현재 선택된 업장 정보
      userWishlist: [] // 사용자 찜 목록 (로컬스토리지에서 불러옴)
    };
    
    // 찜 목록 불러오기
    this.loadUserWishlist();
    
    // 예약 상태 관리 (STEP 7)
    this.reservationState = {
      selectedDate: null,
      selectedTime: null,
      selectedGuests: 4, // 최소 4명부터 시작
      memo: '',
      agreeRefundPolicy: false,
      availableDates: this.generateAvailableDates(),
      availableTimes: [
        { time: '09:00', available: true },
        { time: '10:00', available: true },
        { time: '11:00', available: false },
        { time: '12:00', available: true },
        { time: '13:00', available: true },
        { time: '14:00', available: false },
        { time: '15:00', available: true },
        { time: '16:00', available: true },
        { time: '17:00', available: true },
        { time: '18:00', available: false },
        { time: '19:00', available: true },
        { time: '20:00', available: true },
        { time: '21:00', available: true },
        { time: '22:00', available: false }
      ],
      pricePerHour: 150000,
      minimumHours: 2
    };
    
    // 결제 및 예약 완료 상태 관리 (STEP 8)
    this.paymentState = {
      selectedMethod: 'card', // 'card', 'paybook', 'kakaopay', 'naverpay'
      saveCard: false,
      isProcessing: false,
      cardNumber: '',
      cardExpiry: '',
      cardCVC: '',
      cardHolder: ''
    };
    
    this.bookingState = {
      completedBookings: this.loadCompletedBookings()
    };
    
    // 예약 변경/취소 상태 관리 (STEP 9)
    this.modificationState = {
      currentBooking: null,
      originalGuests: 0,
      newGuests: 0,
      guestDifference: 0,
      additionalDeposit: 0,
      refundAmount: 0,
      isModifying: false,
      isCancelling: false,
      showDepositPopup: false,
      showRefundGuide: false,
      showCancellationPolicy: false
    };
    
    // QR/PIN 생성 상태 관리 (STEP 11)
    this.qrState = {
      currentQR: null,
      currentPIN: null,
      expiryTime: null,
      refreshInterval: null,
      isGenerating: false,
      validityMinutes: 3
    };
    
    // 찜 관리 상태 (STEP 12)
    this.wishlistState = {
      selectedCategory: 'all', // 'all', 'restaurant', 'leisure', 'accommodation'
      categories: [
        { id: 'all', name: '전체', icon: 'fas fa-heart' },
        { id: 'restaurant', name: '식당', icon: 'fas fa-utensils' },
        { id: 'leisure', name: '레저', icon: 'fas fa-gamepad' },
        { id: 'accommodation', name: '숙박', icon: 'fas fa-bed' }
      ]
    };
    
    // 다마고치식 오리 레벨 시스템 정의 (STEP 14)
    this.duckLevelSystem = {
      levels: {
        starter_egg: {
          id: 'starter_egg',
          name: '알 (Starter Egg)',
          emoji: '🥚',
          description: '가입을 축하합니다! 첫 모임을 성공시켜 보세요.',
          bonusRate: 0, // 기본 적립률 추가 보너스
          requirements: {
            totalGuests: 0,
            totalRevenue: 0,
            totalReservations: 0,
            consecutiveNoShows: 0,
            completedMeetings: 0
          },
          benefits: ['기본 적립률 1%']
        },
        baby_duck: {
          id: 'baby_duck',
          name: '아기오리',
          emoji: '🐣',
          description: '첫 모임을 성공하셨네요! 더 큰 모임에 도전해보세요.',
          bonusRate: 0,
          requirements: {
            totalGuests: 1,         // 첫 예약/첫 방문 성공
            totalRevenue: 0,
            totalReservations: 1,
            consecutiveNoShows: 0,
            completedMeetings: 1
          },
          benefits: ['기본 적립률 1%', '모임 가이드 제공']
        },
        leader_duck: {
          id: 'leader_duck',
          name: '리더오리',
          emoji: '🦆',
          description: '모임의 리더가 되셨습니다! 특별한 배지를 획득하세요.',
          bonusRate: 0.5, // +0.5% 적립률 보너스
          requirements: {
            totalGuests: 30,        // 누적 인원 30명
            totalRevenue: 1000000,  // 매출 100만원
            totalReservations: 0,
            consecutiveNoShows: 0,
            completedMeetings: 0
          },
          benefits: ['기본 적립률 1.5%', '리더 배지', '우선 예약권', '전용 상담']
        },
        black_duck: {
          id: 'black_duck',
          name: '검은오리',
          emoji: '🦆‍⬛',
          description: '신뢰할 수 있는 호스트입니다! 프리미엄 혜택을 누리세요.',
          bonusRate: 1.0, // +1.0% 적립률 보너스 (누적)
          requirements: {
            totalGuests: 100,       // 누적 인원 100명
            totalRevenue: 5000000,  // 매출 500만원
            totalReservations: 0,
            consecutiveNoShows: 10, // 노쇼 없는 예약 10회 연속
            completedMeetings: 0
          },
          benefits: ['기본 적립률 2%', '프리미엄 배지', 'VIP 고객센터', '수수료 할인 10%', '특별 이벤트 초대']
        },
        golden_duck: {
          id: 'golden_duck',
          name: '황금오리',
          emoji: '🦆✨',
          description: '최고의 호스트입니다! 모든 프리미엄 혜택을 누리세요.',
          bonusRate: 1.5, // +1.5% 적립률 보너스 (누적)
          requirements: {
            totalGuests: 200,       // 누적 인원 200명
            totalRevenue: 10000000, // 매출 1천만원
            totalReservations: 0,
            consecutiveNoShows: 0,
            completedMeetings: 30   // 모임 30회
          },
          benefits: ['기본 적립률 2.5%', '황금 배지', '전담 매니저', '수수료 할인 20%', 'VIP 라운지 이용', '연간 특별 리워드']
        }
      }
    };
    
    // 전역 가드 & 예외 처리 (STEP 17)
    this.globalGuard = {
      toastQueue: [],
      activeDialog: null,
      lastToastId: 0
    };
    
    // 마이페이지 상태 관리 (STEP 13)
    this.myPageState = {
      // 다마고치식 오리 레벨 시스템 (STEP 14)
      duckLevel: {
        current: 'baby_duck', // 'starter_egg', 'baby_duck', 'leader_duck', 'black_duck', 'golden_duck'
        currentStats: {
          totalGuests: 42,        // 누적 예약 인원
          totalRevenue: 650000,   // 누적 매출 (원)
          totalReservations: 8,   // 총 예약 횟수
          consecutiveNoShows: 0,  // 연속 노쇼 없는 예약 횟수
          completedMeetings: 8    // 완료된 모임 횟수
        }
      },
      
      // 적립 현황
      pointsStatus: {
        totalPoints: 125000,      // 전체 적립포인트
        reservationCount: 8,      // 예약건수
        totalGuests: 42,          // 예약인원
        pendingPoints: 15000,     // 미확정 포인트
        withdrawablePoints: 110000 // 인출가능 포인트
      },
      
      // 프리미엄 멤버십
      premiumMembership: {
        isActive: false,
        monthlyFee: 5500,
        bonusRate: 8, // 8% 적립 부스터
        benefits: ['8% 추가 적립', '우선 예약', '전용 고객센터', '수수료 할인']
      },
      
      // 출금 정보
      withdrawalInfo: {
        bankName: '',
        accountNumber: '',
        accountHolder: '',
        socialSecurityNumber: '', // 주민번호 (마스킹됨)
        rememberInfo: false,
        showSSN: false // 주민번호 표시 여부
      },
      
      // 예약 현황
      reservations: [
        {
          id: 'RES001',
          storeName: '강남 프라이빗 카페',
          date: '2024-09-05',
          time: '14:00',
          guests: 8,
          status: 'confirmed', // confirmed, pending, cancelled
          amount: 240000,
          earnedPoints: 2400
        },
        {
          id: 'RES002',
          storeName: '홍대 루프탑 바',
          date: '2024-09-12',
          time: '19:00',
          guests: 6,
          status: 'pending',
          amount: 180000,
          earnedPoints: 0
        }
      ],
      
      // 이용 내역
      usageHistory: [
        {
          id: 'HIST001',
          storeName: '이태원 프라이빗 다이닝',
          date: '2024-08-20',
          guests: 10,
          amount: 350000,
          earnedPoints: 3500,
          rating: 4.8
        },
        {
          id: 'HIST002',
          storeName: '청담 프리미엄 카페',
          date: '2024-08-15',
          guests: 4,
          amount: 120000,
          earnedPoints: 1200,
          rating: 4.5
        }
      ],
      
      // 알림 설정
      notificationSettings: {
        reservationConfirm: true,    // 예약 확정 알림
        promotionNews: true,         // 프로모션 소식
        pointsUpdate: true,          // 포인트 적립 알림
        levelUpdate: true,           // 레벨 업 알림
        withdrawalComplete: true,    // 출금 완료 알림
        marketingConsent: false      // 마케팅 수신 동의
      },
      
      // 팝업 상태
      showWithdrawalPopup: false,
      showSubscriptionPopup: false,
      showPhoneVerificationPopup: false
    };
    
    // 위치 권한 상태 관리
    this.locationState = {
      permissionGranted: false,
      permissionAsked: false,
      coordinates: null,
      address: null,
      defaultLocation: {
        lat: 37.5665,
        lng: 126.9780,
        address: '서울특별시 중구'
      }
    };
    
    // 온보딩 슬라이드 상태 관리
    this.onboardingState = {
      currentSlide: 0,
      totalSlides: 3,
      slides: [
        {
          icon: 'fas fa-users',
          iconColor: 'text-blue-600',
          bgColor: 'bg-blue-100',
          title: '오직 단체예약만!',
          subtitle: '4인 이상만 혜택 제공',
          description: '소규모 모임부터 대규모 행사까지\n특별한 단체 할인과 서비스를 경험하세요'
        },
        {
          icon: 'fas fa-credit-card',
          iconColor: 'text-green-600',
          bgColor: 'bg-green-100',
          title: '현장 결제, 앱은 적립',
          subtitle: '정산 자동으로 간편하게',
          description: '보증금만 앱에서 결제하고\n나머지는 현장에서! 포인트는 자동 적립됩니다'
        },
        {
          icon: 'fas fa-qrcode',
          iconColor: 'text-purple-600',
          bgColor: 'bg-purple-100',
          title: 'QR 한 번으로',
          subtitle: '빠른 입장 완료',
          description: '복잡한 체크인 없이\nQR코드 하나로 스마트하게 입장하세요'
        }
      ]
    };
    
    this.init();
  }

  init() {
    // 저장된 상태들 복원
    const savedAuthState = localStorage.getItem('authState');
    const savedUser = localStorage.getItem('user');
    
    if (savedAuthState) {
      this.authState = JSON.parse(savedAuthState);
    }
    
    if (savedUser) {
      this.user = JSON.parse(savedUser);
    }
    
    // 위치 상태 복원
    this.loadLocationState();
    
    // 화면 초기화 로직
    if (this.showOnboarding) {
      this.currentScreen = 'onboarding';
    } else if (this.authState.isLoggedIn && !this.showOnboarding) {
      // 로그인된 사용자: 위치 권한을 아직 물어보지 않았다면 위치 권한 화면으로
      if (!this.locationState.permissionAsked) {
        this.currentScreen = 'location-permission';
      } else {
        this.currentScreen = 'home';
      }
    }
    
    this.render();
    this.bindEvents();
  }

  // 화면 전환
  navigateTo(screen) {
    // QR 화면에서 나갈 때 타이머 정리
    if (this.currentScreen === 'qr' && screen !== 'qr') {
      this.cleanupQRTimer();
    }
    
    this.currentScreen = screen;
    this.render();
  }

  // 메인 렌더링
  render() {
    const app = document.getElementById('app');
    
    switch (this.currentScreen) {
      case 'onboarding':
        app.innerHTML = this.renderOnboarding();
        break;
      case 'login':
        app.innerHTML = this.renderLogin();
        break;
      case 'location-permission':
        app.innerHTML = this.renderLocationPermission();
        break;
      case 'home':
        app.innerHTML = this.renderHome();
        break;
      case 'store-detail':
        app.innerHTML = this.renderStoreDetail();
        break;
      case 'reservation':
        app.innerHTML = this.renderReservation();
        break;
      case 'payment':
        app.innerHTML = this.renderPayment();
        break;
      case 'booking-complete':
        app.innerHTML = this.renderBookingComplete();
        break;
      case 'modify-reservation':
        app.innerHTML = this.renderModifyReservation();
        break;
      case 'cancel-reservation':
        app.innerHTML = this.renderCancelReservation();
        break;
      case 'deposit-payment':
        app.innerHTML = this.renderDepositPayment();
        break;
      case 'qr':
        app.innerHTML = this.renderQR();
        break;
      case 'wishlist':
        app.innerHTML = this.renderWishlist();
        break;
      case 'my':
        app.innerHTML = this.renderMy();
        break;
      case 'dev-notes':
        app.innerHTML = this.renderDevNotes();
        break;
      case 'phone-auth':
        app.innerHTML = this.renderPhoneAuth();
        break;
      case 'social-consent':
        app.innerHTML = this.renderSocialConsent();
        break;
      case 'verification-required':
        app.innerHTML = this.renderVerificationRequired();
        break;
      case 'revenue-structure':
        app.innerHTML = this.renderRevenueStructure();
        break;
      case 'refund-policy':
        app.innerHTML = this.renderRefundPolicy();
        break;
      case 'group-policy':
        app.innerHTML = this.renderGroupPolicy();
        break;
      case 'policies':
        app.innerHTML = this.renderPolicies();
        break;
      default:
        app.innerHTML = this.renderLogin();
    }
    
    this.bindScreenEvents();
  }

  // 이벤트 바인딩
  bindEvents() {
    // 전역 이벤트 리스너
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('nav-item')) {
        const screen = e.target.dataset.screen;
        this.navigateTo(screen);
      }
    });
  }

  bindScreenEvents() {
    // 각 화면별 이벤트 바인딩
    this.bindOnboardingEvents();
    this.bindLoginEvents();
    this.bindLocationEvents();
    this.bindHomeEvents();
    this.bindStoreDetailEvents();
    this.bindReservationEvents();
    this.bindPaymentEvents();
    this.bindModificationEvents();
  }

  // === 화면 렌더링 함수들 ===

  renderOnboarding() {
    const currentSlideData = this.onboardingState.slides[this.onboardingState.currentSlide];
    const isLastSlide = this.onboardingState.currentSlide === this.onboardingState.totalSlides - 1;
    const isFirstSlide = this.onboardingState.currentSlide === 0;
    
    return `
      <div class="modal-overlay">
        <div class="modal-content slide-fade-in p-0 max-w-sm w-full max-h-screen overflow-hidden">
          <!-- 상단 Skip 버튼 -->
          <div class="flex justify-end p-4 pb-2">
            <button 
              class="text-gray-500 text-sm font-medium hover:text-gray-700" 
              onclick="OReeApp.instance.skipOnboarding()"
            >
              Skip
            </button>
          </div>
          
          <!-- 슬라이드 컨테이너 -->
          <div class="px-6 pb-8">
            <div class="text-center">
              <!-- 아이콘 영역 -->
              <div class="mb-8">
                <div class="w-24 h-24 mx-auto ${currentSlideData.bgColor} rounded-full flex items-center justify-center mb-6 icon-bounce">
                  <i class="${currentSlideData.icon} text-4xl ${currentSlideData.iconColor}"></i>
                </div>
              </div>
              
              <!-- 텍스트 영역 -->
              <div class="mb-8">
                <h2 class="text-2xl font-bold text-gray-900 mb-2">${currentSlideData.title}</h2>
                <p class="text-lg font-semibold text-blue-600 mb-4">${currentSlideData.subtitle}</p>
                <p class="text-gray-600 text-sm leading-relaxed whitespace-pre-line">${currentSlideData.description}</p>
              </div>
              
              <!-- 슬라이드 인디케이터 -->
              <div class="flex justify-center space-x-2 mb-8">
                ${Array.from({length: this.onboardingState.totalSlides}, (_, index) => `
                  <div class="w-2 h-2 rounded-full transition-all duration-300 ${
                    index === this.onboardingState.currentSlide 
                      ? 'bg-blue-600 indicator-active' 
                      : 'bg-gray-300'
                  }"></div>
                `).join('')}
              </div>
              
              <!-- 버튼 영역 -->
              <div class="space-y-3">
                ${isLastSlide 
                  ? `
                    <button 
                      class="btn btn-primary w-full py-4 font-semibold" 
                      onclick="OReeApp.instance.completeOnboarding()"
                    >
                      시작하기
                    </button>
                  `
                  : `
                    <button 
                      class="btn btn-primary w-full py-4 font-semibold" 
                      onclick="OReeApp.instance.nextSlide()"
                    >
                      다음
                    </button>
                  `
                }
                
                ${!isFirstSlide && !isLastSlide 
                  ? `
                    <button 
                      class="btn btn-secondary w-full py-3" 
                      onclick="OReeApp.instance.prevSlide()"
                    >
                      이전
                    </button>
                  ` 
                  : ''
                }
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderLogin() {
    return `
      <div class="min-h-screen bg-gradient-to-br from-blue-50 to-white flex flex-col">
        <!-- 상단 슬로건 영역 -->
        <div class="flex-1 flex items-center justify-center px-6 py-12">
          <div class="text-center max-w-sm">
            <!-- 일러스트 영역 -->
            <div class="mb-8">
              <div class="w-32 h-32 mx-auto bg-blue-100 rounded-full flex items-center justify-center mb-6">
                <i class="fas fa-users text-5xl text-blue-600"></i>
              </div>
              <h1 class="text-4xl font-bold text-gray-900 mb-3">ORee</h1>
              <p class="text-lg text-gray-600 mb-2">우리들의 모임,</p>
              <p class="text-lg text-gray-600">더 쉽고 특별하게</p>
            </div>
            
            <!-- 기능 소개 -->
            <div class="space-y-3 text-sm text-gray-600">
              <div class="flex items-center justify-center space-x-2">
                <i class="fas fa-map-marker-alt text-blue-500"></i>
                <span>내 주변 단체 가능한 업장 검색</span>
              </div>
              <div class="flex items-center justify-center space-x-2">
                <i class="fas fa-calendar-check text-blue-500"></i>
                <span>간편한 예약과 보증금 결제</span>
              </div>
              <div class="flex items-center justify-center space-x-2">
                <i class="fas fa-qrcode text-blue-500"></i>
                <span>QR코드로 스마트한 입장</span>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 하단 로그인 영역 -->
        <div class="bg-white rounded-t-3xl px-6 py-8 shadow-lg">
          <div class="max-w-sm mx-auto space-y-4">
            
            <!-- 소셜 로그인 버튼들 -->
            <button class="btn w-full py-4 bg-yellow-400 text-gray-900 font-semibold hover:bg-yellow-500 active:bg-yellow-600 flex items-center justify-center space-x-3" onclick="OReeApp.instance.handleSocialLogin('kakao')">
              <i class="fas fa-comment text-xl"></i>
              <span>카카오로 시작하기</span>
            </button>
            
            <button class="btn w-full py-4 bg-green-500 text-white font-semibold hover:bg-green-600 active:bg-green-700 flex items-center justify-center space-x-3" onclick="OReeApp.instance.handleSocialLogin('naver')">
              <span class="text-xl font-bold">N</span>
              <span>네이버로 시작하기</span>
            </button>
            
            <button class="btn btn-secondary w-full py-4 font-semibold flex items-center justify-center space-x-3" onclick="OReeApp.instance.showPhoneAuth()">
              <i class="fas fa-mobile-alt text-xl"></i>
              <span>전화번호로 가입</span>
            </button>
            
            <!-- 둘러보기 -->
            <div class="pt-4 text-center">
              <button class="text-gray-500 underline text-sm" onclick="OReeApp.instance.handleGuestLogin()">
                회원가입 없이 둘러보기
              </button>
            </div>
            
            <!-- 이용약관 -->
            <div class="pt-2 text-xs text-gray-500 text-center">
              로그인 시 <span class="underline">이용약관</span> 및 <span class="underline">개인정보처리방침</span>에 동의하는 것으로 간주됩니다.
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderLocationPermission() {
    return `
      <div class="modal-overlay">
        <div class="modal-content fade-in p-6 max-w-sm">
          <div class="text-center">
            <!-- 위치 아이콘 -->
            <div class="w-20 h-20 mx-auto bg-blue-100 rounded-full flex items-center justify-center mb-6">
              <i class="fas fa-map-marker-alt text-3xl text-blue-600"></i>
            </div>
            
            <!-- 메인 타이틀 -->
            <h2 class="text-xl font-bold text-gray-900 mb-3">내 위치 추적을 허용하시겠어요?</h2>
            
            <!-- 설명 텍스트 -->
            <p class="text-gray-600 text-sm mb-2 leading-relaxed">
              내 주변의 단체예약 가능한 업장을 찾아드려요
            </p>
            <p class="text-gray-500 text-xs mb-8">
              (프로필에서 변경 가능)
            </p>
            
            <!-- 위치 사용 혜택 -->
            <div class="bg-blue-50 rounded-button p-4 mb-8">
              <div class="space-y-2 text-xs text-left">
                <div class="flex items-center space-x-2">
                  <i class="fas fa-check-circle text-blue-600"></i>
                  <span class="text-blue-800">내 주변 맞춤 업장 추천</span>
                </div>
                <div class="flex items-center space-x-2">
                  <i class="fas fa-check-circle text-blue-600"></i>
                  <span class="text-blue-800">거리순 정렬 및 길찾기 제공</span>
                </div>
                <div class="flex items-center space-x-2">
                  <i class="fas fa-check-circle text-blue-600"></i>
                  <span class="text-blue-800">지역별 특가 혜택 알림</span>
                </div>
              </div>
            </div>
            
            <!-- 버튼들 -->
            <div class="space-y-3">
              <button 
                class="btn btn-primary w-full py-4 font-semibold" 
                onclick="OReeApp.instance.allowLocationAndSave()"
              >
                허용 후 저장
              </button>
              
              <button 
                class="btn btn-secondary w-full py-3" 
                onclick="OReeApp.instance.skipLocationLater()"
              >
                나중에
              </button>
            </div>
            
            <!-- 개인정보 안내 -->
            <p class="text-xs text-gray-500 mt-4 leading-relaxed">
              위치 정보는 서비스 제공 목적으로만 사용되며,<br>
              언제든지 설정에서 변경하실 수 있습니다.
            </p>
          </div>
        </div>
      </div>
    `;
  }

  renderHome() {
    return `
      <div class="pb-20 relative">
        ${this.renderHomeHeader()}
        ${this.renderSearchBar()}
        ${this.renderFilterControls()}
        ${this.renderMapListToggle()}
        ${this.renderMainContent()}
        ${this.renderNotificationPanel()}
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderHomeHeader() {
    const unreadCount = this.homeState.notifications.filter(n => !n.isRead).length;
    
    return `
      <!-- 상단 헤더 -->
      <div class="header p-4 bg-white border-b border-gray-100">
        <div class="flex justify-between items-center">
          <!-- 위치 정보 (좌측) -->
          <div class="text-sm text-gray-600">
            <i class="fas fa-map-marker-alt mr-1 ${this.locationState.permissionGranted ? 'text-blue-600' : 'text-gray-400'}"></i>
            ${this.getCurrentLocationText()}
          </div>
          
          <!-- 중앙 로고 -->
          <div class="absolute left-1/2 transform -translate-x-1/2">
            <div class="bg-blue-600 px-4 py-2 rounded-button">
              <h1 class="text-lg font-bold text-white">ORee</h1>
            </div>
          </div>
          
          <!-- 우측 아이콘들 -->
          <div class="flex items-center space-x-2">
            <button class="p-2 text-gray-600 hover:text-blue-600 transition-colors" 
                    onclick="OReeApp.instance.navigateTo('revenue-structure')" 
                    title="수익 구조 안내">
              <i class="fas fa-info-circle text-lg"></i>
            </button>
            
            <button class="notification-btn relative p-2" data-action="toggle-notifications">
              <i class="fas fa-bell text-xl text-gray-600"></i>
              ${unreadCount > 0 ? `
              <span class="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                ${unreadCount > 9 ? '9+' : unreadCount}
              </span>
            ` : ''}
          </button>
        </div>
      </div>
    `;
  }

  renderSearchBar() {
    return `
      <!-- 검색바 -->
      <div class="px-4 py-3 bg-white border-b border-gray-100">
        <div class="relative">
          <input 
            type="text" 
            placeholder="지역, 상호명으로 검색하세요" 
            class="w-full pl-10 pr-4 py-3 bg-gray-50 rounded-button text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white"
            value="${this.homeState.searchQuery}"
            data-action="search-input"
          >
          <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
        </div>
      </div>
    `;
  }

  renderFilterControls() {
    return `
      <!-- 필터 컨트롤 -->
      <div class="px-4 py-3 bg-white border-b border-gray-100">
        <div class="flex items-center space-x-3">
          <button class="filter-btn flex items-center space-x-2 px-3 py-2 ${this.homeState.filters.reservationAvailable ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'} rounded-button text-sm" data-filter="reservation-available">
            <i class="fas fa-calendar-check"></i>
            <span>예약가능</span>
          </button>
          
          <button class="filter-btn flex items-center space-x-2 px-3 py-2 bg-gray-100 text-gray-700 rounded-button text-sm" data-filter="sort">
            <i class="fas fa-sort"></i>
            <span>${this.homeState.filters.sortBy === 'distance' ? '거리순' : this.homeState.filters.sortBy === 'rating' ? '평점순' : '가격순'}</span>
          </button>
        </div>
      </div>
    `;
  }

  renderMapListToggle() {
    return `
      <!-- 지도/목록 전환 토글 -->
      <div class="px-4 py-3 bg-white">
        <div class="flex bg-gray-100 rounded-button p-1">
          <button class="view-toggle flex-1 py-2 text-center rounded-button transition-all ${this.homeState.viewMode === 'map' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600'}" data-view="map">
            <i class="fas fa-map mr-2"></i>지도보기
          </button>
          <button class="view-toggle flex-1 py-2 text-center rounded-button transition-all ${this.homeState.viewMode === 'list' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600'}" data-view="list">
            <i class="fas fa-list mr-2"></i>목록보기
          </button>
        </div>
      </div>
    `;
  }

  renderMainContent() {
    if (this.homeState.viewMode === 'map') {
      return this.renderMapView();
    } else {
      return this.renderListView();
    }
  }

  renderMapView() {
    return `
      <!-- 지도 뷰 -->
      <div class="map-container relative">
        <!-- 지도 영역 -->
        <div class="map-area bg-gray-200 h-96 relative overflow-hidden">
          <!-- 실제 지도가 들어갈 영역 -->
          <div class="w-full h-full bg-gradient-to-br from-blue-100 to-green-100 relative">
            <!-- 지도 배경 패턴 -->
            <div class="absolute inset-0 opacity-20">
              <svg width="100%" height="100%" viewBox="0 0 100 100" class="text-gray-400">
                <defs>
                  <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                    <path d="M 10 0 L 0 0 0 10" fill="none" stroke="currentColor" stroke-width="0.5"/>
                  </pattern>
                </defs>
                <rect width="100" height="100" fill="url(#grid)"/>
              </svg>
            </div>
            
            <!-- 업장 핀들 -->
            ${this.homeState.stores.map((store, index) => `
              <button class="store-pin absolute transform -translate-x-1/2 -translate-y-full" 
                      data-store-id="${store.id}"
                      style="left: ${30 + (index * 25)}%; top: ${40 + (index * 15)}%;">
                <div class="bg-blue-600 text-white p-2 rounded-full shadow-lg hover:bg-blue-700 transition-colors">
                  <i class="fas fa-map-marker-alt text-sm"></i>
                </div>
                ${store.availableToday ? `
                  <div class="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                ` : ''}
              </button>
            `).join('')}
          </div>
          
          <!-- 지도 컨트롤 -->
          <div class="absolute top-4 right-4 space-y-2">
            <button class="bg-white p-2 rounded-button shadow-md">
              <i class="fas fa-plus text-gray-600"></i>
            </button>
            <button class="bg-white p-2 rounded-button shadow-md">
              <i class="fas fa-minus text-gray-600"></i>
            </button>
          </div>
        </div>
        
        ${this.renderSlideCardNews()}
      </div>
    `;
  }

  renderListView() {
    return `
      <!-- 목록 뷰 -->
      <div class="px-4 py-4">
        <div class="grid grid-cols-2 gap-4">
          ${this.homeState.stores.map(store => this.renderStoreGridCard(store)).join('')}
        </div>
      </div>
    `;
  }

  renderStoreGridCard(store) {
    return `
      <div class="store-card bg-white rounded-button shadow-sm border border-gray-100 overflow-hidden cursor-pointer" onclick="OReeApp.instance.navigateTo('store-detail')">
        <!-- 이미지 영역 -->
        <div class="relative">
          <div class="w-full h-32 bg-gray-200 flex items-center justify-center">
            <i class="fas fa-image text-2xl text-gray-400"></i>
          </div>
          <div class="absolute top-2 right-2">
            <button class="w-8 h-8 bg-white bg-opacity-80 rounded-full flex items-center justify-center">
              <i class="far fa-heart text-gray-400 text-sm"></i>
            </button>
          </div>
          ${store.availableToday ? `
            <div class="absolute bottom-2 left-2">
              <span class="bg-green-500 text-white text-xs px-2 py-1 rounded">예약가능</span>
            </div>
          ` : `
            <div class="absolute bottom-2 left-2">
              <span class="bg-gray-500 text-white text-xs px-2 py-1 rounded">예약마감</span>
            </div>
          `}
        </div>
        
        <!-- 정보 영역 -->
        <div class="p-3">
          <h4 class="font-semibold text-gray-900 text-sm mb-1 truncate">${store.name}</h4>
          <p class="text-xs text-gray-600 mb-2">${store.capacity} • ${store.location}</p>
          <div class="flex items-center justify-between">
            <div class="flex items-center space-x-1">
              <i class="fas fa-star text-yellow-400 text-xs"></i>
              <span class="text-xs text-gray-600">${store.rating}</span>
            </div>
            <span class="text-xs text-blue-600">${store.distance}</span>
          </div>
        </div>
      </div>
    `;
  }

  renderSlideCardNews() {
    const selectedStore = this.homeState.selectedPin ? 
      this.homeState.stores.find(s => s.id === this.homeState.selectedPin) : 
      this.homeState.stores[0];
      
    if (!selectedStore) return '';
    
    return `
      <!-- 하단 슬라이드 카드뉴스 -->
      <div class="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl shadow-lg transform transition-transform duration-300 ${this.homeState.selectedPin ? 'translate-y-0' : 'translate-y-full'}">
        <div class="p-4">
          <!-- 드래그 핸들 -->
          <div class="w-8 h-1 bg-gray-300 rounded mx-auto mb-4"></div>
          
          <!-- 카드 컨테이너 -->
          <div class="card-container overflow-x-auto">
            <div class="flex space-x-4" style="width: fit-content;">
              ${this.homeState.stores.map(store => `
                <div class="store-slide-card flex-shrink-0 w-72 bg-white border border-gray-100 rounded-button overflow-hidden ${store.id === selectedStore.id ? 'ring-2 ring-blue-500' : ''}">
                  <!-- 이미지 -->
                  <div class="relative">
                    <div class="w-full h-40 bg-gray-200 flex items-center justify-center">
                      <i class="fas fa-image text-3xl text-gray-400"></i>
                    </div>
                    <div class="absolute top-3 right-3">
                      <button class="w-8 h-8 bg-white bg-opacity-90 rounded-full flex items-center justify-center shadow">
                        <i class="far fa-heart text-gray-400"></i>
                      </button>
                    </div>
                  </div>
                  
                  <!-- 정보 -->
                  <div class="p-4">
                    <div class="flex items-start justify-between mb-2">
                      <h3 class="font-semibold text-gray-900">${store.name}</h3>
                      ${store.availableToday ? `
                        <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">예약가능</span>
                      ` : `
                        <span class="bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded">예약마감</span>
                      `}
                    </div>
                    
                    <p class="text-sm text-gray-600 mb-3">${store.capacity} • ${store.location}</p>
                    
                    <div class="flex items-center justify-between mb-3">
                      <div class="flex items-center space-x-1">
                        <i class="fas fa-star text-yellow-400"></i>
                        <span class="font-medium text-gray-900">${store.rating}</span>
                        <span class="text-sm text-gray-600">(127)</span>
                      </div>
                      <span class="text-sm text-blue-600 font-medium">${store.distance}</span>
                    </div>
                    
                    <button class="w-full btn btn-primary text-sm py-2" onclick="OReeApp.instance.navigateTo('store-detail')">
                      상세보기
                    </button>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderNotificationPanel() {
    const reservationNotifications = this.homeState.notifications.filter(n => n.type === 'reservation');
    const unreadNotifications = this.homeState.notifications.filter(n => !n.isRead);
    
    return `
      <!-- 알림 슬라이드 패널 -->
      <div class="notification-panel fixed top-0 right-0 w-full max-w-sm h-full bg-white shadow-xl transform transition-transform duration-300 z-50 ${this.homeState.showNotifications ? 'translate-x-0' : 'translate-x-full'}">
        <!-- 헤더 -->
        <div class="p-4 border-b border-gray-200">
          <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-semibold text-gray-900">알림</h2>
            <button class="close-notifications p-1">
              <i class="fas fa-times text-gray-400 text-xl"></i>
            </button>
          </div>
          
          <!-- 필터 -->
          <div class="space-y-3">
            <div class="flex space-x-2">
              <button class="notification-filter px-3 py-2 text-sm bg-blue-600 text-white rounded-button" data-filter="all">
                전체 (${this.homeState.notifications.length})
              </button>
              <button class="notification-filter px-3 py-2 text-sm bg-gray-100 text-gray-700 rounded-button" data-filter="reservation">
                예약 관련 (${reservationNotifications.length})
              </button>
            </div>
            
            <div class="flex items-center justify-between">
              <div class="flex space-x-2">
                <button class="notification-filter px-3 py-2 text-sm bg-gray-100 text-gray-700 rounded-button" data-filter="unread">
                  미읽음 (${unreadNotifications.length})
                </button>
                <button class="notification-filter px-3 py-2 text-sm bg-gray-100 text-gray-700 rounded-button" data-filter="read">
                  읽음
                </button>
              </div>
              
              <button class="mark-all-read text-sm text-blue-600 hover:text-blue-700">
                모두 읽음
              </button>
            </div>
          </div>
        </div>
        
        <!-- 알림 목록 -->
        <div class="notification-list flex-1 overflow-y-auto">
          ${this.homeState.notifications.map(notification => `
            <div class="notification-item p-4 border-b border-gray-100 ${!notification.isRead ? 'bg-blue-50' : ''}" data-notification-id="${notification.id}">
              <div class="flex items-start space-x-3">
                <div class="flex-shrink-0 mt-1">
                  <div class="w-8 h-8 ${notification.type === 'reservation' ? 'bg-blue-100' : 'bg-green-100'} rounded-full flex items-center justify-center">
                    <i class="fas ${notification.type === 'reservation' ? 'fa-calendar-check text-blue-600' : 'fa-bullhorn text-green-600'} text-sm"></i>
                  </div>
                </div>
                
                <div class="flex-1 min-w-0">
                  <div class="flex items-center justify-between mb-1">
                    <h4 class="text-sm font-medium text-gray-900">${notification.title}</h4>
                    ${!notification.isRead ? `
                      <div class="w-2 h-2 bg-blue-600 rounded-full"></div>
                    ` : ''}
                  </div>
                  <p class="text-sm text-gray-600 mb-2">${notification.message}</p>
                  <p class="text-xs text-gray-400">${notification.time}</p>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
      
      <!-- 오버레이 -->
      ${this.homeState.showNotifications ? `
        <div class="notification-overlay fixed inset-0 bg-black bg-opacity-50 z-40" onclick="OReeApp.instance.toggleNotifications()"></div>
      ` : ''}
    `;
  }

  renderStoreCard() {
    return `
      <div class="card p-4 cursor-pointer" onclick="OReeApp.instance.navigateTo('store-detail')">
        <div class="flex space-x-4">
          <div class="w-20 h-20 bg-gray-200 rounded-button flex-shrink-0">
            <i class="fas fa-image text-gray-400 w-full h-full flex items-center justify-center"></i>
          </div>
          <div class="flex-1">
            <div class="flex justify-between items-start mb-2">
              <h4 class="font-semibold text-gray-900">강남 프라이빗 카페</h4>
              <button class="text-gray-400 hover:text-red-500">
                <i class="far fa-heart"></i>
              </button>
            </div>
            <p class="text-sm text-gray-600 mb-2">20-30명 단체 가능 • 강남구 테헤란로</p>
            <div class="flex items-center justify-between">
              <div class="flex items-center space-x-2">
                <span class="text-yellow-500"><i class="fas fa-star"></i></span>
                <span class="text-sm text-gray-700">4.8 (128)</span>
              </div>
              <span class="text-blue-600 font-semibold">시간당 15만원</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderStoreDetail() {
    // 현재 업장 정보 (실제로는 URL 파라미터나 선택된 업장에서 가져옴)
    const store = this.homeState.currentStore || this.homeState.stores[0];
    const isWishlisted = this.isStoreInWishlist(store.id);
    
    return `
      <div class="pb-32">
        ${this.renderStoreDetailHeader(store, isWishlisted)}
        ${this.renderStoreImageGallery(store)}
        ${this.renderStoreBasicInfo(store, isWishlisted)}
        ${this.renderStoreDetailSections(store)}
        ${this.renderStoreReservationCTA(store)}
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderStoreDetailHeader(store, isWishlisted) {
    return `
      <!-- 상세 헤더 -->
      <div class="header bg-white border-b border-gray-200 sticky top-0 z-30">
        <div class="flex justify-between items-center p-4">
          <button onclick="OReeApp.instance.navigateTo('home')" class="text-gray-600 hover:text-gray-800 transition-colors">
            <i class="fas fa-arrow-left text-xl"></i>
          </button>
          <h1 class="text-lg font-semibold text-gray-900 truncate max-w-48">${store.name}</h1>
          <div class="flex items-center space-x-3">
            <button onclick="OReeApp.instance.shareStore(${store.id})" class="text-gray-600 hover:text-gray-800 transition-colors">
              <i class="fas fa-share text-xl"></i>
            </button>
            <button onclick="OReeApp.instance.toggleWishlist(${store.id})" class="wishlist-btn transition-colors">
              <i class="fa${isWishlisted ? 's' : 'r'} fa-heart text-xl ${isWishlisted ? 'text-red-500' : 'text-gray-600 hover:text-red-500'}"></i>
            </button>
          </div>
        </div>
      </div>
    `;
  }

  renderStoreImageGallery(store) {
    const images = [
      { url: '/static/store1.jpg', caption: '메인 홀' },
      { url: '/static/store2.jpg', caption: '프라이빗룸' },
      { url: '/static/store3.jpg', caption: '테라스' },
      { url: '/static/store4.jpg', caption: '바 카운터' },
      { url: '/static/store5.jpg', caption: '전체 전경' }
    ];
    
    return `
      <!-- 이미지 갤러리 -->
      <div class="image-gallery relative bg-gray-200">
        <div class="h-72 overflow-hidden">
          <!-- 메인 이미지 -->
          <div class="w-full h-full bg-gradient-to-br from-gray-300 to-gray-400 flex items-center justify-center">
            <div class="text-center">
              <i class="fas fa-image text-4xl text-gray-500 mb-2"></i>
              <p class="text-gray-600 font-medium">${store.name}</p>
              <p class="text-sm text-gray-500">대표 이미지</p>
            </div>
          </div>
        </div>
        
        <!-- 이미지 인디케이터 -->
        <div class="absolute bottom-4 left-4 bg-black bg-opacity-60 text-white px-3 py-1 rounded-button text-sm">
          <i class="fas fa-camera mr-1"></i>
          1 / ${images.length}
        </div>
        
        <!-- 예약 상태 배지 -->
        <div class="absolute top-4 right-4">
          ${store.availableToday ? `
            <span class="bg-green-500 text-white px-3 py-2 rounded-button text-sm font-medium shadow-lg">
              <i class="fas fa-check-circle mr-1"></i>
              예약가능
            </span>
          ` : `
            <span class="bg-red-500 text-white px-3 py-2 rounded-button text-sm font-medium shadow-lg">
              <i class="fas fa-times-circle mr-1"></i>
              예약마감
            </span>
          `}
        </div>
        
        <!-- 이미지 더보기 버튼 -->
        <button class="absolute bottom-4 right-4 bg-white bg-opacity-90 text-gray-800 px-3 py-2 rounded-button text-sm font-medium hover:bg-opacity-100 transition-colors">
          <i class="fas fa-images mr-1"></i>
          사진 더보기
        </button>
      </div>
    `;
  }

  renderStoreBasicInfo(store, isWishlisted) {
    return `
      <!-- 기본 정보 -->
      <div class="store-basic-info bg-white p-6 border-b border-gray-100">
        <!-- 상호명 및 평점 -->
        <div class="flex items-start justify-between mb-4">
          <div class="flex-1">
            <h1 class="text-2xl font-bold text-gray-900 mb-2">${store.name}</h1>
            <div class="flex items-center space-x-4 mb-3">
              <div class="flex items-center space-x-1">
                <div class="flex">
                  ${Array.from({ length: 5 }, (_, i) => `
                    <i class="fas fa-star text-sm ${i < Math.floor(store.rating) ? 'text-yellow-400' : 'text-gray-300'}"></i>
                  `).join('')}
                </div>
                <span class="font-semibold text-gray-900">${store.rating}</span>
                <span class="text-gray-500 text-sm">(127개 리뷰)</span>
              </div>
            </div>
            
            <!-- 수용인원 및 카테고리 -->
            <div class="flex items-center space-x-4">
              <div class="flex items-center space-x-2">
                <i class="fas fa-users text-gray-500"></i>
                <span class="text-gray-700">${store.capacity}</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-tag text-gray-500"></i>
                <span class="text-gray-700">${store.category}</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-map-marker-alt text-gray-500"></i>
                <span class="text-gray-700">${store.distance}</span>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 핵심 특징 -->
        <div class="flex items-center space-x-2 mb-4">
          <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-button text-sm font-medium">
            <i class="fas fa-wifi mr-1"></i>무료 WiFi
          </span>
          <span class="bg-green-100 text-green-800 px-3 py-1 rounded-button text-sm font-medium">
            <i class="fas fa-car mr-1"></i>주차가능
          </span>
          <span class="bg-purple-100 text-purple-800 px-3 py-1 rounded-button text-sm font-medium">
            <i class="fas fa-video mr-1"></i>프로젝터
          </span>
        </div>
        
        <!-- 가격 정보 -->
        <div class="bg-blue-50 p-4 rounded-button">
          <div class="flex items-center justify-between">
            <div>
              <span class="text-2xl font-bold text-blue-900">150,000원</span>
              <span class="text-blue-700 ml-1">/ 시간</span>
            </div>
            <div class="text-right">
              <p class="text-sm text-blue-700">최소 2시간 이용</p>
              <p class="text-xs text-blue-600">주말 +20% 할증</p>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderStoreDetailSections(store) {
    return `
      <!-- 상세 정보 섹션들 -->
      <div class="store-detail-sections">
        ${this.renderMenuSection()}
        ${this.renderLocationSection(store)}
        ${this.renderTransportSection()}
        ${this.renderParkingSection()}
        ${this.renderReservationGuideSection()}
        ${this.renderReviewsSection()}
      </div>
    `;
  }

  renderMenuSection() {
    const menuItems = [
      { name: '아메리카노', price: '5,000원', category: '커피' },
      { name: '카페라떼', price: '5,500원', category: '커피' },
      { name: '크로와상 샌드위치', price: '12,000원', category: '브런치' },
      { name: '파스타', price: '18,000원', category: '메인' },
      { name: '맥주', price: '6,000원', category: '주류' }
    ];
    
    return `
      <!-- 메뉴 섹션 -->
      <div class="menu-section bg-white p-6 border-b border-gray-100">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-xl font-bold text-gray-900">
            <i class="fas fa-utensils text-gray-500 mr-2"></i>
            메뉴
          </h3>
          <button class="text-blue-600 text-sm font-medium">전체보기</button>
        </div>
        
        <div class="space-y-3">
          ${menuItems.slice(0, 3).map(item => `
            <div class="flex items-center justify-between py-2">
              <div>
                <h4 class="font-medium text-gray-900">${item.name}</h4>
                <p class="text-sm text-gray-600">${item.category}</p>
              </div>
              <span class="font-semibold text-gray-900">${item.price}</span>
            </div>
          `).join('')}
        </div>
        
        <button class="w-full mt-4 py-3 text-blue-600 bg-blue-50 rounded-button text-sm font-medium hover:bg-blue-100 transition-colors">
          메뉴 전체보기
        </button>
      </div>
    `;
  }

  renderLocationSection(store) {
    return `
      <!-- 위치 섹션 -->
      <div class="location-section bg-white p-6 border-b border-gray-100">
        <h3 class="text-xl font-bold text-gray-900 mb-4">
          <i class="fas fa-map-marker-alt text-gray-500 mr-2"></i>
          위치
        </h3>
        
        <div class="space-y-3">
          <div class="flex items-start space-x-3">
            <i class="fas fa-map-marker-alt text-blue-600 mt-1"></i>
            <div>
              <p class="font-medium text-gray-900">${store.location}</p>
              <p class="text-sm text-gray-600">서울특별시 강남구 테헤란로 123 (역삼동)</p>
            </div>
          </div>
          
          <!-- 간단 지도 -->
          <div class="mt-4 h-32 bg-gray-200 rounded-button relative overflow-hidden">
            <div class="absolute inset-0 bg-gradient-to-br from-blue-100 to-green-100 flex items-center justify-center">
              <div class="text-center">
                <i class="fas fa-map text-2xl text-gray-500 mb-2"></i>
                <p class="text-sm text-gray-600">지도 보기</p>
              </div>
            </div>
            <!-- 위치 핀 -->
            <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <i class="fas fa-map-marker-alt text-2xl text-red-500"></i>
            </div>
          </div>
          
          <button class="w-full mt-3 py-3 text-blue-600 bg-blue-50 rounded-button text-sm font-medium hover:bg-blue-100 transition-colors">
            <i class="fas fa-directions mr-2"></i>
            길찾기
          </button>
        </div>
      </div>
    `;
  }

  renderTransportSection() {
    return `
      <!-- 교통 섹션 -->
      <div class="transport-section bg-white p-6 border-b border-gray-100">
        <h3 class="text-xl font-bold text-gray-900 mb-4">
          <i class="fas fa-subway text-gray-500 mr-2"></i>
          교통
        </h3>
        
        <div class="space-y-4">
          <div class="flex items-center space-x-3">
            <div class="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
              <span class="text-white text-xs font-bold">2</span>
            </div>
            <div>
              <p class="font-medium text-gray-900">강남역</p>
              <p class="text-sm text-gray-600">도보 5분 (400m)</p>
            </div>
          </div>
          
          <div class="flex items-center space-x-3">
            <div class="w-8 h-8 bg-green-600 rounded flex items-center justify-center">
              <span class="text-white text-xs font-bold">2</span>
            </div>
            <div>
              <p class="font-medium text-gray-900">역삼역</p>
              <p class="text-sm text-gray-600">도보 8분 (600m)</p>
            </div>
          </div>
          
          <div class="flex items-center space-x-3">
            <div class="w-8 h-8 bg-gray-600 rounded flex items-center justify-center">
              <i class="fas fa-bus text-white text-xs"></i>
            </div>
            <div>
              <p class="font-medium text-gray-900">버스정류장</p>
              <p class="text-sm text-gray-600">146, 301, 472번 (도보 2분)</p>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderParkingSection() {
    return `
      <!-- 주차 섹션 -->
      <div class="parking-section bg-white p-6 border-b border-gray-100">
        <h3 class="text-xl font-bold text-gray-900 mb-4">
          <i class="fas fa-car text-gray-500 mr-2"></i>
          주차
        </h3>
        
        <div class="space-y-3">
          <div class="flex items-center space-x-3">
            <i class="fas fa-check-circle text-green-500"></i>
            <span class="text-gray-900">주차 가능 (15대)</span>
          </div>
          
          <div class="bg-gray-50 p-4 rounded-button">
            <div class="space-y-2 text-sm">
              <div class="flex justify-between">
                <span class="text-gray-600">기본 요금</span>
                <span class="text-gray-900 font-medium">무료 (2시간)</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">추가 요금</span>
                <span class="text-gray-900 font-medium">시간당 2,000원</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">주차 위치</span>
                <span class="text-gray-900 font-medium">건물 지하 1층</span>
              </div>
            </div>
          </div>
          
          <p class="text-sm text-gray-600">
            <i class="fas fa-info-circle text-blue-500 mr-1"></i>
            예약 시간 2시간 전부터 주차 가능합니다.
          </p>
        </div>
      </div>
    `;
  }

  renderReservationGuideSection() {
    return `
      <!-- 예약 안내 섹션 -->
      <div class="reservation-guide-section bg-white p-6 border-b border-gray-100">
        <h3 class="text-xl font-bold text-gray-900 mb-4">
          <i class="fas fa-calendar-check text-gray-500 mr-2"></i>
          예약 안내
        </h3>
        
        <div class="space-y-4">
          <!-- 이용 시간 -->
          <div>
            <h4 class="font-medium text-gray-900 mb-2">이용 시간</h4>
            <div class="bg-gray-50 p-3 rounded-button">
              <div class="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span class="text-gray-600">평일:</span>
                  <span class="text-gray-900 ml-1">09:00~22:00</span>
                </div>
                <div>
                  <span class="text-gray-600">주말:</span>
                  <span class="text-gray-900 ml-1">10:00~24:00</span>
                </div>
              </div>
            </div>
          </div>
          
          <!-- 예약 규정 -->
          <div>
            <h4 class="font-medium text-gray-900 mb-3">예약 규정</h4>
            <div class="space-y-2 text-sm">
              <div class="flex items-start space-x-2">
                <i class="fas fa-circle text-gray-400 text-xs mt-2"></i>
                <span class="text-gray-700">최소 이용시간 2시간</span>
              </div>
              <div class="flex items-start space-x-2">
                <i class="fas fa-circle text-gray-400 text-xs mt-2"></i>
                <span class="text-gray-700">예약 취소는 이용 4시간 전까지 가능</span>
              </div>
              <div class="flex items-start space-x-2">
                <i class="fas fa-circle text-gray-400 text-xs mt-2"></i>
                <span class="text-gray-700">보증금 50% 선결제 필요</span>
              </div>
              <div class="flex items-start space-x-2">
                <i class="fas fa-circle text-gray-400 text-xs mt-2"></i>
                <span class="text-gray-700">15분 지각 시 자동 취소</span>
              </div>
            </div>
          </div>
          
          <!-- 준비사항 -->
          <div>
            <h4 class="font-medium text-gray-900 mb-3">준비사항</h4>
            <div class="bg-blue-50 p-3 rounded-button">
              <div class="space-y-1 text-sm">
                <p class="text-blue-800">
                  <i class="fas fa-qrcode mr-2"></i>
                  입장 시 예약 QR코드를 제시해 주세요
                </p>
                <p class="text-blue-700">
                  신분증 지참 필수 (대표자)
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderReviewsSection() {
    const reviews = [
      {
        id: 1,
        user: '김**',
        rating: 5,
        date: '2024.01.15',
        content: '깔끔하고 분위기가 너무 좋아요! 단체모임하기 딱이에요.',
        helpful: 12
      },
      {
        id: 2,
        user: '박**',
        rating: 4,
        date: '2024.01.10',
        content: '시설도 좋고 직원분들도 친절하세요. 주차가 편해서 좋았어요.',
        helpful: 8
      }
    ];
    
    return `
      <!-- 리뷰 섹션 -->
      <div class="reviews-section bg-white p-6">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-xl font-bold text-gray-900">
            <i class="fas fa-star text-gray-500 mr-2"></i>
            리뷰 (127)
          </h3>
          <button class="text-blue-600 text-sm font-medium">전체보기</button>
        </div>
        
        <!-- 평점 요약 -->
        <div class="bg-gray-50 p-4 rounded-button mb-4">
          <div class="flex items-center space-x-4">
            <div class="text-center">
              <div class="text-3xl font-bold text-gray-900">4.8</div>
              <div class="flex justify-center mb-1">
                ${Array.from({ length: 5 }, (_, i) => `
                  <i class="fas fa-star text-sm text-yellow-400"></i>
                `).join('')}
              </div>
              <div class="text-xs text-gray-600">127개 리뷰</div>
            </div>
            
            <div class="flex-1 space-y-1">
              ${[5,4,3,2,1].map(rating => `
                <div class="flex items-center space-x-2">
                  <span class="text-sm text-gray-600 w-2">${rating}</span>
                  <div class="flex-1 bg-gray-200 rounded-full h-2">
                    <div class="bg-yellow-400 h-2 rounded-full" style="width: ${rating === 5 ? '75%' : rating === 4 ? '20%' : '5%'}"></div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
        
        <!-- 리뷰 목록 -->
        <div class="space-y-4">
          ${reviews.map(review => `
            <div class="review-item border-b border-gray-100 pb-4 last:border-b-0">
              <div class="flex items-start justify-between mb-2">
                <div class="flex items-center space-x-2">
                  <span class="font-medium text-gray-900">${review.user}</span>
                  <div class="flex">
                    ${Array.from({ length: 5 }, (_, i) => `
                      <i class="fas fa-star text-xs ${i < review.rating ? 'text-yellow-400' : 'text-gray-300'}"></i>
                    `).join('')}
                  </div>
                </div>
                <span class="text-xs text-gray-500">${review.date}</span>
              </div>
              
              <p class="text-gray-700 text-sm mb-2">${review.content}</p>
              
              <div class="flex items-center space-x-4 text-xs text-gray-500">
                <button class="flex items-center space-x-1 hover:text-blue-600">
                  <i class="far fa-thumbs-up"></i>
                  <span>도움됨 ${review.helpful}</span>
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  renderStoreReservationCTA(store) {
    return `
      <!-- 예약하기 CTA (고정 하단) -->
      <div class="reservation-cta fixed bottom-16 left-0 right-0 bg-white border-t border-gray-200 p-4 z-20">
        <div class="flex items-center space-x-4">
          <!-- 가격 정보 -->
          <div class="flex-1">
            <div class="flex items-baseline space-x-2">
              <span class="text-2xl font-bold text-gray-900">150,000원</span>
              <span class="text-gray-600">/ 시간</span>
            </div>
            <p class="text-sm text-gray-600">최소 2시간, 보증금 50% 선결제</p>
          </div>
          
          <!-- 예약 버튼 -->
          <button 
            class="btn btn-primary px-8 py-3 font-semibold ${!store.availableToday ? 'opacity-50 cursor-not-allowed' : ''}"
            ${store.availableToday ? 'onclick="OReeApp.instance.startReservation()"' : 'disabled'}
          >
            ${store.availableToday ? '예약하기' : '예약마감'}
          </button>
        </div>
      </div>
    `;
  }

  renderReservation() {
    // 전화번호 인증 체크
    if (!this.authState.isPhoneVerified) {
      return this.renderPhoneVerificationRequired();
    }

    return `
      <div class="pb-32 bg-gray-50">
        ${this.renderReservationHeader()}
        ${this.renderReservationProgress()}
        <div class="space-y-6">
          ${this.renderDateSelection()}
          ${this.renderTimeSelection()}
          ${this.renderGuestSelection()}
          ${this.renderMemoSection()}
          ${this.renderDepositCalculation()}
          ${this.renderRefundPolicyAgreement()}
        </div>
        ${this.renderReservationCTA()}
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderPhoneVerificationRequired() {
    return `
      <div class="pb-20 bg-gray-50">
        <div class="header p-4 bg-white border-b">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('store-detail')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">예약하기</h1>
            <div></div>
          </div>
        </div>
        
        <div class="flex items-center justify-center min-h-96">
          <div class="text-center p-6">
            <div class="w-16 h-16 mx-auto bg-red-100 rounded-full flex items-center justify-center mb-4">
              <i class="fas fa-phone-slash text-2xl text-red-600"></i>
            </div>
            <h2 class="text-xl font-bold text-gray-900 mb-3">전화번호 인증이 필요합니다</h2>
            <p class="text-gray-600 mb-6 leading-relaxed">
              안전한 예약 서비스 이용을 위해<br>
              전화번호 인증을 완료해주세요
            </p>
            <div class="space-y-3">
              <button 
                class="btn btn-primary w-full"
                onclick="OReeApp.instance.navigateTo('phone-auth')"
              >
                전화번호 인증하기
              </button>
              <button 
                class="btn btn-secondary w-full"
                onclick="OReeApp.instance.navigateTo('store-detail')"
              >
                이전으로 돌아가기
              </button>
            </div>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderReservationHeader() {
    const store = this.homeState.currentStore || this.homeState.stores[0];
    
    return `
      <!-- 예약 헤더 -->
      <div class="header p-4 bg-white border-b sticky top-0 z-30">
        <div class="flex justify-between items-center">
          <button onclick="OReeApp.instance.navigateTo('store-detail')" class="text-gray-600 hover:text-gray-800 transition-colors">
            <i class="fas fa-arrow-left text-xl"></i>
          </button>
          <div class="text-center">
            <h1 class="text-lg font-semibold text-gray-900">예약하기</h1>
            <p class="text-sm text-gray-600">${store.name}</p>
          </div>
          <div class="w-6"></div> <!-- 중앙 정렬을 위한 빈 공간 -->
        </div>
      </div>
    `;
  }

  renderReservationProgress() {
    return `
      <!-- 예약 진행 단계 -->
      <div class="bg-white p-4 border-b">
        <div class="flex items-center justify-between text-sm">
          <div class="flex items-center space-x-2 text-blue-600">
            <div class="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs">1</div>
            <span class="font-medium">예약 정보 입력</span>
          </div>
          <div class="flex-1 h-px bg-gray-300 mx-3"></div>
          <div class="flex items-center space-x-2 text-gray-400">
            <div class="w-6 h-6 bg-gray-300 text-white rounded-full flex items-center justify-center text-xs">2</div>
            <span>결제</span>
          </div>
          <div class="flex-1 h-px bg-gray-300 mx-3"></div>
          <div class="flex items-center space-x-2 text-gray-400">
            <div class="w-6 h-6 bg-gray-300 text-white rounded-full flex items-center justify-center text-xs">3</div>
            <span>완료</span>
          </div>
        </div>
      </div>
    `;
  }

  renderDateSelection() {
    const today = new Date();
    const dates = this.reservationState.availableDates;
    
    return `
      <!-- 날짜 선택 -->
      <div class="bg-white p-4 mx-4 rounded-button shadow-sm">
        <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <i class="fas fa-calendar-alt text-blue-600 mr-2"></i>
          날짜 선택
        </h3>
        
        <!-- 월 네비게이션 -->
        <div class="flex items-center justify-between mb-4">
          <button class="p-2 text-gray-600 hover:text-gray-800">
            <i class="fas fa-chevron-left"></i>
          </button>
          <h4 class="text-lg font-medium text-gray-900">
            ${today.getFullYear()}년 ${today.getMonth() + 1}월
          </h4>
          <button class="p-2 text-gray-600 hover:text-gray-800">
            <i class="fas fa-chevron-right"></i>
          </button>
        </div>
        
        <!-- 요일 헤더 -->
        <div class="grid grid-cols-7 gap-1 mb-2">
          ${['일', '월', '화', '수', '목', '금', '토'].map(day => `
            <div class="text-center text-sm font-medium text-gray-500 py-2">${day}</div>
          `).join('')}
        </div>
        
        <!-- 날짜 그리드 -->
        <div class="grid grid-cols-7 gap-1">
          ${dates.map(date => `
            <button 
              class="date-btn p-2 text-sm rounded transition-colors ${date.available ? 
                (date.date === this.reservationState.selectedDate ? 
                  'bg-blue-600 text-white' : 
                  'text-gray-900 hover:bg-blue-50') : 
                'text-gray-400 cursor-not-allowed'}"
              data-date="${date.date}"
              ${!date.available ? 'disabled' : ''}
            >
              ${date.day}
            </button>
          `).join('')}
        </div>
        
        <!-- 범례 -->
        <div class="flex items-center justify-center space-x-4 mt-4 text-xs text-gray-600">
          <div class="flex items-center space-x-1">
            <div class="w-3 h-3 bg-blue-600 rounded"></div>
            <span>선택됨</span>
          </div>
          <div class="flex items-center space-x-1">
            <div class="w-3 h-3 bg-gray-100 border border-gray-300 rounded"></div>
            <span>예약가능</span>
          </div>
          <div class="flex items-center space-x-1">
            <div class="w-3 h-3 bg-gray-300 rounded"></div>
            <span>예약불가</span>
          </div>
        </div>
      </div>
    `;
  }

  renderTimeSelection() {
    return `
      <!-- 시간 선택 -->
      <div class="bg-white p-4 mx-4 rounded-button shadow-sm">
        <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <i class="fas fa-clock text-blue-600 mr-2"></i>
          시간 선택
        </h3>
        
        <div class="mb-4">
          <p class="text-sm text-gray-600 mb-3">
            <i class="fas fa-info-circle text-blue-500 mr-1"></i>
            최소 2시간 이용 (시간당 ${this.reservationState.pricePerHour.toLocaleString()}원)
          </p>
          
          <div class="grid grid-cols-4 gap-2">
            ${this.reservationState.availableTimes.map(slot => `
              <button 
                class="time-btn p-3 text-sm rounded-button border transition-colors ${slot.available ?
                  (slot.time === this.reservationState.selectedTime ?
                    'border-blue-600 bg-blue-600 text-white' :
                    'border-gray-300 text-gray-900 hover:border-blue-600') :
                  'border-gray-200 text-gray-400 cursor-not-allowed bg-gray-50'}"
                data-time="${slot.time}"
                ${!slot.available ? 'disabled' : ''}
              >
                ${slot.time}
              </button>
            `).join('')}
          </div>
        </div>
        
        ${this.reservationState.selectedTime ? `
          <div class="bg-blue-50 p-3 rounded-button">
            <div class="flex items-center justify-between text-sm">
              <span class="text-blue-800">선택된 시간</span>
              <span class="font-medium text-blue-900">${this.reservationState.selectedTime} ~ ${this.calculateEndTime()}</span>
            </div>
          </div>
        ` : ''}
      </div>
    `;
  }

  renderGuestSelection() {
    const guestError = this.reservationState.selectedGuests < 4;
    
    return `
      <!-- 인원 선택 -->
      <div class="bg-white p-4 mx-4 rounded-button shadow-sm">
        <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <i class="fas fa-users text-blue-600 mr-2"></i>
          인원 선택
        </h3>
        
        <!-- 4인 이상 안내 -->
        <div class="bg-amber-50 border border-amber-200 p-3 rounded-button mb-4">
          <div class="flex items-start space-x-2">
            <i class="fas fa-exclamation-triangle text-amber-600 mt-0.5"></i>
            <div>
              <p class="text-sm font-medium text-amber-800">단체예약 전용</p>
              <p class="text-xs text-amber-700 mt-1">4인 이상 단체만 예약 가능합니다</p>
            </div>
          </div>
        </div>
        
        <!-- 인원 카운터 -->
        <div class="flex items-center justify-between">
          <div>
            <p class="font-medium text-gray-900">이용 인원</p>
            <p class="text-sm text-gray-600">최소 4명부터 예약 가능</p>
          </div>
          
          <div class="flex items-center space-x-3">
            <button 
              class="guest-btn w-10 h-10 rounded-button border border-gray-300 flex items-center justify-center ${this.reservationState.selectedGuests <= 4 ? 'text-gray-400 cursor-not-allowed' : 'text-gray-700 hover:border-gray-400'}"
              data-action="decrease"
              ${this.reservationState.selectedGuests <= 4 ? 'disabled' : ''}
            >
              <i class="fas fa-minus"></i>
            </button>
            
            <span class="guest-count text-2xl font-bold text-gray-900 w-12 text-center">
              ${this.reservationState.selectedGuests}
            </span>
            
            <button 
              class="guest-btn w-10 h-10 rounded-button border border-gray-300 flex items-center justify-center text-gray-700 hover:border-gray-400"
              data-action="increase"
            >
              <i class="fas fa-plus"></i>
            </button>
          </div>
        </div>
        
        <!-- 인원 에러 메시지 -->
        ${guestError ? `
          <div class="mt-4 p-3 bg-red-50 border border-red-200 rounded-button">
            <div class="flex items-center space-x-2">
              <i class="fas fa-times-circle text-red-600"></i>
              <p class="text-sm font-medium text-red-800">4인 이하 예약은 불가합니다.</p>
            </div>
          </div>
        ` : ''}
      </div>
    `;
  }

  renderMemoSection() {
    return `
      <!-- 메모 (선택사항) -->
      <div class="bg-white p-4 mx-4 rounded-button shadow-sm">
        <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <i class="fas fa-edit text-blue-600 mr-2"></i>
          요청사항 
          <span class="text-sm text-gray-500 font-normal ml-2">(선택)</span>
        </h3>
        
        <textarea 
          class="w-full p-3 border border-gray-300 rounded-button resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          rows="3"
          placeholder="업장에 전달할 요청사항이 있으시면 적어주세요. (예: 생일파티, 프로젝터 사용, 특별 세팅 등)"
          data-memo-input
        >${this.reservationState.memo}</textarea>
        
        <p class="text-xs text-gray-500 mt-2">
          ⚠️ 요청사항은 업장 사정에 따라 제공되지 않을 수 있습니다.
        </p>
      </div>
    `;
  }

  renderDepositCalculation() {
    const totalAmount = this.calculateTotalAmount();
    const depositAmount = this.calculateDepositAmount();
    const remainingAmount = totalAmount - depositAmount;
    
    return `
      <!-- 보증금 계산 -->
      <div class="bg-white p-4 mx-4 rounded-button shadow-sm">
        <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <i class="fas fa-calculator text-blue-600 mr-2"></i>
          결제 정보
        </h3>
        
        <!-- 계산 내역 -->
        <div class="space-y-3">
          <div class="flex justify-between items-center text-sm">
            <span class="text-gray-600">기본 이용료 (2시간)</span>
            <span class="text-gray-900">${(this.reservationState.pricePerHour * 2).toLocaleString()}원</span>
          </div>
          
          <div class="flex justify-between items-center text-sm">
            <span class="text-gray-600">추가 인원료 (${Math.max(0, this.reservationState.selectedGuests - 10)}명)</span>
            <span class="text-gray-900">${this.calculateExtraGuestFee().toLocaleString()}원</span>
          </div>
          
          <div class="border-t pt-3">
            <div class="flex justify-between items-center">
              <span class="font-medium text-gray-900">총 이용료</span>
              <span class="text-xl font-bold text-gray-900">${totalAmount.toLocaleString()}원</span>
            </div>
          </div>
        </div>
        
        <!-- 보증금 설명 -->
        <div class="mt-4 p-4 bg-blue-50 rounded-button">
          <div class="space-y-2">
            <div class="flex justify-between items-center">
              <span class="text-blue-800 font-medium">선결제 (보증금 50%)</span>
              <span class="text-xl font-bold text-blue-900">${depositAmount.toLocaleString()}원</span>
            </div>
            <div class="flex justify-between items-center text-sm">
              <span class="text-blue-700">현장 결제</span>
              <span class="font-medium text-blue-800">${remainingAmount.toLocaleString()}원</span>
            </div>
          </div>
          
          <div class="mt-3 text-xs text-blue-700">
            <p><i class="fas fa-info-circle mr-1"></i> 보증금은 이용 시간 4시간 전까지 100% 환불 가능</p>
            <p><i class="fas fa-info-circle mr-1"></i> 나머지 금액은 현장에서 결제하시면 됩니다</p>
          </div>
        </div>
        
        <!-- 계산식 예시 -->
        <div class="mt-3 p-3 bg-gray-50 rounded text-xs text-gray-600">
          <p class="font-medium mb-1">💡 계산식 예시</p>
          <p>기본료 (${this.reservationState.pricePerHour.toLocaleString()}원 × 2시간) + 추가인원료 (10명 초과시 1명당 5,000원) = 총액</p>
          <p>보증금 = 총액 × 50%</p>
        </div>
      </div>
    `;
  }

  renderRefundPolicyAgreement() {
    return `
      <!-- 환불정책 동의 -->
      <div class="bg-white p-4 mx-4 rounded-button shadow-sm">
        <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <i class="fas fa-file-contract text-blue-600 mr-2"></i>
          이용약관 및 환불정책
        </h3>
        
        <!-- 환불정책 내용 -->
        <div class="bg-gray-50 p-4 rounded-button mb-4 text-sm">
          <div class="space-y-2">
            <div class="font-medium text-gray-900">환불정책</div>
            <div class="space-y-1 text-gray-700">
              <p>• 예약 확정 후 4시간 전 취소: 100% 환불</p>
              <p>• 예약 시간 2~4시간 전 취소: 70% 환불</p>
              <p>• 예약 시간 2시간 내 취소: 환불 불가</p>
              <p>• 노쇼(No-show): 환불 불가</p>
            </div>
            
            <div class="mt-3 pt-3 border-t">
              <div class="font-medium text-gray-900 mb-1">이용수칙</div>
              <div class="space-y-1 text-gray-700">
                <p>• 예약 시간 15분 지각 시 자동 취소</p>
                <p>• 시설 손상 시 별도 변상금 청구</p>
                <p>• 소음, 흡연 등으로 인한 피해 시 퇴장 조치</p>
                <p>• 미성년자는 보호자 동반 필수</p>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 필수 동의 체크박스 -->
        <div class="space-y-3">
          <label class="flex items-start space-x-3 cursor-pointer">
            <input 
              type="checkbox" 
              class="refund-policy-checkbox mt-1 w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              ${this.reservationState.agreeRefundPolicy ? 'checked' : ''}
            >
            <div class="text-sm">
              <span class="font-medium text-gray-900">환불정책 및 이용약관에 동의합니다</span>
              <span class="text-red-500 ml-1">*필수</span>
              <p class="text-gray-600 mt-1">위 내용을 모두 확인하였으며, 이에 동의합니다.</p>
            </div>
          </label>
        </div>
      </div>
    `;
  }

  renderReservationCTA() {
    const canProceed = this.validateReservationForm();
    const totalAmount = this.calculateTotalAmount();
    const depositAmount = this.calculateDepositAmount();
    
    return `
      <!-- 예약 확정 CTA -->
      <div class="fixed bottom-16 left-0 right-0 bg-white border-t border-gray-200 p-4 z-20">
        <div class="flex items-center space-x-3">
          <!-- 취소 버튼 -->
          <button 
            class="btn btn-secondary flex-1"
            onclick="OReeApp.instance.cancelReservation()"
          >
            취소
          </button>
          
          <!-- 결제 정보 및 버튼 -->
          <div class="flex-2 flex items-center justify-between bg-blue-50 p-3 rounded-button">
            <div class="text-right">
              <div class="text-sm text-blue-700">선결제 금액</div>
              <div class="font-bold text-blue-900">${depositAmount.toLocaleString()}원</div>
            </div>
            
            <button 
              class="btn btn-primary ml-4 px-6 ${!canProceed ? 'opacity-50 cursor-not-allowed' : ''}"
              onclick="OReeApp.instance.guardedProceedToPayment()"
              ${!canProceed ? 'disabled' : ''}
            >
              결제하기
            </button>
          </div>
        </div>
        
        ${!canProceed ? `
          <div class="mt-2 text-xs text-red-600 text-center">
            필수 정보를 모두 입력하고 약관에 동의해주세요
          </div>
        ` : ''}
      </div>
    `;
  }

  renderPayment() {
    if (this.paymentState.isProcessing) {
      return this.renderPaymentProcessing();
    }

    return `
      <div class="pb-32 bg-gray-50">
        ${this.renderPaymentHeader()}
        ${this.renderPaymentProgress()}
        <div class="space-y-6">
          ${this.renderReservationSummary()}
          ${this.renderPaymentMethods()}
          ${this.renderPaymentAmount()}
        </div>
        ${this.renderPaymentCTA()}
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderPaymentProcessing() {
    return `
      <div class="min-h-screen bg-white flex items-center justify-center">
        <div class="text-center">
          <div class="w-16 h-16 mx-auto mb-6">
            <div class="spinner border-4 border-blue-600"></div>
          </div>
          <h2 class="text-xl font-bold text-gray-900 mb-2">결제 진행 중</h2>
          <p class="text-gray-600">잠시만 기다려주세요...</p>
        </div>
      </div>
    `;
  }

  renderPaymentHeader() {
    const store = this.homeState.currentStore || this.homeState.stores[0];
    
    return `
      <!-- 결제 헤더 -->
      <div class="header p-4 bg-white border-b sticky top-0 z-30">
        <div class="flex justify-between items-center">
          <button onclick="OReeApp.instance.navigateTo('reservation')" class="text-gray-600 hover:text-gray-800 transition-colors">
            <i class="fas fa-arrow-left text-xl"></i>
          </button>
          <div class="text-center">
            <h1 class="text-lg font-semibold text-gray-900">보증금 결제</h1>
            <p class="text-sm text-gray-600">${store.name}</p>
          </div>
          <div class="w-6"></div>
        </div>
      </div>
    `;
  }

  renderPaymentProgress() {
    return `
      <!-- 결제 진행 단계 -->
      <div class="bg-white p-4 border-b">
        <div class="flex items-center justify-between text-sm">
          <div class="flex items-center space-x-2 text-gray-400">
            <div class="w-6 h-6 bg-gray-300 text-white rounded-full flex items-center justify-center text-xs">✓</div>
            <span>예약 정보 입력</span>
          </div>
          <div class="flex-1 h-px bg-gray-300 mx-3"></div>
          <div class="flex items-center space-x-2 text-blue-600">
            <div class="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs">2</div>
            <span class="font-medium">결제</span>
          </div>
          <div class="flex-1 h-px bg-gray-300 mx-3"></div>
          <div class="flex items-center space-x-2 text-gray-400">
            <div class="w-6 h-6 bg-gray-300 text-white rounded-full flex items-center justify-center text-xs">3</div>
            <span>완료</span>
          </div>
        </div>
      </div>
    `;
  }

  renderReservationSummary() {
    const store = this.homeState.currentStore || this.homeState.stores[0];
    const reservation = this.reservationState;
    
    return `
      <!-- 예약 정보 확인 -->
      <div class="bg-white p-4 mx-4 rounded-button shadow-sm">
        <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <i class="fas fa-clipboard-check text-blue-600 mr-2"></i>
          예약 정보 확인
        </h3>
        
        <div class="space-y-3">
          <div class="flex justify-between items-center">
            <span class="text-gray-600">업장명</span>
            <span class="font-medium text-gray-900">${store.name}</span>
          </div>
          
          <div class="flex justify-between items-center">
            <span class="text-gray-600">예약 날짜</span>
            <span class="font-medium text-gray-900">${this.formatReservationDate()}</span>
          </div>
          
          <div class="flex justify-between items-center">
            <span class="text-gray-600">이용 시간</span>
            <span class="font-medium text-gray-900">${reservation.selectedTime} ~ ${this.calculateEndTime()}</span>
          </div>
          
          <div class="flex justify-between items-center">
            <span class="text-gray-600">이용 인원</span>
            <span class="font-medium text-gray-900">${reservation.selectedGuests}명</span>
          </div>
          
          <div class="flex justify-between items-center">
            <span class="text-gray-600">예약자명</span>
            <span class="font-medium text-gray-900">${this.getReservationUserName()}</span>
          </div>
          
          <div class="flex justify-between items-center">
            <span class="text-gray-600">연락처</span>
            <span class="font-medium text-gray-900">${this.getReservationPhoneNumber()}</span>
          </div>
          
          ${reservation.memo ? `
            <div class="pt-3 border-t">
              <span class="text-gray-600 text-sm">요청사항</span>
              <p class="text-gray-900 text-sm mt-1">${reservation.memo}</p>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  renderPaymentMethods() {
    return `
      <!-- 결제수단 선택 -->
      <div class="bg-white p-4 mx-4 rounded-button shadow-sm">
        <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <i class="fas fa-credit-card text-blue-600 mr-2"></i>
          결제수단 선택
        </h3>
        
        <!-- 결제 방법 -->
        <div class="space-y-3">
          <!-- 신용카드/체크카드 -->
          <label class="payment-method block cursor-pointer">
            <div class="flex items-center justify-between p-3 border-2 ${this.paymentState.selectedMethod === 'card' ? 'border-blue-600 bg-blue-50' : 'border-gray-200'} rounded-button transition-colors">
              <div class="flex items-center space-x-3">
                <input 
                  type="radio" 
                  name="paymentMethod" 
                  value="card"
                  class="payment-method-radio"
                  ${this.paymentState.selectedMethod === 'card' ? 'checked' : ''}
                >
                <div>
                  <p class="font-medium text-gray-900">신용카드 / 체크카드</p>
                  <p class="text-sm text-gray-600">안전한 카드 결제</p>
                </div>
              </div>
              <div class="flex space-x-2">
                <img src="https://via.placeholder.com/32x20/0066cc/ffffff?text=V" alt="Visa" class="w-8 h-5 rounded">
                <img src="https://via.placeholder.com/32x20/eb001b/ffffff?text=M" alt="Master" class="w-8 h-5 rounded">
              </div>
            </div>
          </label>
          
          <!-- 페이북 -->
          <label class="payment-method block cursor-pointer">
            <div class="flex items-center justify-between p-3 border-2 ${this.paymentState.selectedMethod === 'paybook' ? 'border-blue-600 bg-blue-50' : 'border-gray-200'} rounded-button transition-colors">
              <div class="flex items-center space-x-3">
                <input 
                  type="radio" 
                  name="paymentMethod" 
                  value="paybook"
                  class="payment-method-radio"
                  ${this.paymentState.selectedMethod === 'paybook' ? 'checked' : ''}
                >
                <div>
                  <p class="font-medium text-gray-900">페이북</p>
                  <p class="text-sm text-gray-600">간편 계좌 결제</p>
                </div>
              </div>
              <div class="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
                <span class="text-white text-xs font-bold">PB</span>
              </div>
            </div>
          </label>
          
          <!-- 카카오페이 -->
          <label class="payment-method block cursor-pointer">
            <div class="flex items-center justify-between p-3 border-2 ${this.paymentState.selectedMethod === 'kakaopay' ? 'border-blue-600 bg-blue-50' : 'border-gray-200'} rounded-button transition-colors">
              <div class="flex items-center space-x-3">
                <input 
                  type="radio" 
                  name="paymentMethod" 
                  value="kakaopay"
                  class="payment-method-radio"
                  ${this.paymentState.selectedMethod === 'kakaopay' ? 'checked' : ''}
                >
                <div>
                  <p class="font-medium text-gray-900">카카오페이</p>
                  <p class="text-sm text-gray-600">카카오톡 간편결제</p>
                </div>
              </div>
              <div class="w-8 h-8 bg-yellow-400 rounded flex items-center justify-center">
                <span class="text-black text-xs font-bold">K</span>
              </div>
            </div>
          </label>
          
          <!-- 네이버페이 -->
          <label class="payment-method block cursor-pointer">
            <div class="flex items-center justify-between p-3 border-2 ${this.paymentState.selectedMethod === 'naverpay' ? 'border-blue-600 bg-blue-50' : 'border-gray-200'} rounded-button transition-colors">
              <div class="flex items-center space-x-3">
                <input 
                  type="radio" 
                  name="paymentMethod" 
                  value="naverpay"
                  class="payment-method-radio"
                  ${this.paymentState.selectedMethod === 'naverpay' ? 'checked' : ''}
                >
                <div>
                  <p class="font-medium text-gray-900">네이버페이</p>
                  <p class="text-sm text-gray-600">네이버 간편결제</p>
                </div>
              </div>
              <div class="w-8 h-8 bg-green-500 rounded flex items-center justify-center">
                <span class="text-white text-xs font-bold">N</span>
              </div>
            </div>
          </label>
        </div>
        
        <!-- 카드 정보 입력 (카드 선택 시에만) -->
        ${this.paymentState.selectedMethod === 'card' ? `
          <div class="mt-4 pt-4 border-t border-gray-200">
            <div class="space-y-3">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">카드번호</label>
                <input 
                  type="text" 
                  placeholder="0000-0000-0000-0000"
                  class="card-number-input w-full p-3 border border-gray-300 rounded-button focus:outline-none focus:ring-2 focus:ring-blue-500"
                  maxlength="19"
                >
              </div>
              
              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">유효기간</label>
                  <input 
                    type="text" 
                    placeholder="MM/YY"
                    class="card-expiry-input w-full p-3 border border-gray-300 rounded-button focus:outline-none focus:ring-2 focus:ring-blue-500"
                    maxlength="5"
                  >
                </div>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-1">CVC</label>
                  <input 
                    type="password" 
                    placeholder="000"
                    class="card-cvc-input w-full p-3 border border-gray-300 rounded-button focus:outline-none focus:ring-2 focus:ring-blue-500"
                    maxlength="3"
                  >
                </div>
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">카드 소유자명</label>
                <input 
                  type="text" 
                  placeholder="홍길동"
                  class="card-holder-input w-full p-3 border border-gray-300 rounded-button focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
              </div>
              
              <!-- 카드 저장 옵션 -->
              <label class="flex items-center space-x-2 cursor-pointer">
                <input 
                  type="checkbox" 
                  class="save-card-checkbox w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                  ${this.paymentState.saveCard ? 'checked' : ''}
                >
                <span class="text-sm text-gray-700">다음에도 사용할 수 있도록 카드 정보 저장</span>
              </label>
            </div>
          </div>
        ` : ''}
      </div>
    `;
  }

  renderPaymentAmount() {
    const totalAmount = this.calculateTotalAmount();
    const depositAmount = this.calculateDepositAmount();
    const remainingAmount = totalAmount - depositAmount;
    
    return `
      <!-- 결제 금액 -->
      <div class="bg-white p-4 mx-4 rounded-button shadow-sm">
        <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <i class="fas fa-won-sign text-blue-600 mr-2"></i>
          결제 금액
        </h3>
        
        <div class="space-y-3">
          <!-- 총 이용 금액 -->
          <div class="bg-gray-50 p-4 rounded-button">
            <div class="flex justify-between items-center mb-2">
              <span class="text-gray-600">총 이용 금액</span>
              <span class="font-medium text-gray-900">${totalAmount.toLocaleString()}원</span>
            </div>
            <div class="text-xs text-gray-500">
              기본 ${this.reservationState.minimumHours}시간 + 추가인원료 포함
            </div>
          </div>
          
          <!-- 결제 구분 -->
          <div class="space-y-2">
            <div class="flex justify-between items-center">
              <div class="flex items-center space-x-2">
                <span class="w-3 h-3 bg-blue-600 rounded-full"></span>
                <span class="text-blue-800 font-medium">지금 결제 (보증금 50%)</span>
              </div>
              <span class="text-xl font-bold text-blue-900">${depositAmount.toLocaleString()}원</span>
            </div>
            
            <div class="flex justify-between items-center">
              <div class="flex items-center space-x-2">
                <span class="w-3 h-3 bg-gray-400 rounded-full"></span>
                <span class="text-gray-600">현장 결제</span>
              </div>
              <span class="font-medium text-gray-900">${remainingAmount.toLocaleString()}원</span>
            </div>
          </div>
          
          <!-- 주의사항 -->
          <div class="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-button">
            <div class="flex items-start space-x-2">
              <i class="fas fa-exclamation-triangle text-amber-600 text-sm mt-0.5"></i>
              <div class="text-sm">
                <p class="font-medium text-amber-800 mb-1">결제 안내</p>
                <ul class="space-y-1 text-amber-700">
                  <li>• 보증금 결제 후 예약이 확정됩니다</li>
                  <li>• 나머지 금액은 현장에서 결제해주세요</li>
                  <li>• 환불 시에는 환불정책이 적용됩니다</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderPaymentCTA() {
    const depositAmount = this.calculateDepositAmount();
    const isValidPayment = this.validatePaymentForm();
    
    return `
      <!-- 결제하기 CTA -->
      <div class="fixed bottom-16 left-0 right-0 bg-white border-t border-gray-200 p-4 z-20">
        <div class="flex items-center space-x-3">
          <!-- 취소 버튼 -->
          <button 
            class="btn btn-secondary flex-1"
            onclick="OReeApp.instance.cancelPayment()"
          >
            취소
          </button>
          
          <!-- 결제 버튼 -->
          <div class="flex-2 flex items-center justify-between">
            <div class="text-right mr-4">
              <div class="text-sm text-gray-600">결제 금액</div>
              <div class="text-lg font-bold text-blue-900">${depositAmount.toLocaleString()}원</div>
            </div>
            
            <button 
              class="btn btn-primary px-6 py-3 font-semibold ${!isValidPayment ? 'opacity-50 cursor-not-allowed' : ''}"
              onclick="OReeApp.instance.processPayment()"
              ${!isValidPayment ? 'disabled' : ''}
            >
              결제 진행
            </button>
          </div>
        </div>
        
        ${!isValidPayment ? `
          <div class="mt-2 text-xs text-red-600 text-center">
            ${this.paymentState.selectedMethod === 'card' ? '카드 정보를 모두 입력해주세요' : '결제수단을 선택해주세요'}
          </div>
        ` : ''}
      </div>
    `;
  }

  renderBookingComplete() {
    const bookingId = this.generateBookingId();
    const reservation = this.reservationState;
    const store = this.homeState.currentStore || this.homeState.stores[0];
    
    return `
      <div class="pb-20 bg-gray-50">
        <!-- 예약 완료 헤더 -->
        <div class="header p-4 bg-white border-b">
          <div class="flex justify-between items-center">
            <div></div>
            <h1 class="text-lg font-semibold text-gray-900">예약 완료</h1>
            <button onclick="OReeApp.instance.navigateTo('home')" class="text-gray-600">
              <i class="fas fa-times text-xl"></i>
            </button>
          </div>
        </div>
        
        <!-- 완료 메시지 -->
        <div class="text-center py-12 bg-white">
          <div class="w-20 h-20 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-6">
            <i class="fas fa-check text-3xl text-green-600"></i>
          </div>
          
          <h2 class="text-2xl font-bold text-gray-900 mb-3">예약이 완료되었습니다!</h2>
          <p class="text-gray-600 mb-2">보증금 결제가 완료되어 예약이 확정되었습니다.</p>
          <p class="text-sm text-gray-500">예약번호: ${bookingId}</p>
        </div>
        
        <!-- 예약 상세 정보 -->
        <div class="bg-white p-4 mx-4 rounded-button shadow-sm mb-6">
          <h3 class="text-lg font-semibold text-gray-900 mb-4">예약 상세</h3>
          
          <div class="space-y-3">
            <div class="flex items-center space-x-3">
              <i class="fas fa-store text-blue-600 w-5"></i>
              <div>
                <p class="font-medium text-gray-900">${store.name}</p>
                <p class="text-sm text-gray-600">${store.location}</p>
              </div>
            </div>
            
            <div class="flex items-center space-x-3">
              <i class="fas fa-calendar text-blue-600 w-5"></i>
              <div>
                <p class="font-medium text-gray-900">${this.formatReservationDate()}</p>
                <p class="text-sm text-gray-600">${reservation.selectedTime} ~ ${this.calculateEndTime()} (2시간)</p>
              </div>
            </div>
            
            <div class="flex items-center space-x-3">
              <i class="fas fa-users text-blue-600 w-5"></i>
              <div>
                <p class="font-medium text-gray-900">${reservation.selectedGuests}명</p>
                <p class="text-sm text-gray-600">예약자: ${this.getReservationUserName()}</p>
              </div>
            </div>
            
            <div class="flex items-center space-x-3">
              <i class="fas fa-won-sign text-blue-600 w-5"></i>
              <div>
                <p class="font-medium text-gray-900">보증금 ${this.calculateDepositAmount().toLocaleString()}원 결제완료</p>
                <p class="text-sm text-gray-600">현장 결제: ${(this.calculateTotalAmount() - this.calculateDepositAmount()).toLocaleString()}원</p>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 중요 안내사항 -->
        <div class="bg-white p-4 mx-4 rounded-button shadow-sm mb-6">
          <h3 class="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <i class="fas fa-exclamation-circle text-orange-500 mr-2"></i>
            중요 안내사항
          </h3>
          
          <div class="space-y-4">
            <!-- 인원 변경 정책 -->
            <div class="p-4 bg-red-50 border border-red-200 rounded-button">
              <div class="flex items-start space-x-3">
                <i class="fas fa-users text-red-600 mt-1"></i>
                <div>
                  <p class="font-medium text-red-800 mb-1">인원 변경 필수 안내</p>
                  <p class="text-sm text-red-700 leading-relaxed">
                    <strong>3일 전까지 인원 변경 필수</strong><br>
                    미 변경 시 보증금 소멸되니 반드시 확인해주세요
                  </p>
                  <button 
                    class="text-red-600 text-sm font-medium mt-2 underline"
                    onclick="OReeApp.instance.showRefundPolicyDetail()"
                  >
                    자세히 보기 →
                  </button>
                </div>
              </div>
            </div>
            
            <!-- 입장 안내 -->
            <div class="p-4 bg-blue-50 border border-blue-200 rounded-button">
              <div class="flex items-start space-x-3">
                <i class="fas fa-qrcode text-blue-600 mt-1"></i>
                <div>
                  <p class="font-medium text-blue-800 mb-1">입장 시 필요사항</p>
                  <ul class="text-sm text-blue-700 space-y-1">
                    <li>• 예약 QR코드 제시 (마이페이지에서 확인)</li>
                    <li>• 예약자 신분증 지참</li>
                    <li>• 예약 시간 15분 전 도착 권장</li>
                  </ul>
                </div>
              </div>
            </div>
            
            <!-- 연락처 안내 -->
            <div class="p-4 bg-gray-50 border border-gray-200 rounded-button">
              <div class="flex items-start space-x-3">
                <i class="fas fa-phone text-gray-600 mt-1"></i>
                <div>
                  <p class="font-medium text-gray-800 mb-1">업장 연락처</p>
                  <p class="text-sm text-gray-700">02-1234-5678</p>
                  <p class="text-xs text-gray-600 mt-1">문의사항이나 급한 변경은 직접 연락해주세요</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 액션 버튼들 -->
        <div class="px-4 space-y-3">
          <button 
            class="btn btn-primary w-full"
            onclick="OReeApp.instance.navigateTo('my')"
          >
            내 예약 확인하기
          </button>
          
          <button 
            class="btn btn-secondary w-full"
            onclick="OReeApp.instance.navigateTo('home')"
          >
            홈으로 돌아가기
          </button>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderQR() {
    // QR 진입시 즉시 생성
    if (!this.qrState.currentQR || this.isQRExpired()) {
      this.generateNewQR();
    }
    
    const remainingTime = this.getRemainingTime();
    const progressPercent = (remainingTime / (this.qrState.validityMinutes * 60)) * 100;
    
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('my')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">현장 인증 QR</h1>
            <button onclick="OReeApp.instance.refreshQR()" class="text-blue-600">
              <i class="fas fa-sync-alt ${this.qrState.isGenerating ? 'fa-spin' : ''}"></i>
            </button>
          </div>
        </div>
        
        <div class="p-4">
          <!-- QR 코드 및 PIN -->
          <div class="text-center mb-6">
            <!-- 유효시간 표시 -->
            <div class="mb-4">
              <div class="flex items-center justify-center space-x-2 mb-2">
                <i class="fas fa-clock text-blue-600"></i>
                <span class="text-sm font-medium text-blue-600">
                  유효시간: ${Math.floor(remainingTime / 60)}분 ${remainingTime % 60}초
                </span>
              </div>
              <div class="w-full bg-gray-200 rounded-full h-2">
                <div 
                  class="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full transition-all duration-1000" 
                  style="width: ${progressPercent}%"
                ></div>
              </div>
            </div>
            
            <!-- QR 코드 -->
            <div class="w-64 h-64 mx-auto bg-white border-2 border-gray-200 rounded-button flex items-center justify-center mb-4 shadow-lg">
              ${this.qrState.currentQR ? this.renderQRPattern() : this.renderLoadingQR()}
            </div>
            
            <!-- PIN 코드 -->
            <div class="card p-4 bg-blue-50 border border-blue-200 mb-4">
              <h3 class="text-sm font-medium text-blue-900 mb-2">백업 PIN 코드</h3>
              <div class="text-3xl font-bold text-blue-600 tracking-wider">
                ${this.qrState.currentPIN || '----'}
              </div>
              <p class="text-xs text-blue-700 mt-1">QR 인식이 안 될 경우 사용</p>
            </div>
            
            <p class="text-sm text-gray-600">사장님께 위 QR 또는 PIN을 보여주세요</p>
          </div>
          
          <!-- 현장 절차 안내 -->
          <div class="card p-4 mb-6">
            <h3 class="font-semibold text-gray-900 mb-4">
              <i class="fas fa-list-ol text-green-600 mr-2"></i>
              현장 절차 안내
            </h3>
            
            <div class="space-y-4">
              <div class="flex items-start space-x-3">
                <div class="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span class="text-xs font-bold text-green-600">1</span>
                </div>
                <div class="text-sm">
                  <p class="font-medium text-gray-900">QR/PIN 제시</p>
                  <p class="text-gray-600">사장님께 생성된 QR 또는 PIN 코드를 보여주세요</p>
                </div>
              </div>
              
              <div class="flex items-start space-x-3">
                <div class="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span class="text-xs font-bold text-green-600">2</span>
                </div>
                <div class="text-sm">
                  <p class="font-medium text-gray-900">정보 상호 확인</p>
                  <p class="text-gray-600">사장님과 최종 결제금액, 최종 인원을 서로 확인하세요</p>
                </div>
              </div>
              
              <div class="flex items-start space-x-3">
                <div class="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span class="text-xs font-bold text-green-600">3</span>
                </div>
                <div class="text-sm">
                  <p class="font-medium text-gray-900">사장님 대시보드 입력</p>
                  <p class="text-gray-600">사장님 대시보드에서 총 인원/총 결제금액 입력 → 사용자 프로필에 적립금 계산 반영</p>
                </div>
              </div>
              
              <div class="flex items-start space-x-3">
                <div class="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span class="text-xs font-bold text-green-600">4</span>
                </div>
                <div class="text-sm">
                  <p class="font-medium text-gray-900">보증금 반환 요청</p>
                  <p class="text-gray-600">보증금 반환은 사장님에게 직접 요청하세요</p>
                </div>
              </div>
              
              <div class="flex items-start space-x-3">
                <div class="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span class="text-xs font-bold text-green-600">5</span>
                </div>
                <div class="text-sm">
                  <p class="font-medium text-gray-900">현장 결제</p>
                  <p class="text-gray-600">현장 결제는 업장에 직접 결제하세요</p>
                </div>
              </div>
            </div>
          </div>
          
          <!-- 하단 요약 안내 -->
          <div class="space-y-3">
            <div class="card p-3 bg-blue-50 border border-blue-200">
              <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                  <i class="fas fa-shield-alt text-blue-600"></i>
                  <span class="text-sm font-medium text-blue-900">환불정책</span>
                </div>
                <button 
                  onclick="OReeApp.instance.navigateTo('refund-policy')"
                  class="text-xs text-blue-700 underline"
                >
                  자세히 보기
                </button>
              </div>
              <p class="text-xs text-blue-800 mt-1">3일전 100% → 1일전 50% → 당일 0%</p>
            </div>
            
            <div class="card p-3 bg-green-50 border border-green-200">
              <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                  <i class="fas fa-coins text-green-600"></i>
                  <span class="text-sm font-medium text-green-900">보증금</span>
                </div>
                <span class="text-xs font-bold text-green-800">${this.getActiveBooking()?.depositAmount?.toLocaleString() || '0'}원</span>
              </div>
              <p class="text-xs text-green-800 mt-1">현장 확인 후 사장님께 반환 요청</p>
            </div>
            
            <div class="card p-3 bg-orange-50 border border-orange-200">
              <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                  <i class="fas fa-credit-card text-orange-600"></i>
                  <span class="text-sm font-medium text-orange-900">현장 결제</span>
                </div>
                <span class="text-xs font-bold text-orange-800">업장 직접 결제</span>
              </div>
              <p class="text-xs text-orange-800 mt-1">총 금액에서 보증금을 제외한 나머지 금액</p>
            </div>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderWishlist() {
    const filteredStores = this.getFilteredWishlistStores();
    
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="text-center">
            <h1 class="text-2xl font-bold text-gray-900">ORee</h1>
          </div>
        </div>
        
        <!-- 카테고리 탭 -->
        <div class="px-4 mb-4">
          <div class="flex space-x-1 bg-gray-100 rounded-button p-1">
            ${this.wishlistState.categories.map(category => `
              <button
                class="flex-1 py-2 px-3 rounded-button text-sm font-medium transition-colors ${
                  this.wishlistState.selectedCategory === category.id
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }"
                onclick="OReeApp.instance.switchWishlistCategory('${category.id}')"
              >
                <i class="${category.icon} mr-1"></i>
                ${category.name}
              </button>
            `).join('')}
          </div>
        </div>
        
        <!-- 2열 카드 그리드 -->
        <div class="px-4">
          ${filteredStores.length > 0 ? `
            <div class="grid grid-cols-2 gap-4">
              ${filteredStores.map(store => this.renderWishlistCard(store)).join('')}
            </div>
          ` : `
            <div class="text-center py-12">
              <i class="fas fa-heart text-4xl text-gray-300 mb-4"></i>
              <h3 class="text-lg font-semibold text-gray-600 mb-2">찜한 업장이 없습니다</h3>
              <p class="text-sm text-gray-500 mb-6">
                ${this.wishlistState.selectedCategory === 'all' ? '마음에 드는 업장을' : `${this.getCategoryName()}을`} 찜해보세요
              </p>
              <button 
                class="btn btn-primary btn-sm"
                onclick="OReeApp.instance.navigateTo('home')"
              >
                업장 둘러보기
              </button>
            </div>
          `}
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderWishlistCard(store) {
    return `
      <div 
        class="card p-3 hover:shadow-md transition-shadow cursor-pointer relative"
        onclick="OReeApp.instance.viewStoreDetail(${store.id})"
      >
        <!-- 이미지 -->
        <div class="w-full h-32 bg-gray-200 rounded-button mb-3 overflow-hidden">
          <img 
            src="${store.image}" 
            alt="${store.name}" 
            class="w-full h-full object-cover"
            onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
          >
          <div class="w-full h-full bg-gray-200 rounded-button items-center justify-center hidden">
            <i class="fas fa-image text-gray-400"></i>
          </div>
        </div>
        
        <!-- 찜 버튼 -->
        <div class="absolute top-5 right-5">
          <button 
            class="w-8 h-8 bg-white bg-opacity-90 rounded-full flex items-center justify-center shadow-sm hover:bg-opacity-100"
            onclick="OReeApp.instance.toggleWishlist(${store.id}, event)"
          >
            <i class="fas fa-heart text-red-500 text-sm"></i>
          </button>
        </div>
        
        <!-- 정보 -->
        <div class="space-y-1">
          <h3 class="font-semibold text-gray-900 text-sm leading-tight line-clamp-1">${store.name}</h3>
          <p class="text-xs text-gray-600">${store.category}</p>
          
          <div class="flex items-center justify-between mt-2">
            <div class="flex items-center space-x-1">
              <i class="fas fa-star text-yellow-500 text-xs"></i>
              <span class="text-xs font-medium text-gray-700">${store.rating}</span>
            </div>
            <div class="flex items-center space-x-1">
              <i class="fas fa-users text-gray-400 text-xs"></i>
              <span class="text-xs text-gray-500">${store.capacity.split('-')[0]}+명</span>
            </div>
          </div>
          
          <div class="flex items-center justify-between mt-1">
            <span class="text-xs text-blue-600 font-medium">${store.priceRange}</span>
            <span class="text-xs text-gray-500">${store.distance}</span>
          </div>
        </div>
      </div>
    `;
  }

  // STEP 12: 찜 관리 메서드들
  getFilteredWishlistStores() {
    // 찜한 업장 중에서 카테고리에 맞는 것들만 반환
    const wishlistedStores = this.homeState.stores.filter(store => 
      this.homeState.userWishlist.includes(store.id)
    );
    
    if (this.wishlistState.selectedCategory === 'all') {
      return wishlistedStores;
    }
    
    return wishlistedStores.filter(store => 
      store.categoryType === this.wishlistState.selectedCategory
    );
  }

  switchWishlistCategory(categoryId) {
    this.wishlistState.selectedCategory = categoryId;
    this.render();
  }

  getCategoryName() {
    const category = this.wishlistState.categories.find(
      cat => cat.id === this.wishlistState.selectedCategory
    );
    return category ? category.name : '전체';
  }

  viewStoreDetail(storeId) {
    const store = this.homeState.stores.find(s => s.id === storeId);
    if (store) {
      this.homeState.currentStore = store;
      this.navigateTo('store-detail');
    }
  }

  toggleWishlist(storeId, event) {
    if (event) {
      event.stopPropagation(); // 카드 클릭 이벤트 전파 방지
    }
    
    const index = this.homeState.userWishlist.indexOf(storeId);
    if (index > -1) {
      // 찜 해제
      this.homeState.userWishlist.splice(index, 1);
      this.showToast('찜 목록에서 제거되었습니다');
    } else {
      // 찜 추가
      this.homeState.userWishlist.push(storeId);
      this.showToast('찜 목록에 추가되었습니다');
    }
    
    // 로컬스토리지에 저장
    this.saveUserWishlist();
    
    // 현재 화면이 찜 목록이면 re-render
    if (this.currentScreen === 'wishlist') {
      this.render();
    }
  }

  renderMy() {
    return `
      <div class="pb-20">
        ${this.renderMyHeader()}
        ${this.renderPremiumBanner()}
        ${this.renderPointsOverview()}
        ${this.renderReservationStatus()}
        ${this.renderUsageHistory()}
        ${this.renderSubscriptionManagement()}
        ${this.renderPhoneVerification()}
        ${this.renderNotificationSettings()}
        ${this.renderRevenueStructureLink()}
        ${this.renderWithdrawalPopup()}
        ${this.renderBottomNav()}
      </div>
    `;
  }
  
  // 마이페이지 헤더 (오리 레벨 + 프리미엄 멤버십)
  renderMyHeader() {
    const currentLevel = this.getCurrentDuckLevel();
    const nextLevel = this.getNextDuckLevel();
    const { currentStats } = this.myPageState.duckLevel;
    const { premiumMembership } = this.myPageState;
    
    return `
      <div class="header p-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div class="flex items-center justify-between mb-4">
          <h1 class="text-xl font-semibold">마이페이지</h1>
          <button class="text-white/80 hover:text-white" onclick="OReeApp.instance.openSettingsMenu()">
            <i class="fas fa-cog text-xl"></i>
          </button>
        </div>
        
        <!-- 오리 레벨 프로필 카드 -->
        <div class="bg-white/10 backdrop-blur-sm rounded-xl p-4">
          <div class="flex items-center space-x-4">
            <!-- 오리 아바타 + 프리미엄 배지 -->
            <div class="relative">
              <div class="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center text-3xl relative">
                ${currentLevel.emoji}
                <!-- 레벨업 가능 표시 -->
                ${this.checkLevelUpConditions() ? `
                  <div class="absolute -top-1 -right-1 w-5 h-5 bg-yellow-400 rounded-full flex items-center justify-center animate-pulse">
                    <i class="fas fa-star text-yellow-800 text-xs"></i>
                  </div>
                ` : ''}
              </div>
              
              <!-- 프리미엄 금배지 -->
              ${premiumMembership.isActive ? `
                <div class="absolute -bottom-1 -right-1 w-6 h-6 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center border-2 border-white shadow-lg">
                  <i class="fas fa-crown text-white text-xs"></i>
                </div>
              ` : ''}
            </div>
            
            <div class="flex-1">
              <div class="flex items-center space-x-2 mb-1">
                <h3 class="text-lg font-semibold">${this.user?.name || '사용자'}</h3>
                <span class="bg-white/20 px-2 py-0.5 rounded text-xs font-medium">
                  ${currentLevel.name}
                </span>
                <!-- 프리미엄 배지 텍스트 -->
                ${premiumMembership.isActive ? `
                  <span class="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-2 py-0.5 rounded text-xs font-bold">
                    👑 PREMIUM
                  </span>
                ` : ''}
              </div>
              
              <!-- 적립률 표시 (프리미엄 반영) -->
              <div class="flex items-center space-x-2 mb-2">
                ${premiumMembership.isActive ? `
                  <span class="text-white text-sm font-semibold">적립률 8%</span>
                  <span class="bg-yellow-400/30 text-yellow-200 px-2 py-0.5 rounded text-xs font-medium">
                    +3% 프리미엄 보너스
                  </span>
                ` : `
                  <span class="text-white/80 text-sm">적립률 ${(1 + currentLevel.bonusRate).toFixed(1)}%</span>
                  ${currentLevel.bonusRate > 0 ? `
                    <span class="bg-yellow-400/20 text-yellow-200 px-2 py-0.5 rounded text-xs">
                      +${currentLevel.bonusRate.toFixed(1)}% 보너스
                    </span>
                  ` : ''}
                `}
              </div>
              
              <!-- 진행 상황 -->
              <div class="text-xs text-white/80 space-y-1">
                <div class="flex items-center space-x-4">
                  <span>👥 누적인원 ${currentStats.totalGuests}명</span>
                  <span>💰 매출 ${(currentStats.totalRevenue / 10000).toFixed(0)}만원</span>
                </div>
                <div class="flex items-center space-x-4">
                  <span>🏆 완료모임 ${currentStats.completedMeetings}회</span>
                  ${this.authState.isPhoneVerified 
                    ? '<span class="text-green-300"><i class="fas fa-check-circle mr-1"></i>인증완료</span>'
                    : '<span class="text-red-300"><i class="fas fa-exclamation-circle mr-1"></i>미인증</span>'
                  }
                </div>
              </div>
            </div>
          </div>
          
          <!-- 레벨업 버튼 (조건 충족 시) -->
          ${this.checkLevelUpConditions() && nextLevel ? `
            <div class="mt-4 pt-4 border-t border-white/20">
              <button class="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-white py-3 px-4 rounded-xl font-semibold hover:shadow-lg transition-all duration-200 animate-pulse" 
                      onclick="OReeApp.instance.levelUp()">
                <div class="flex items-center justify-center space-x-2">
                  <span>${nextLevel.emoji}</span>
                  <span>${currentLevel.name} → ${nextLevel.name} 레벨업!</span>
                  <i class="fas fa-arrow-up"></i>
                </div>
              </button>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }
  
  // 프리미엄 멤버십 가입 유도 배너
  renderPremiumBanner() {
    const { premiumMembership } = this.myPageState;
    
    if (premiumMembership.isActive) return '';
    
    return `
      <div class="px-4 pt-4">
        <div class="bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl p-4 text-white relative overflow-hidden">
          <div class="flex items-center justify-between relative z-10">
            <div class="flex-1">
              <div class="flex items-center space-x-2 mb-1">
                <i class="fas fa-crown text-yellow-300"></i>
                <h4 class="font-bold">프리미엄 멤버십</h4>
              </div>
              <p class="text-white/90 text-sm mb-2">
                월 ${premiumMembership.monthlyFee.toLocaleString()}원으로 ${premiumMembership.bonusRate}% 추가 적립!
              </p>
              <button class="bg-white text-purple-600 px-4 py-2 rounded-full text-sm font-semibold hover:bg-white/90 transition-colors" 
                      onclick="OReeApp.instance.showPremiumSubscription()">
                지금 가입하기
              </button>
            </div>
            <div class="text-right">
              <div class="text-2xl font-bold mb-1">+${premiumMembership.bonusRate}%</div>
              <div class="text-xs text-white/80">적립 부스터</div>
            </div>
          </div>
          <div class="absolute -top-4 -right-4 w-20 h-20 bg-white/10 rounded-full"></div>
          <div class="absolute -bottom-2 -left-2 w-12 h-12 bg-white/10 rounded-full"></div>
        </div>
      </div>
    `;
  }
  
  // 오리 레벨 & 미션 시스템
  renderPointsOverview() {
    const { pointsStatus } = this.myPageState;
    const currentLevel = this.getCurrentDuckLevel();
    const nextLevel = this.getNextDuckLevel();
    const levelProgress = this.getDuckLevelProgress();
    const missions = this.getCurrentMissions();
    
    return `
      <div class="px-4 pt-4">
        <div class="card p-0 overflow-hidden">
          <!-- 레벨 & 미션 헤더 -->
          <div class="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border-b">
            <div class="flex items-center justify-between mb-3">
              <h3 class="text-lg font-semibold text-gray-900">오리 레벨 & 미션</h3>
              <div class="flex items-center space-x-2">
                <span class="text-2xl">${currentLevel.emoji}</span>
                <span class="text-sm font-medium text-gray-700">${currentLevel.name}</span>
              </div>
            </div>
            
            ${nextLevel ? `
              <!-- 다음 레벨 진행상황 -->
              <div class="mb-4">
                <div class="flex items-center justify-between text-sm text-gray-600 mb-2">
                  <span>다음 레벨: ${nextLevel.name}</span>
                  <span>${nextLevel.emoji}</span>
                </div>
                
                <!-- 미션 진행 상황 -->
                ${missions.length > 0 ? `
                  <div class="space-y-2">
                    ${missions.slice(0, 2).map(mission => {
                      const progress = (mission.current / mission.target) * 100;
                      return `
                        <div class="bg-white/60 rounded-lg p-2">
                          <div class="flex items-center justify-between text-xs text-gray-600 mb-1">
                            <span>${mission.icon} ${mission.title}</span>
                            <span>${mission.current}/${mission.target}</span>
                          </div>
                          <div class="w-full bg-gray-200 rounded-full h-1.5">
                            <div class="bg-gradient-to-r from-blue-500 to-purple-500 h-1.5 rounded-full transition-all duration-300" 
                                 style="width: ${Math.min(progress, 100)}%"></div>
                          </div>
                        </div>
                      `;
                    }).join('')}
                    
                    ${missions.length > 2 ? `
                      <button class="w-full text-xs text-blue-600 hover:text-blue-800 py-1" 
                              onclick="OReeApp.instance.showAllMissions()">
                        미션 ${missions.length}개 모두 보기 <i class="fas fa-chevron-right ml-1"></i>
                      </button>
                    ` : ''}
                  </div>
                ` : `
                  <div class="text-center py-2">
                    <p class="text-sm text-gray-500">모든 미션을 완료했습니다!</p>
                    <button class="mt-2 text-sm text-yellow-600 font-medium" onclick="OReeApp.instance.levelUp()">
                      🎉 레벨업하기
                    </button>
                  </div>
                `}
              </div>
            ` : `
              <!-- 최고 레벨 달성 -->
              <div class="text-center py-4">
                <div class="text-3xl mb-2">👑</div>
                <p class="text-sm font-medium text-gray-900 mb-1">최고 레벨 달성!</p>
                <p class="text-xs text-gray-600">모든 혜택을 누리고 계십니다</p>
              </div>
            `}
            
            <!-- 현재 레벨 혜택 -->
            <div class="bg-white/80 rounded-lg p-3">
              <h4 class="text-sm font-semibold text-gray-900 mb-2">현재 레벨 혜택</h4>
              <div class="flex flex-wrap gap-1">
                ${currentLevel.benefits.map(benefit => `
                  <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                    ${benefit}
                  </span>
                `).join('')}
              </div>
            </div>
          </div>
          
          <!-- 적립 현황 -->
          <div class="p-4">
            <h4 class="text-sm font-semibold text-gray-900 mb-3">나의 적립현황</h4>
            
            <div class="grid grid-cols-2 gap-4 mb-4">
              <div class="text-center">
                <div class="text-2xl font-bold text-blue-600 mb-1">
                  ${pointsStatus.totalPoints.toLocaleString()}
                </div>
                <div class="text-xs text-gray-600">전체 적립포인트</div>
              </div>
              <div class="text-center">
                <div class="text-2xl font-bold text-green-600 mb-1">
                  ${pointsStatus.withdrawablePoints.toLocaleString()}
                </div>
                <div class="text-xs text-gray-600">인출가능포인트</div>
              </div>
            </div>
            
            <!-- 상세 현황 -->
            <div class="grid grid-cols-3 gap-4 mb-4 text-center">
              <div>
                <div class="text-lg font-semibold text-gray-900 mb-1">
                  ${pointsStatus.reservationCount}
                </div>
                <div class="text-xs text-gray-600">예약건수</div>
              </div>
              <div>
                <div class="text-lg font-semibold text-gray-900 mb-1">
                  ${pointsStatus.totalGuests}
                </div>
                <div class="text-xs text-gray-600">총 예약인원</div>
              </div>
              <div>
                <div class="text-lg font-semibold text-orange-600 mb-1">
                  ${pointsStatus.pendingPoints.toLocaleString()}
                </div>
                <div class="text-xs text-gray-600">미확정포인트</div>
              </div>
            </div>
            
            <!-- 출금 버튼 -->
            <button class="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-200" 
                    onclick="OReeApp.instance.openWithdrawalPopup()">
              <i class="fas fa-money-bill-wave mr-2"></i>
              출금신청 (${pointsStatus.withdrawablePoints.toLocaleString()}P)
            </button>
          </div>
        </div>
      </div>
    `;
  }

  // 나의 예약현황
  renderReservationStatus() {
    const { reservations } = this.myPageState;
    const activeReservations = reservations.filter(r => r.status !== 'cancelled');
    
    return `
      <div class="px-4 pt-4">
        <div class="card p-4">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-900">나의 예약현황</h3>
            <span class="text-sm text-gray-600">${activeReservations.length}건</span>
          </div>
          
          ${activeReservations.length > 0 ? `
            <div class="space-y-3">
              ${activeReservations.map(reservation => `
                <div class="border border-gray-200 rounded-lg p-3">
                  <div class="flex items-start justify-between">
                    <div class="flex-1">
                      <h4 class="font-medium text-gray-900 mb-1">${reservation.storeName}</h4>
                      <div class="text-sm text-gray-600 space-y-1">
                        <div class="flex items-center space-x-4">
                          <span><i class="fas fa-calendar mr-1"></i>${reservation.date}</span>
                          <span><i class="fas fa-clock mr-1"></i>${reservation.time}</span>
                          <span><i class="fas fa-users mr-1"></i>${reservation.guests}명</span>
                        </div>
                        <div class="flex items-center space-x-4">
                          <span><i class="fas fa-won-sign mr-1"></i>${reservation.amount.toLocaleString()}원</span>
                          ${reservation.earnedPoints > 0 
                            ? `<span class="text-green-600"><i class="fas fa-coins mr-1"></i>+${reservation.earnedPoints}P</span>`
                            : '<span class="text-orange-600"><i class="fas fa-clock mr-1"></i>적립대기</span>'
                          }
                        </div>
                      </div>
                    </div>
                    <div class="flex flex-col space-y-1">
                      <span class="text-xs px-2 py-1 rounded-full ${
                        reservation.status === 'confirmed' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      }">
                        ${reservation.status === 'confirmed' ? '확정' : '대기'}
                      </span>
                    </div>
                  </div>
                  
                  <div class="flex space-x-2 mt-3">
                    <button class="flex-1 bg-gray-100 text-gray-700 py-2 px-3 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors" 
                            onclick="OReeApp.instance.modifyReservation('${reservation.id}')">
                      <i class="fas fa-edit mr-1"></i>예약변경
                    </button>
                    <button class="flex-1 bg-red-50 text-red-600 py-2 px-3 rounded-lg text-sm font-medium hover:bg-red-100 transition-colors" 
                            onclick="OReeApp.instance.cancelReservation('${reservation.id}')">
                      <i class="fas fa-times mr-1"></i>예약취소
                    </button>
                  </div>
                </div>
              `).join('')}
            </div>
            
            <button class="w-full mt-4 text-blue-600 text-sm font-medium py-2 hover:bg-blue-50 rounded-lg transition-colors" 
                    onclick="OReeApp.instance.viewAllReservations()">
              전체 예약내역 보기 <i class="fas fa-chevron-right ml-1"></i>
            </button>
          ` : `
            <div class="text-center py-8 text-gray-500">
              <i class="fas fa-calendar-plus text-3xl mb-3"></i>
              <p class="text-sm">예약 내역이 없습니다</p>
              <button class="mt-3 text-blue-600 text-sm font-medium hover:underline" 
                      onclick="OReeApp.instance.navigateTo('home')">
                지금 예약하기
              </button>
            </div>
          `}
        </div>
      </div>
    `;
  }
  
  // 지난 이용내역
  renderUsageHistory() {
    const { usageHistory } = this.myPageState;
    
    return `
      <div class="px-4 pt-4">
        <div class="card p-4">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-900">지난 이용내역</h3>
            <span class="text-sm text-gray-600">${usageHistory.length}건</span>
          </div>
          
          ${usageHistory.length > 0 ? `
            <div class="space-y-3">
              ${usageHistory.slice(0, 2).map(history => `
                <div class="border border-gray-200 rounded-lg p-3">
                  <div class="flex items-start justify-between">
                    <div class="flex-1">
                      <h4 class="font-medium text-gray-900 mb-1">${history.storeName}</h4>
                      <div class="text-sm text-gray-600 space-y-1">
                        <div class="flex items-center space-x-4">
                          <span><i class="fas fa-calendar mr-1"></i>${history.date}</span>
                          <span><i class="fas fa-users mr-1"></i>${history.guests}명</span>
                        </div>
                        <div class="flex items-center space-x-4">
                          <span><i class="fas fa-won-sign mr-1"></i>${history.amount.toLocaleString()}원</span>
                          <span class="text-green-600"><i class="fas fa-coins mr-1"></i>+${history.earnedPoints}P</span>
                        </div>
                      </div>
                    </div>
                    <div class="flex flex-col items-end space-y-1">
                      <div class="flex items-center space-x-1">
                        <span class="text-yellow-500">★</span>
                        <span class="text-sm font-medium">${history.rating}</span>
                      </div>
                      <button class="text-xs text-blue-600 hover:underline" 
                              onclick="OReeApp.instance.writeReview('${history.id}')">
                        리뷰쓰기
                      </button>
                    </div>
                  </div>
                </div>
              `).join('')}
            </div>
            
            <button class="w-full mt-4 text-blue-600 text-sm font-medium py-2 hover:bg-blue-50 rounded-lg transition-colors" 
                    onclick="OReeApp.instance.viewAllHistory()">
              전체 이용내역 보기 <i class="fas fa-chevron-right ml-1"></i>
            </button>
          ` : `
            <div class="text-center py-6 text-gray-500">
              <i class="fas fa-history text-2xl mb-2"></i>
              <p class="text-sm">이용 내역이 없습니다</p>
            </div>
          `}
        </div>
      </div>
    `;
  }
  
  // 구독 관리 (STEP 16 강화)
  renderSubscriptionManagement() {
    const { premiumMembership } = this.myPageState;
    
    return `
      <div class="px-4 pt-4">
        <div class="card p-4">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-900">구독 관리</h3>
            <i class="fas fa-crown ${premiumMembership.isActive ? 'text-yellow-500' : 'text-purple-500'}"></i>
          </div>
          
          ${premiumMembership.isActive ? `
            <!-- 프리미엄 멤버 활성 상태 -->
            <div class="bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-200 rounded-xl p-5">
              <!-- 상태 헤더 -->
              <div class="flex items-center justify-between mb-4">
                <div class="flex items-center space-x-3">
                  <div class="w-10 h-10 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                    <i class="fas fa-crown text-white"></i>
                  </div>
                  <div>
                    <div class="font-bold text-purple-900">프리미엄 멤버</div>
                    <div class="text-sm text-purple-700">8% 적립률 적용 중</div>
                  </div>
                </div>
                <span class="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold animate-pulse">
                  ✓ 활성
                </span>
              </div>
              
              <!-- 구독 정보 -->
              <div class="bg-white/50 rounded-lg p-3 mb-4">
                <div class="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <div class="text-gray-600">월 구독료</div>
                    <div class="font-semibold text-gray-900">5,500원</div>
                  </div>
                  <div>
                    <div class="text-gray-600">다음 결제일</div>
                    <div class="font-semibold text-gray-900">
                      ${premiumMembership.nextBillingDate ? new Date(premiumMembership.nextBillingDate).toLocaleDateString('ko-KR') : '2024.09.15'}
                    </div>
                  </div>
                </div>
              </div>
              
              <!-- 혜택 목록 -->
              <div class="space-y-2 text-sm text-purple-800 mb-4">
                <h4 class="font-semibold text-purple-900 mb-2">🎁 현재 이용 중인 혜택</h4>
                ${premiumMembership.benefits.map(benefit => `
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-check-circle text-green-600"></i>
                    <span>${benefit}</span>
                  </div>
                `).join('')}
              </div>
              
              <!-- 관리 버튼 -->
              <div class="flex space-x-2">
                <button class="flex-1 bg-gradient-to-r from-purple-500 to-purple-600 text-white py-3 px-4 rounded-lg text-sm font-semibold hover:shadow-lg transition-all duration-200" 
                        onclick="OReeApp.instance.manageBilling()">
                  <i class="fas fa-credit-card mr-2"></i>결제 관리
                </button>
                <button class="flex-1 bg-white border-2 border-red-200 text-red-600 py-3 px-4 rounded-lg text-sm font-semibold hover:bg-red-50 transition-colors" 
                        onclick="OReeApp.instance.showCancelSubscriptionDialog()">
                  <i class="fas fa-times-circle mr-2"></i>해지하기
                </button>
              </div>
              
              <div class="mt-3 text-center">
                <p class="text-xs text-purple-600">
                  📱 해지 후에도 잔여 기간 동안 프리미엄 혜택이 유지됩니다
                </p>
              </div>
            </div>
          ` : `
            <!-- 프리미엄 미가입 상태 -->
            <div class="text-center py-6">
              <div class="w-20 h-20 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-crown text-purple-400 text-2xl"></i>
              </div>
              <h4 class="font-bold text-gray-900 mb-2">프리미엄 멤버십</h4>
              <p class="text-sm text-gray-600 mb-4">
                8% 적립률과 프리미엄 혜택을<br>
                월 5,500원으로 누려보세요
              </p>
              
              <!-- 간단 혜택 미리보기 -->
              <div class="bg-gray-50 rounded-lg p-3 mb-4 text-left">
                <div class="space-y-2 text-xs text-gray-700">
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-percentage text-purple-500 w-4"></i>
                    <span>8% 적립률 (기본 5%에서 +3%)</span>
                  </div>
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-star text-purple-500 w-4"></i>
                    <span>우선 예약권</span>
                  </div>
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-medal text-purple-500 w-4"></i>
                    <span>프리미엄 배지</span>
                  </div>
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-headset text-purple-500 w-4"></i>
                    <span>전용 고객센터</span>
                  </div>
                </div>
              </div>
              
              <button class="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 px-6 rounded-xl text-sm font-bold hover:shadow-lg transition-all duration-200" 
                      onclick="OReeApp.instance.showPremiumPaymentPopup()">
                <i class="fas fa-crown mr-2"></i>
                7일 무료로 시작하기
              </button>
              
              <div class="mt-2">
                <p class="text-xs text-gray-500">
                  7일 무료 체험 • 언제든 해지 가능
                </p>
              </div>
            </div>
          `}
        </div>
      </div>
    `;
  }
  
  // 전화번호 인증 상태
  renderPhoneVerification() {
    const isVerified = this.authState.isPhoneVerified;
    
    return `
      <div class="px-4 pt-4">
        <div class="card p-4">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-900">전화번호 인증</h3>
            <div class="flex items-center space-x-2">
              <div class="w-3 h-3 rounded-full ${isVerified ? 'bg-green-500' : 'bg-red-500'}"></div>
              <span class="text-sm ${isVerified ? 'text-green-600' : 'text-red-600'}">
                ${isVerified ? '인증완료' : '미인증'}
              </span>
            </div>
          </div>
          
          ${isVerified ? `
            <div class="flex items-center space-x-3 p-3 bg-green-50 border border-green-200 rounded-lg">
              <i class="fas fa-check-circle text-green-600"></i>
              <div class="flex-1">
                <p class="text-sm text-green-800 font-medium">전화번호 인증이 완료되었습니다</p>
                <p class="text-xs text-green-600 mt-1">
                  ${this.authState.phoneNumber || '010-****-****'}
                </p>
              </div>
              <button class="text-green-600 hover:text-green-700" 
                      onclick="OReeApp.instance.changePhoneNumber()">
                <i class="fas fa-edit"></i>
              </button>
            </div>
          ` : `
            <div class="space-y-3">
              <div class="flex items-start space-x-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                <i class="fas fa-exclamation-circle text-red-600 mt-0.5"></i>
                <div class="flex-1">
                  <p class="text-sm text-red-800 font-medium">전화번호 인증이 필요합니다</p>
                  <p class="text-xs text-red-600 mt-1">
                    예약, QR코드 생성 등의 서비스 이용을 위해<br>
                    전화번호 인증을 완료해주세요.
                  </p>
                </div>
              </div>
              
              <button class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors" 
                      onclick="OReeApp.instance.navigateTo('phone-auth')">
                <i class="fas fa-mobile-alt mr-2"></i>
                지금 인증하기
              </button>
            </div>
          `}
        </div>
      </div>
    `;
  }
  
  // 수익 구조 안내 링크
  renderRevenueStructureLink() {
    return `
      <div class="px-4 pt-4 pb-4">
        <div class="card p-4">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-900">수익 정보</h3>
            <i class="fas fa-chart-line text-blue-500"></i>
          </div>
          
          <div class="space-y-3">
            <button class="w-full flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg hover:from-blue-100 hover:to-indigo-100 transition-colors" 
                    onclick="OReeApp.instance.navigateTo('revenue-structure')">
              <div class="flex items-center space-x-3">
                <i class="fas fa-info-circle text-blue-600"></i>
                <div class="text-left">
                  <h4 class="font-medium text-gray-900">포인트 & 수익 구조</h4>
                  <p class="text-xs text-blue-600">적립률, 수수료 정책 안내</p>
                </div>
              </div>
              <i class="fas fa-chevron-right text-blue-400"></i>
            </button>
            
            <!-- 간단 요약 정보 -->
            <div class="bg-gray-50 rounded-lg p-3">
              <div class="grid grid-cols-2 gap-3 text-center text-sm">
                <div>
                  <div class="text-lg font-bold text-green-600">5%</div>
                  <div class="text-xs text-gray-600">기본 적립률</div>
                </div>
                <div>
                  <div class="text-lg font-bold text-purple-600">8%</div>
                  <div class="text-xs text-gray-600">프리미엄 적립률</div>
                </div>
              </div>
              <div class="text-center mt-2">
                <button class="text-xs text-blue-600 hover:underline" 
                        onclick="OReeApp.instance.navigateTo('revenue-structure')">
                  자세한 정책 보기 <i class="fas fa-external-link-alt ml-1"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // 알림 설정
  renderNotificationSettings() {
    const { notificationSettings } = this.myPageState;
    
    return `
      <div class="px-4 pt-4 pb-4">
        <div class="card p-4">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-900">알림 설정</h3>
            <i class="fas fa-bell text-blue-500"></i>
          </div>
          
          <div class="space-y-3">
            ${Object.entries({
              reservationConfirm: '예약 확정 알림',
              promotionNews: '프로모션 소식',
              pointsUpdate: '포인트 적립 알림',
              levelUpdate: '레벨 업 알림',
              withdrawalComplete: '출금 완료 알림',
              marketingConsent: '마케팅 수신 동의'
            }).map(([key, label]) => `
              <div class="flex items-center justify-between py-2">
                <span class="text-sm text-gray-700">${label}</span>
                <label class="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" 
                         class="sr-only peer" 
                         ${notificationSettings[key] ? 'checked' : ''}
                         onchange="OReeApp.instance.toggleNotification('${key}')">
                  <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer 
                             peer-checked:after:translate-x-full peer-checked:after:border-white 
                             after:content-[''] after:absolute after:top-[2px] after:left-[2px] 
                             after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all 
                             peer-checked:bg-blue-600"></div>
                </label>
              </div>
            `).join('')}
          </div>
          
          <div class="mt-4 pt-4 border-t border-gray-200">
            <button class="w-full text-gray-600 text-sm py-2 hover:text-gray-800 transition-colors" 
                    onclick="OReeApp.instance.resetNotificationSettings()">
              <i class="fas fa-undo mr-2"></i>
              기본값으로 초기화
            </button>
          </div>
        </div>
      </div>
    `;
  }

  // 출금신청 슬라이드 팝업
  renderWithdrawalPopup() {
    if (!this.myPageState.showWithdrawalPopup) return '';
    
    const { withdrawalInfo, pointsStatus } = this.myPageState;
    const maskedSSN = withdrawalInfo.socialSecurityNumber 
      ? (withdrawalInfo.showSSN 
          ? withdrawalInfo.socialSecurityNumber 
          : `${withdrawalInfo.socialSecurityNumber.substring(0, 6)}-${withdrawalInfo.socialSecurityNumber.substring(7, 8)}******`)
      : '';
    
    return `
      <div class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end" onclick="OReeApp.instance.closeWithdrawalPopup()">
        <div class="bg-white w-full rounded-t-3xl max-h-[90vh] overflow-y-auto" onclick="event.stopPropagation()">
          <!-- 헤더 -->
          <div class="flex items-center justify-between p-4 border-b">
            <h3 class="text-lg font-semibold text-gray-900">출금신청</h3>
            <button class="text-gray-400 hover:text-gray-600" onclick="OReeApp.instance.closeWithdrawalPopup()">
              <i class="fas fa-times text-xl"></i>
            </button>
          </div>
          
          <!-- 출금 가능 금액 -->
          <div class="p-4 bg-blue-50 border-b">
            <div class="text-center">
              <div class="text-sm text-blue-600 mb-1">출금 가능 포인트</div>
              <div class="text-2xl font-bold text-blue-900">
                ${pointsStatus.withdrawablePoints.toLocaleString()}P
              </div>
              <div class="text-xs text-blue-600 mt-1">
                (${pointsStatus.withdrawablePoints.toLocaleString()}원)
              </div>
            </div>
          </div>
          
          <div class="p-4 space-y-4">
            <!-- 출금 금액 입력 -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">출금 금액</label>
              <div class="relative">
                <input type="number" 
                       id="withdrawalAmount"
                       class="w-full p-3 border border-gray-300 rounded-lg text-right"
                       placeholder="0"
                       max="${pointsStatus.withdrawablePoints}"
                       onchange="OReeApp.instance.updateWithdrawalAmount(this.value)">
                <span class="absolute right-3 top-3 text-gray-500">원</span>
              </div>
              <div class="flex justify-between mt-2 text-xs text-gray-500">
                <span>최소 출금: 10,000원</span>
                <button class="text-blue-600 hover:underline" 
                        onclick="document.getElementById('withdrawalAmount').value = '${pointsStatus.withdrawablePoints}'; OReeApp.instance.updateWithdrawalAmount('${pointsStatus.withdrawablePoints}')">
                  전액
                </button>
              </div>
            </div>
            
            <!-- 계좌 정보 -->
            <div class="space-y-3">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">은행명</label>
                <select class="w-full p-3 border border-gray-300 rounded-lg" 
                        onchange="OReeApp.instance.updateBankInfo('bankName', this.value)">
                  <option value="">은행을 선택하세요</option>
                  <option value="KB국민은행" ${withdrawalInfo.bankName === 'KB국민은행' ? 'selected' : ''}>KB국민은행</option>
                  <option value="신한은행" ${withdrawalInfo.bankName === '신한은행' ? 'selected' : ''}>신한은행</option>
                  <option value="우리은행" ${withdrawalInfo.bankName === '우리은행' ? 'selected' : ''}>우리은행</option>
                  <option value="하나은행" ${withdrawalInfo.bankName === '하나은행' ? 'selected' : ''}>하나은행</option>
                  <option value="NH농협은행" ${withdrawalInfo.bankName === 'NH농협은행' ? 'selected' : ''}>NH농협은행</option>
                  <option value="IBK기업은행" ${withdrawalInfo.bankName === 'IBK기업은행' ? 'selected' : ''}>IBK기업은행</option>
                </select>
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">계좌번호</label>
                <input type="text" 
                       class="w-full p-3 border border-gray-300 rounded-lg"
                       placeholder="계좌번호를 입력하세요"
                       value="${withdrawalInfo.accountNumber}"
                       onchange="OReeApp.instance.updateBankInfo('accountNumber', this.value)">
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">예금주명</label>
                <input type="text" 
                       class="w-full p-3 border border-gray-300 rounded-lg"
                       placeholder="예금주명을 입력하세요"
                       value="${withdrawalInfo.accountHolder}"
                       onchange="OReeApp.instance.updateBankInfo('accountHolder', this.value)">
              </div>
              
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">주민번호 (원천징수용)</label>
                <div class="relative">
                  <input type="${withdrawalInfo.showSSN ? 'text' : 'password'}" 
                         class="w-full p-3 border border-gray-300 rounded-lg pr-12"
                         placeholder="주민번호를 입력하세요"
                         value="${withdrawalInfo.showSSN ? withdrawalInfo.socialSecurityNumber : maskedSSN}"
                         onchange="OReeApp.instance.updateBankInfo('socialSecurityNumber', this.value)">
                  <button class="absolute right-3 top-3 text-gray-500 hover:text-gray-700" 
                          onclick="OReeApp.instance.toggleSSNVisibility()">
                    <i class="fas ${withdrawalInfo.showSSN ? 'fa-eye-slash' : 'fa-eye'}"></i>
                  </button>
                </div>
              </div>
            </div>
            
            <!-- 저장 옵션 -->
            <div class="flex items-center space-x-2">
              <input type="checkbox" 
                     id="rememberInfo"
                     class="rounded border-gray-300"
                     ${withdrawalInfo.rememberInfo ? 'checked' : ''}
                     onchange="OReeApp.instance.toggleRememberInfo()">
              <label for="rememberInfo" class="text-sm text-gray-700">저장정보 기억하기</label>
            </div>
            
            <!-- 안내사항 -->
            <div class="bg-gray-50 p-4 rounded-lg">
              <h4 class="text-sm font-semibold text-gray-900 mb-2">출금 안내사항</h4>
              <ul class="text-xs text-gray-600 space-y-1">
                <li>• 출금 신청은 평일 오후 3시까지 가능합니다</li>
                <li>• 출금 처리는 <strong>다음 주 목요일</strong>에 일괄 진행됩니다</li>
                <li>• 출금 시 3.3% 원천징수가 적용됩니다</li>
                <li>• 연 소득 2천만원 초과 시 종합소득세 신고 대상입니다</li>
                <li>• 출금 수수료는 건당 500원입니다</li>
              </ul>
            </div>
            
            <!-- 출금 신청 버튼 -->
            <div class="space-y-3 pt-4">
              <button class="w-full bg-blue-600 text-white py-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors" 
                      onclick="OReeApp.instance.submitWithdrawal()">
                <i class="fas fa-paper-plane mr-2"></i>
                출금 신청하기
              </button>
              
              <button class="w-full bg-gray-100 text-gray-600 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors" 
                      onclick="OReeApp.instance.closeWithdrawalPopup()">
                취소
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  
  // 출금 팝업 관련 메서드들
  openWithdrawalPopup() {
    this.myPageState.showWithdrawalPopup = true;
    this.render();
  }
  
  closeWithdrawalPopup() {
    this.myPageState.showWithdrawalPopup = false;
    this.render();
  }
  
  updateWithdrawalAmount(amount) {
    this.myPageState.withdrawalAmount = parseInt(amount) || 0;
  }
  
  updateBankInfo(field, value) {
    this.myPageState.withdrawalInfo[field] = value;
  }
  
  toggleSSNVisibility() {
    this.myPageState.withdrawalInfo.showSSN = !this.myPageState.withdrawalInfo.showSSN;
    this.render();
  }
  
  toggleRememberInfo() {
    this.myPageState.withdrawalInfo.rememberInfo = !this.myPageState.withdrawalInfo.rememberInfo;
  }
  
  submitWithdrawal() {
    // 출금 신청 처리 로직
    alert('출금 신청이 완료되었습니다. 다음 주 목요일에 입금 예정입니다.');
    this.closeWithdrawalPopup();
  }
  
  // 프리미엄 멤버십 관련 메서드들
  showPremiumSubscription() {
    alert('프리미엄 멤버십 가입 페이지로 이동합니다.');
  }
  
  // 구독 해지 다이얼로그 (STEP 16)
  showCancelSubscriptionDialog() {
    const cancelDialog = `
      <div class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" onclick="this.remove()">
        <div class="bg-white w-full max-w-md rounded-xl overflow-hidden" onclick="event.stopPropagation()">
          <!-- 헤더 -->
          <div class="bg-red-50 border-b border-red-200 p-4 text-center">
            <div class="text-3xl mb-2">😢</div>
            <h3 class="text-lg font-semibold text-red-900">구독을 해지하시겠습니까?</h3>
            <p class="text-sm text-red-700 mt-1">정말로 프리미엄 혜택을 포기하시겠어요?</p>
          </div>
          
          <div class="p-4">
            <!-- 해지 시 잃게 되는 혜택 -->
            <div class="mb-4">
              <h4 class="font-semibold text-gray-900 mb-3">❌ 해지 시 잃게 되는 혜택</h4>
              <div class="space-y-2 text-sm text-gray-600">
                <div class="flex items-center space-x-2">
                  <i class="fas fa-times text-red-500 w-4"></i>
                  <span>8% → 5% 적립률 하향 (3% 손실)</span>
                </div>
                <div class="flex items-center space-x-2">
                  <i class="fas fa-times text-red-500 w-4"></i>
                  <span>우선 예약권 상실</span>
                </div>
                <div class="flex items-center space-x-2">
                  <i class="fas fa-times text-red-500 w-4"></i>
                  <span>프리미엄 배지 제거</span>
                </div>
                <div class="flex items-center space-x-2">
                  <i class="fas fa-times text-red-500 w-4"></i>
                  <span>전용 고객센터 이용 불가</span>
                </div>
              </div>
            </div>
            
            <!-- 해지 안내 -->
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
              <h4 class="font-semibold text-blue-900 mb-2">📋 해지 안내사항</h4>
              <div class="space-y-1 text-xs text-blue-800">
                <div>• 해지 즉시 프리미엄 혜택이 중단됩니다</div>
                <div>• 잔여 기간에 대한 환불은 불가능합니다</div>
                <div>• 언제든 다시 가입하실 수 있습니다</div>
                <div>• 해지 후에도 기존 적립 포인트는 유지됩니다</div>
              </div>
            </div>
            
            <!-- 대안 제안 -->
            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
              <h4 class="font-semibold text-yellow-900 mb-2">💡 잠시만요!</h4>
              <p class="text-xs text-yellow-800">
                해지 대신 <strong>일시정지</strong>를 고려해보세요.<br>
                최대 3개월까지 결제를 일시정지할 수 있습니다.
              </p>
            </div>
            
            <!-- 버튼 -->
            <div class="space-y-3">
              <button class="w-full bg-yellow-500 text-white py-3 px-4 rounded-lg text-sm font-semibold hover:bg-yellow-600 transition-colors" 
                      onclick="OReeApp.instance.pauseSubscription(); this.parentElement.parentElement.parentElement.remove();">
                <i class="fas fa-pause mr-2"></i>일시정지 (최대 3개월)
              </button>
              
              <button class="w-full bg-red-500 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-red-600 transition-colors" 
                      onclick="OReeApp.instance.cancelSubscription(); this.parentElement.parentElement.parentElement.remove();">
                <i class="fas fa-times mr-2"></i>구독 해지하기
              </button>
              
              <button class="w-full border border-gray-300 text-gray-600 py-2 px-4 rounded-lg text-sm hover:bg-gray-50 transition-colors" 
                      onclick="this.parentElement.parentElement.parentElement.remove()">
                취소
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', cancelDialog);
  }
  
  pauseSubscription() {
    alert('구독 일시정지가 완료되었습니다. 3개월 후 자동으로 재개됩니다.');
  }
  
  cancelSubscription() {
    // 해지 처리
    this.myPageState.premiumMembership.isActive = false;
    this.myPageState.premiumMembership.cancelDate = new Date().toISOString();
    
    // 해지 완료 토스트
    const cancelToast = document.createElement('div');
    cancelToast.className = `
      fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 
      bg-gray-800 text-white p-4 rounded-xl shadow-2xl z-50 max-w-sm w-full mx-4 text-center
    `;
    
    cancelToast.innerHTML = `
      <div class="text-2xl mb-2">📱</div>
      <h3 class="font-semibold mb-1">구독 해지 완료</h3>
      <p class="text-sm text-gray-300">프리미엄 멤버십이 해지되었습니다</p>
      <p class="text-xs text-gray-400 mt-1">언제든 다시 가입하실 수 있습니다</p>
    `;
    
    document.body.appendChild(cancelToast);
    
    setTimeout(() => {
      cancelToast.style.opacity = '0';
      setTimeout(() => {
        document.body.removeChild(cancelToast);
      }, 300);
    }, 3000);
    
    this.render();
  }
  
  manageBilling() {
    const billingPopup = `
      <div class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" onclick="this.remove()">
        <div class="bg-white w-full max-w-md rounded-xl overflow-hidden" onclick="event.stopPropagation()">
          <div class="flex items-center justify-between p-4 border-b">
            <h3 class="text-lg font-semibold text-gray-900">결제 관리</h3>
            <button class="text-gray-400 hover:text-gray-600" onclick="this.parentElement.parentElement.parentElement.remove()">
              <i class="fas fa-times text-xl"></i>
            </button>
          </div>
          
          <div class="p-4 space-y-4">
            <div>
              <h4 class="font-semibold text-gray-900 mb-2">현재 결제 정보</h4>
              <div class="bg-gray-50 rounded-lg p-3">
                <div class="flex justify-between text-sm">
                  <span class="text-gray-600">결제 수단</span>
                  <span class="font-medium">**** **** **** 1234</span>
                </div>
                <div class="flex justify-between text-sm mt-1">
                  <span class="text-gray-600">다음 결제일</span>
                  <span class="font-medium">2024.09.15</span>
                </div>
                <div class="flex justify-between text-sm mt-1">
                  <span class="text-gray-600">결제 금액</span>
                  <span class="font-medium">월 5,500원</span>
                </div>
              </div>
            </div>
            
            <div class="space-y-2">
              <button class="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <span class="text-sm font-medium">결제 수단 변경</span>
                <i class="fas fa-chevron-right text-gray-400"></i>
              </button>
              
              <button class="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <span class="text-sm font-medium">결제 내역 확인</span>
                <i class="fas fa-chevron-right text-gray-400"></i>
              </button>
              
              <button class="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <span class="text-sm font-medium">영수증 다운로드</span>
                <i class="fas fa-chevron-right text-gray-400"></i>
              </button>
            </div>
            
            <div class="text-xs text-gray-500 text-center">
              결제는 앱스토어/구글플레이를 통해 처리됩니다
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', billingPopup);
  }
  
  // 예약 관련 메서드들
  modifyReservation(reservationId) {
    alert(`예약 ${reservationId} 변경 페이지로 이동합니다.`);
  }
  
  cancelReservation(reservationId) {
    if (confirm('정말로 예약을 취소하시겠습니까?')) {
      alert(`예약 ${reservationId}이 취소되었습니다.`);
    }
  }
  
  viewAllReservations() {
    alert('전체 예약내역 페이지로 이동합니다.');
  }
  
  viewAllHistory() {
    alert('전체 이용내역 페이지로 이동합니다.');
  }
  
  writeReview(historyId) {
    alert(`${historyId} 리뷰 작성 페이지로 이동합니다.`);
  }
  
  // 전화번호 인증 관련 메서드들
  changePhoneNumber() {
    if (confirm('전화번호를 변경하시겠습니까?')) {
      this.navigateTo('phone-auth');
    }
  }
  
  // 알림 설정 관련 메서드들
  toggleNotification(type) {
    this.myPageState.notificationSettings[type] = !this.myPageState.notificationSettings[type];
  }
  
  resetNotificationSettings() {
    if (confirm('알림 설정을 기본값으로 초기화하시겠습니까?')) {
      this.myPageState.notificationSettings = {
        reservationConfirm: true,
        promotionNews: true,
        pointsUpdate: true,
        levelUpdate: true,
        withdrawalComplete: true,
        marketingConsent: false
      };
      this.render();
    }
  }
  
  // 오리 레벨 시스템 유틸리티 메서드들 (STEP 14)
  getCurrentDuckLevel() {
    return this.duckLevelSystem.levels[this.myPageState.duckLevel.current];
  }
  
  getNextDuckLevel() {
    const currentLevel = this.myPageState.duckLevel.current;
    const levelOrder = ['starter_egg', 'baby_duck', 'leader_duck', 'black_duck', 'golden_duck'];
    const currentIndex = levelOrder.indexOf(currentLevel);
    
    if (currentIndex < levelOrder.length - 1) {
      return this.duckLevelSystem.levels[levelOrder[currentIndex + 1]];
    }
    return null; // 최고 레벨
  }
  
  checkLevelUpConditions() {
    const currentStats = this.myPageState.duckLevel.currentStats;
    const nextLevel = this.getNextDuckLevel();
    
    if (!nextLevel) return false;
    
    const req = nextLevel.requirements;
    return (
      currentStats.totalGuests >= req.totalGuests &&
      currentStats.totalRevenue >= req.totalRevenue &&
      currentStats.totalReservations >= req.totalReservations &&
      currentStats.consecutiveNoShows >= req.consecutiveNoShows &&
      currentStats.completedMeetings >= req.completedMeetings
    );
  }
  
  levelUp() {
    if (this.checkLevelUpConditions()) {
      const currentLevel = this.getCurrentDuckLevel();
      const nextLevel = this.getNextDuckLevel();
      
      this.myPageState.duckLevel.current = nextLevel.id;
      
      // 레벨업 축하 토스트
      this.showLevelUpToast(currentLevel, nextLevel);
      
      // 프로필 일러스트 변경 및 적립률 보너스 반영
      this.render();
      
      return true;
    }
    return false;
  }
  
  showLevelUpToast(fromLevel, toLevel) {
    const toast = document.createElement('div');
    toast.className = `
      fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 
      bg-gradient-to-r from-yellow-400 to-orange-500 text-white p-6 rounded-xl 
      shadow-2xl z-50 max-w-sm w-full mx-4 animate-bounce
    `;
    
    toast.innerHTML = `
      <div class="text-center">
        <div class="text-4xl mb-2">${toLevel.emoji}</div>
        <h3 class="text-lg font-bold mb-1">레벨 업!</h3>
        <p class="text-sm mb-2">${fromLevel.name} → ${toLevel.name}</p>
        <p class="text-xs opacity-90">${toLevel.description}</p>
        <div class="mt-3 text-xs">
          <span class="bg-white/20 px-2 py-1 rounded-full">
            적립률 ${1 + toLevel.bonusRate}% 달성!
          </span>
        </div>
      </div>
    `;
    
    document.body.appendChild(toast);
    
    // 3초 후 토스트 제거
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => {
        document.body.removeChild(toast);
      }, 300);
    }, 3000);
  }
  
  getDuckLevelProgress() {
    const nextLevel = this.getNextDuckLevel();
    if (!nextLevel) return { isMaxLevel: true };
    
    const currentStats = this.myPageState.duckLevel.currentStats;
    const req = nextLevel.requirements;
    
    // 각 요구사항별 진행률 계산
    const progress = {};
    
    if (req.totalGuests > 0) {
      progress.totalGuests = {
        current: currentStats.totalGuests,
        required: req.totalGuests,
        percentage: Math.min((currentStats.totalGuests / req.totalGuests) * 100, 100)
      };
    }
    
    if (req.totalRevenue > 0) {
      progress.totalRevenue = {
        current: currentStats.totalRevenue,
        required: req.totalRevenue,
        percentage: Math.min((currentStats.totalRevenue / req.totalRevenue) * 100, 100)
      };
    }
    
    if (req.consecutiveNoShows > 0) {
      progress.consecutiveNoShows = {
        current: currentStats.consecutiveNoShows,
        required: req.consecutiveNoShows,
        percentage: Math.min((currentStats.consecutiveNoShows / req.consecutiveNoShows) * 100, 100)
      };
    }
    
    if (req.completedMeetings > 0) {
      progress.completedMeetings = {
        current: currentStats.completedMeetings,
        required: req.completedMeetings,
        percentage: Math.min((currentStats.completedMeetings / req.completedMeetings) * 100, 100)
      };
    }
    
    return { progress, nextLevel, isMaxLevel: false };
  }
  
  // 미션 시스템
  getCurrentMissions() {
    const nextLevel = this.getNextDuckLevel();
    if (!nextLevel) return [];
    
    const currentStats = this.myPageState.duckLevel.currentStats;
    const req = nextLevel.requirements;
    const missions = [];
    
    if (req.totalGuests > currentStats.totalGuests) {
      missions.push({
        id: 'total_guests',
        title: '모임 참여자 늘리기',
        description: `총 ${req.totalGuests}명의 참여자와 모임하기`,
        current: currentStats.totalGuests,
        target: req.totalGuests,
        type: 'progress',
        icon: '👥',
        reward: '레벨업을 위한 필수 조건'
      });
    }
    
    if (req.totalRevenue > currentStats.totalRevenue) {
      missions.push({
        id: 'total_revenue',
        title: '매출 목표 달성',
        description: `총 ${(req.totalRevenue / 10000).toFixed(0)}만원 매출 달성하기`,
        current: currentStats.totalRevenue,
        target: req.totalRevenue,
        type: 'progress',
        icon: '💰',
        reward: '레벨업을 위한 필수 조건'
      });
    }
    
    if (req.consecutiveNoShows > currentStats.consecutiveNoShows) {
      missions.push({
        id: 'consecutive_no_shows',
        title: '신뢰도 쌓기',
        description: `노쇼 없이 ${req.consecutiveNoShows}회 연속 예약 성공하기`,
        current: currentStats.consecutiveNoShows,
        target: req.consecutiveNoShows,
        type: 'streak',
        icon: '🎯',
        reward: '레벨업을 위한 필수 조건'
      });
    }
    
    if (req.completedMeetings > currentStats.completedMeetings) {
      missions.push({
        id: 'completed_meetings',
        title: '모임 마스터',
        description: `총 ${req.completedMeetings}회의 모임 성공적으로 완료하기`,
        current: currentStats.completedMeetings,
        target: req.completedMeetings,
        type: 'progress',
        icon: '🏆',
        reward: '레벨업을 위한 필수 조건'
      });
    }
    
    return missions;
  }

  // 미션 관련 메서드들
  showAllMissions() {
    const missions = this.getCurrentMissions();
    const currentLevel = this.getCurrentDuckLevel();
    const nextLevel = this.getNextDuckLevel();
    
    const missionPopup = `
      <div class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" onclick="this.remove()">
        <div class="bg-white w-full max-w-md rounded-xl max-h-[80vh] overflow-y-auto" onclick="event.stopPropagation()">
          <!-- 헤더 -->
          <div class="flex items-center justify-between p-4 border-b">
            <div class="flex items-center space-x-3">
              <span class="text-2xl">${currentLevel.emoji}</span>
              <div>
                <h3 class="text-lg font-semibold text-gray-900">${nextLevel.name} 달성 미션</h3>
                <p class="text-sm text-gray-600">${nextLevel.description}</p>
              </div>
            </div>
            <button class="text-gray-400 hover:text-gray-600" onclick="this.parentElement.parentElement.parentElement.remove()">
              <i class="fas fa-times text-xl"></i>
            </button>
          </div>
          
          <!-- 미션 목록 -->
          <div class="p-4 space-y-4">
            ${missions.map(mission => {
              const progress = (mission.current / mission.target) * 100;
              const isCompleted = progress >= 100;
              
              return `
                <div class="border ${isCompleted ? 'border-green-200 bg-green-50' : 'border-gray-200'} rounded-lg p-4">
                  <div class="flex items-start space-x-3">
                    <div class="text-2xl">${mission.icon}</div>
                    <div class="flex-1">
                      <h4 class="font-semibold text-gray-900 mb-1">${mission.title}</h4>
                      <p class="text-sm text-gray-600 mb-3">${mission.description}</p>
                      
                      <div class="mb-2">
                        <div class="flex items-center justify-between text-sm text-gray-600 mb-1">
                          <span>진행상황</span>
                          <span class="${isCompleted ? 'text-green-600 font-semibold' : ''}">
                            ${mission.current.toLocaleString()}/${mission.target.toLocaleString()}
                            ${mission.type === 'progress' ? '명' : '회'}
                          </span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-2">
                          <div class="bg-gradient-to-r ${isCompleted ? 'from-green-500 to-emerald-600' : 'from-blue-500 to-purple-500'} h-2 rounded-full transition-all duration-300" 
                               style="width: ${Math.min(progress, 100)}%"></div>
                        </div>
                      </div>
                      
                      <div class="flex items-center justify-between">
                        <span class="text-xs ${isCompleted ? 'text-green-600' : 'text-gray-500'}">${mission.reward}</span>
                        ${isCompleted ? '<i class="fas fa-check-circle text-green-500"></i>' : ''}
                      </div>
                    </div>
                  </div>
                </div>
              `;
            }).join('')}
            
            <!-- 레벨업 혜택 미리보기 -->
            <div class="bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-lg p-4">
              <h4 class="font-semibold text-gray-900 mb-2">🎁 레벨업 시 혜택</h4>
              <div class="space-y-1">
                ${nextLevel.benefits.map(benefit => `
                  <div class="text-sm text-gray-700">• ${benefit}</div>
                `).join('')}
              </div>
              ${nextLevel.bonusRate > 0 ? `
                <div class="mt-2 bg-yellow-100 border border-yellow-200 rounded px-3 py-2">
                  <div class="text-sm font-semibold text-yellow-800">
                    💰 적립률 ${(1 + currentLevel.bonusRate).toFixed(1)}% → ${(1 + nextLevel.bonusRate).toFixed(1)}%
                  </div>
                </div>
              ` : ''}
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', missionPopup);
  }
  
  // 스탯 업데이트 시뮬레이션 (테스트용)
  simulateActivity(type) {
    const { currentStats } = this.myPageState.duckLevel;
    
    switch(type) {
      case 'reservation':
        currentStats.totalGuests += Math.floor(Math.random() * 8) + 4; // 4-12명
        currentStats.totalRevenue += Math.floor(Math.random() * 300000) + 200000; // 20-50만원
        currentStats.totalReservations += 1;
        currentStats.completedMeetings += 1;
        currentStats.consecutiveNoShows += 1;
        break;
        
      case 'levelup_test':
        // 다음 레벨 조건을 충족하도록 설정
        const nextLevel = this.getNextDuckLevel();
        if (nextLevel) {
          const req = nextLevel.requirements;
          currentStats.totalGuests = Math.max(currentStats.totalGuests, req.totalGuests);
          currentStats.totalRevenue = Math.max(currentStats.totalRevenue, req.totalRevenue);
          currentStats.totalReservations = Math.max(currentStats.totalReservations, req.totalReservations);
          currentStats.consecutiveNoShows = Math.max(currentStats.consecutiveNoShows, req.consecutiveNoShows);
          currentStats.completedMeetings = Math.max(currentStats.completedMeetings, req.completedMeetings);
        }
        break;
    }
    
    // 레벨업 체크
    if (this.checkLevelUpConditions()) {
      // 자동 레벨업은 하지 않고 사용자가 버튼을 클릭하도록 유도
      this.render();
    } else {
      this.render();
    }
  }

  // 프리미엄 결제 팝업 (STEP 16 강화)
  renderPremiumPaymentPopup() {
    if (!this.showPremiumPaymentPopup) return '';
    
    return `
      <div class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end" onclick="OReeApp.instance.closePremiumPaymentPopup()">
        <div class="bg-white w-full rounded-t-3xl max-h-[90vh] overflow-y-auto" onclick="event.stopPropagation()">
          <!-- 헤더 -->
          <div class="bg-gradient-to-r from-purple-500 to-pink-500 text-white p-6 text-center relative">
            <button class="absolute top-4 right-4 text-white/80 hover:text-white" onclick="OReeApp.instance.closePremiumPaymentPopup()">
              <i class="fas fa-times text-xl"></i>
            </button>
            
            <div class="text-4xl mb-3">👑</div>
            <h3 class="text-xl font-bold mb-2">프리미엄 멤버십</h3>
            <p class="text-purple-100 text-sm">8% 적립률과 프리미엄 혜택을 누리세요!</p>
          </div>
          
          <div class="p-6">
            <!-- 특별 혜택 강조 -->
            <div class="bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-yellow-300 rounded-xl p-5 mb-6">
              <div class="text-center">
                <div class="flex items-center justify-center space-x-2 mb-3">
                  <span class="text-2xl">🔥</span>
                  <div class="text-2xl font-bold text-orange-600">+3%</div>
                  <span class="text-2xl">🔥</span>
                </div>
                <p class="text-sm font-semibold text-orange-800 mb-2">
                  지금 결제 시 3% 추가로<br>
                  <span class="text-lg text-purple-600">8% 적립 부스터</span>가 적용됩니다!
                </p>
                <div class="flex items-center justify-center space-x-3 text-sm text-orange-600 bg-white/50 rounded-full py-2 px-4">
                  <span class="line-through">기본 5%</span>
                  <i class="fas fa-arrow-right text-purple-600"></i>
                  <span class="font-bold text-purple-600">프리미엄 8%</span>
                </div>
              </div>
            </div>
            
            <!-- 월 구독료 -->
            <div class="text-center mb-6">
              <div class="text-sm text-gray-600 mb-1">월 정기결제</div>
              <div class="text-3xl font-bold text-gray-900 mb-1">5,500원</div>
              <div class="text-sm text-gray-500">VAT 포함 • 언제든 해지 가능</div>
              <div class="mt-2 inline-block bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-medium">
                💰 첫 7일 무료 체험
              </div>
            </div>
            
            <!-- 프리미엄 혜택 목록 -->
            <div class="mb-6">
              <h4 class="font-semibold text-gray-900 mb-3 text-center">🎁 프리미엄 전용 혜택</h4>
              <div class="space-y-3">
                <div class="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                  <div class="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                    <i class="fas fa-percentage text-white text-sm"></i>
                  </div>
                  <div>
                    <div class="font-medium text-gray-900">8% 적립률</div>
                    <div class="text-xs text-gray-600">기본 5%에서 3% 추가 적립</div>
                  </div>
                </div>
                
                <div class="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                  <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                    <i class="fas fa-star text-white text-sm"></i>
                  </div>
                  <div>
                    <div class="font-medium text-gray-900">우선 예약권</div>
                    <div class="text-xs text-gray-600">인기 매장 우선 예약 기회</div>
                  </div>
                </div>
                
                <div class="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                  <div class="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                    <i class="fas fa-headset text-white text-sm"></i>
                  </div>
                  <div>
                    <div class="font-medium text-gray-900">전용 고객센터</div>
                    <div class="text-xs text-gray-600">프리미엄 회원 전용 상담</div>
                  </div>
                </div>
                
                <div class="flex items-center space-x-3 p-3 bg-orange-50 rounded-lg">
                  <div class="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center">
                    <i class="fas fa-medal text-white text-sm"></i>
                  </div>
                  <div>
                    <div class="font-medium text-gray-900">프리미엄 배지</div>
                    <div class="text-xs text-gray-600">프로필에 금색 배지 표시</div>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- 적립 예시 -->
            <div class="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-xl p-4 mb-6">
              <h4 class="font-semibold text-purple-900 mb-3 text-center">💎 적립 예시</h4>
              <div class="space-y-2 text-sm">
                <div class="flex justify-between items-center py-2 border-b border-purple-200">
                  <span class="text-purple-700">10만원 모임 이용</span>
                  <span class="font-semibold text-purple-900">8,000P (+3,000P)</span>
                </div>
                <div class="flex justify-between items-center py-2 border-b border-purple-200">
                  <span class="text-purple-700">30만원 모임 이용</span>
                  <span class="font-semibold text-purple-900">24,000P (+9,000P)</span>
                </div>
                <div class="flex justify-between items-center py-2">
                  <span class="text-purple-700">50만원 모임 이용</span>
                  <span class="font-semibold text-purple-900">40,000P (+15,000P)</span>
                </div>
              </div>
              <div class="text-center mt-3 p-2 bg-purple-100 rounded text-purple-800 font-medium text-xs">
                기본 대비 매월 최대 수만 포인트 추가 적립! 🚀
              </div>
            </div>
            
            <!-- 환불 정책 아코디언 -->
            <div class="mb-6">
              <button class="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg text-left hover:bg-gray-100 transition-colors" 
                      onclick="OReeApp.instance.toggleRefundPolicy()">
                <span class="text-sm font-medium text-gray-700">📋 자세히 보기 (환불정책)</span>
                <i class="fas fa-chevron-down text-gray-400 transform transition-transform ${this.showRefundPolicy ? 'rotate-180' : ''}" id="refund-chevron"></i>
              </button>
              
              <div class="overflow-hidden transition-all duration-300 ${this.showRefundPolicy ? 'max-h-96' : 'max-h-0'}">
                <div class="p-4 bg-gray-50 rounded-b-lg text-xs text-gray-600 space-y-2">
                  <div class="space-y-2">
                    <div class="flex items-start space-x-2">
                      <span class="text-blue-600">•</span>
                      <span><strong>월 정기결제:</strong> 매월 5,500원 자동 결제 (VAT 포함)</span>
                    </div>
                    
                    <div class="flex items-start space-x-2">
                      <span class="text-blue-600">•</span>
                      <span><strong>즉시 혜택 제공:</strong> 가입 즉시 프리미엄 혜택이 적용되며, 중도해지 시 잔여 기간에 대한 환불은 불가합니다</span>
                    </div>
                    
                    <div class="flex items-start space-x-2">
                      <span class="text-green-600">•</span>
                      <span><strong>7일 무료 체험:</strong> 최초 결제 7일 이내 + 이용 내역이 없을 시 전액 환불 가능</span>
                    </div>
                    
                    <div class="flex items-start space-x-2">
                      <span class="text-orange-600">•</span>
                      <span><strong>해지 방법:</strong> [마이 > 구독 관리]에서 언제든 해지 가능하며, 해지 후에도 잔여 기간 동안 혜택이 유지됩니다</span>
                    </div>
                    
                    <div class="flex items-start space-x-2">
                      <span class="text-purple-600">•</span>
                      <span><strong>결제 정책:</strong> 앱마켓(Apple App Store / Google Play Store) 결제 정책을 준수합니다</span>
                    </div>
                  </div>
                  
                  <div class="mt-3 pt-3 border-t border-gray-300 text-center">
                    <span class="text-gray-500 font-medium">언제든 해지 가능 • 위약금 없음</span>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- 결제 버튼 -->
            <div class="space-y-3">
              <button class="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-4 px-6 rounded-xl font-bold text-lg hover:shadow-lg transition-all duration-200 relative overflow-hidden" 
                      onclick="OReeApp.instance.processPremiumPayment()">
                <div class="relative z-10 flex items-center justify-center space-x-2">
                  <i class="fas fa-crown"></i>
                  <span>7일 무료로 시작하기</span>
                  <i class="fas fa-arrow-right"></i>
                </div>
                <div class="absolute inset-0 bg-white opacity-0 hover:opacity-10 transition-opacity duration-200"></div>
              </button>
              
              <button class="w-full border border-gray-300 text-gray-600 py-3 px-4 rounded-xl text-sm hover:bg-gray-50 transition-colors" 
                      onclick="OReeApp.instance.closePremiumPaymentPopup()">
                나중에 하기
              </button>
            </div>
            
            <div class="text-center mt-4 space-y-1">
              <p class="text-xs text-gray-500">
                7일 무료 체험 후 월 5,500원 자동 결제
              </p>
              <p class="text-xs text-gray-400">
                언제든 해지 가능 • 해지 시까지 프리미엄 혜택 유지
              </p>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  
  // 프리미엄 멤버십 관련 메서드들 (STEP 16)
  showPremiumPaymentPopup() {
    this.showPremiumPaymentPopup = true;
    this.showRefundPolicy = false; // 아코디언 초기화
    this.render();
  }
  
  closePremiumPaymentPopup() {
    this.showPremiumPaymentPopup = false;
    this.showRefundPolicy = false;
    this.render();
  }
  
  toggleRefundPolicy() {
    this.showRefundPolicy = !this.showRefundPolicy;
    this.render();
    
    // 아코디언 애니메이션을 위한 chevron 회전
    setTimeout(() => {
      const chevron = document.getElementById('refund-chevron');
      if (chevron) {
        chevron.classList.toggle('rotate-180', this.showRefundPolicy);
      }
    }, 100);
  }
  
  processPremiumPayment() {
    // 결제 성공 처리
    this.showPremiumSuccessAnimation();
    
    // 멤버십 상태 업데이트
    this.myPageState.premiumMembership.isActive = true;
    this.myPageState.premiumMembership.subscriptionDate = new Date().toISOString();
    this.myPageState.premiumMembership.nextBillingDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(); // 30일 후
    
    this.closePremiumPaymentPopup();
  }
  
  showPremiumSuccessAnimation() {
    const successToast = document.createElement('div');
    successToast.className = `
      fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 
      bg-gradient-to-r from-purple-500 to-pink-500 text-white p-6 rounded-xl 
      shadow-2xl z-50 max-w-sm w-full mx-4 text-center
    `;
    
    successToast.innerHTML = `
      <div class="text-4xl mb-3">🎉</div>
      <h3 class="text-lg font-bold mb-2">프리미엄 멤버 가입 완료!</h3>
      <div class="space-y-1 text-sm">
        <div class="flex items-center justify-center space-x-2">
          <span class="text-2xl">👑</span>
          <span class="font-semibold">금배지 획득</span>
        </div>
        <div class="text-purple-100">8% 적립률이 적용되었습니다</div>
        <div class="text-purple-200 text-xs">7일 무료 체험 시작</div>
      </div>
    `;
    
    document.body.appendChild(successToast);
    
    // 3초 후 토스트 제거
    setTimeout(() => {
      successToast.style.opacity = '0';
      successToast.style.transform = 'translate(-50%, -50%) scale(0.9)';
      setTimeout(() => {
        document.body.removeChild(successToast);
      }, 300);
    }, 3000);
  }
  
  showSettlementOverview() {
    const settlementPopup = `
      <div class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" onclick="this.remove()">
        <div class="bg-white w-full max-w-md rounded-xl max-h-[80vh] overflow-y-auto" onclick="event.stopPropagation()">
          <div class="flex items-center justify-between p-4 border-b">
            <h3 class="text-lg font-semibold text-gray-900">정산 개요</h3>
            <button class="text-gray-400 hover:text-gray-600" onclick="this.parentElement.parentElement.parentElement.remove()">
              <i class="fas fa-times text-xl"></i>
            </button>
          </div>
          
          <div class="p-4 space-y-4">
            <div>
              <h4 class="font-semibold text-gray-900 mb-2">정산 주기</h4>
              <p class="text-sm text-gray-600">매주 목요일 일괄 정산 처리</p>
            </div>
            
            <div>
              <h4 class="font-semibold text-gray-900 mb-2">수수료 계산</h4>
              <ul class="text-sm text-gray-600 space-y-1">
                <li>• 기본: 총 거래액의 최대 15%</li>
                <li>• 구독: 총 거래액의 12% (월 33,000원)</li>
                <li>• VAT 별도 (10%)</li>
              </ul>
            </div>
            
            <div>
              <h4 class="font-semibold text-gray-900 mb-2">정산 방식</h4>
              <ul class="text-sm text-gray-600 space-y-1">
                <li>• 주간 매출 집계 후 수수료 차감</li>
                <li>• 등록된 계좌로 자동 입금</li>
                <li>• 정산 내역서 이메일 발송</li>
              </ul>
            </div>
            
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p class="text-xs text-blue-800">
                자세한 정산 정책은 업주 대시보드에서 확인하실 수 있습니다.
              </p>
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', settlementPopup);
  }
  
  contactSupport() {
    alert('고객센터 전화 연결: 1588-0000 (실제로는 전화 앱 실행)');
  }
  
  openChat() {
    alert('채팅 상담 시작 (실제로는 채팅 창 오픈)');
  }
  
  navigateBack() {
    // 이전 페이지로 돌아가기 (기본적으로 마이페이지)
    this.navigateTo('my');
  }

  // 전역 가드 시스템 (STEP 17)
  
  // 접근 권한 체크
  checkAccess(requiredLevel, targetAction = '') {
    // 접근 레벨: 'guest' < 'authenticated' < 'phone_verified'
    
    if (requiredLevel === 'guest') {
      return { allowed: true };
    }
    
    if (requiredLevel === 'authenticated') {
      if (!this.authState.isLoggedIn) {
        return {
          allowed: false,
          reason: 'login_required',
          message: '로그인이 필요한 서비스입니다',
          action: 'login'
        };
      }
      return { allowed: true };
    }
    
    if (requiredLevel === 'phone_verified') {
      if (!this.authState.isLoggedIn) {
        return {
          allowed: false,
          reason: 'login_required',
          message: '로그인이 필요한 서비스입니다',
          action: 'login'
        };
      }
      
      if (!this.authState.isPhoneVerified) {
        return {
          allowed: false,
          reason: 'verification_required',
          message: '인증자에 한해 서비스 이용이 가능합니다.',
          action: 'phone_verification'
        };
      }
      
      return { allowed: true };
    }
    
    return { allowed: false, reason: 'unknown', message: '접근이 제한되었습니다.' };
  }
  
  // 가드 적용 네비게이션
  guardedNavigateTo(screen, requiredLevel = 'guest', additionalChecks = null) {
    // 기본 접근 권한 체크
    const accessCheck = this.checkAccess(requiredLevel, screen);
    
    if (!accessCheck.allowed) {
      this.showAccessDeniedDialog(accessCheck, screen);
      return false;
    }
    
    // 추가 체크 (예: 최소 인원 체크 등)
    if (additionalChecks) {
      const additionalCheck = additionalChecks();
      if (!additionalCheck.allowed) {
        this.showGlobalToast(additionalCheck.message, 'warning');
        return false;
      }
    }
    
    // 접근 허용
    this.navigateTo(screen);
    return true;
  }
  
  // 접근 거부 다이얼로그
  showAccessDeniedDialog(accessCheck, targetScreen) {
    const { reason, message, action } = accessCheck;
    
    let dialogContent = '';
    
    if (reason === 'login_required') {
      dialogContent = `
        <div class="text-center">
          <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-user-lock text-blue-600 text-2xl"></i>
          </div>
          <h3 class="text-lg font-semibold text-gray-900 mb-2">로그인이 필요합니다</h3>
          <p class="text-sm text-gray-600 mb-6">${message}</p>
          <div class="space-y-3">
            <button class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors" 
                    onclick="OReeApp.instance.navigateTo('login'); OReeApp.instance.closeGlobalDialog();">
              <i class="fas fa-sign-in-alt mr-2"></i>로그인하기
            </button>
            <button class="w-full border border-gray-300 text-gray-600 py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors" 
                    onclick="OReeApp.instance.closeGlobalDialog();">
              취소
            </button>
          </div>
        </div>
      `;
    } else if (reason === 'verification_required') {
      dialogContent = `
        <div class="text-center">
          <div class="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-mobile-alt text-orange-600 text-2xl"></i>
          </div>
          <h3 class="text-lg font-semibold text-gray-900 mb-2">전화번호 인증 필요</h3>
          <p class="text-sm text-gray-600 mb-6">${message}</p>
          <div class="space-y-3">
            <button class="w-full bg-orange-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-orange-700 transition-colors" 
                    onclick="OReeApp.instance.navigateTo('phone-auth'); OReeApp.instance.closeGlobalDialog();">
              <i class="fas fa-phone mr-2"></i>지금 인증하기
            </button>
            <button class="w-full border border-gray-300 text-gray-600 py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors" 
                    onclick="OReeApp.instance.closeGlobalDialog();">
              나중에 하기
            </button>
          </div>
        </div>
      `;
    }
    
    this.showGlobalDialog(dialogContent);
  }

  // 가드된 결제 진행 메서드
  guardedProceedToPayment() {
    // 1. 전화번호 인증 상태 확인
    const accessCheck = this.checkAccess('phone_verified', 'payment');
    if (!accessCheck.allowed) {
      this.showAccessDeniedDialog(accessCheck, 'payment');
      return;
    }

    // 2. 예약 데이터 확인
    if (!this.reservation) {
      this.showGlobalToast('예약 정보를 불러올 수 없습니다.', 'error');
      return;
    }

    // 3. 최소 인원 확인 (4명)
    const totalGuests = this.reservation.adults + this.reservation.children;
    if (totalGuests < 4) {
      const dialogContent = `
        <div class="text-center">
          <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-users text-red-600 text-2xl"></i>
          </div>
          <h3 class="text-lg font-semibold text-gray-900 mb-2">최소 인원 미달</h3>
          <p class="text-sm text-gray-600 mb-2">예약은 최소 4명부터 가능합니다.</p>
          <p class="text-xs text-gray-500 mb-6">현재: ${totalGuests}명</p>
          <div class="space-y-3">
            <button class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors" 
                    onclick="OReeApp.instance.navigateTo('reserve'); OReeApp.instance.closeGlobalDialog();">
              <i class="fas fa-edit mr-2"></i>인원 수정하기
            </button>
            <button class="w-full border border-gray-300 text-gray-600 py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors" 
                    onclick="OReeApp.instance.closeGlobalDialog();">
              취소
            </button>
          </div>
        </div>
      `;
      
      this.showGlobalDialog(dialogContent);
      return;
    }

    // 4. 모든 검증 통과 - 결제 진행
    this.proceedToPayment();
  }

  // 네트워크 오류 통합 처리 메서드
  handleNetworkError(error, operation = '요청') {
    console.error('Network Error:', error);
    
    // 네트워크 연결 상태 확인
    if (!navigator.onLine) {
      this.showGlobalToast('인터넷 연결을 확인해 주세요.', 'error');
      return;
    }
    
    // 기본 네트워크 오류 메시지
    this.showGlobalToast('네트워크 오류가 발생했습니다. 다시 시도해 주세요.', 'error');
  }

  // API 호출 래퍼 (네트워크 오류 처리 포함)
  async apiCall(apiFunction, ...args) {
    try {
      return await apiFunction(...args);
    } catch (error) {
      this.handleNetworkError(error);
      throw error; // 호출자에게 에러 전파
    }
  }
  
  // 전역 토스트 표시
  showGlobalToast(message, type = 'info', duration = 3000) {
    const toastId = ++this.globalGuard.lastToastId;
    
    const toast = document.createElement('div');
    toast.id = `global-toast-${toastId}`;
    toast.className = `
      fixed top-4 left-1/2 transform -translate-x-1/2 z-50 
      max-w-sm w-full mx-4 px-4 py-3 rounded-lg shadow-lg
      transition-all duration-300 translate-y-0 opacity-100
      ${this.getToastStyles(type)}
    `;
    
    const icon = this.getToastIcon(type);
    
    toast.innerHTML = `
      <div class="flex items-center space-x-3">
        <div class="flex-shrink-0">
          <i class="${icon}"></i>
        </div>
        <div class="flex-1">
          <p class="text-sm font-medium">${message}</p>
        </div>
        <button class="flex-shrink-0 hover:opacity-70 transition-opacity" 
                onclick="OReeApp.instance.closeToast('${toastId}')">
          <i class="fas fa-times"></i>
        </button>
      </div>
    `;
    
    // 기존 토스트 위로 새로운 토스트 추가
    document.body.appendChild(toast);
    
    // 애니메이션 효과
    setTimeout(() => {
      toast.style.transform = 'translate(-50%, 0)';
    }, 100);
    
    // 자동 제거
    setTimeout(() => {
      this.closeToast(toastId);
    }, duration);
    
    return toastId;
  }
  
  getToastStyles(type) {
    switch (type) {
      case 'success':
        return 'bg-green-500 text-white';
      case 'error':
        return 'bg-red-500 text-white';
      case 'warning':
        return 'bg-orange-500 text-white';
      case 'info':
      default:
        return 'bg-blue-500 text-white';
    }
  }
  
  getToastIcon(type) {
    switch (type) {
      case 'success':
        return 'fas fa-check-circle text-white';
      case 'error':
        return 'fas fa-exclamation-circle text-white';
      case 'warning':
        return 'fas fa-exclamation-triangle text-white';
      case 'info':
      default:
        return 'fas fa-info-circle text-white';
    }
  }
  
  closeToast(toastId) {
    const toast = document.getElementById(`global-toast-${toastId}`);
    if (toast) {
      toast.style.opacity = '0';
      toast.style.transform = 'translate(-50%, -20px)';
      setTimeout(() => {
        if (toast.parentElement) {
          toast.parentElement.removeChild(toast);
        }
      }, 300);
    }
  }
  
  // 전역 다이얼로그 표시
  showGlobalDialog(content) {
    this.closeGlobalDialog(); // 기존 다이얼로그 닫기
    
    const dialog = document.createElement('div');
    dialog.id = 'global-dialog';
    dialog.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4';
    
    dialog.innerHTML = `
      <div class="bg-white w-full max-w-md rounded-xl overflow-hidden transform scale-95 opacity-0 transition-all duration-300" 
           id="global-dialog-content">
        <div class="p-6">
          ${content}
        </div>
      </div>
    `;
    
    document.body.appendChild(dialog);
    
    // 애니메이션 효과
    setTimeout(() => {
      const dialogContent = document.getElementById('global-dialog-content');
      if (dialogContent) {
        dialogContent.style.transform = 'scale(1)';
        dialogContent.style.opacity = '1';
      }
    }, 100);
    
    this.globalGuard.activeDialog = dialog;
  }
  
  closeGlobalDialog() {
    const dialog = document.getElementById('global-dialog');
    if (dialog) {
      const dialogContent = document.getElementById('global-dialog-content');
      if (dialogContent) {
        dialogContent.style.transform = 'scale(0.95)';
        dialogContent.style.opacity = '0';
      }
      
      setTimeout(() => {
        if (dialog.parentElement) {
          dialog.parentElement.removeChild(dialog);
        }
        this.globalGuard.activeDialog = null;
      }, 300);
    }
  }
  
  // 네트워크 오류 처리
  handleNetworkError(error, context = '') {
    console.error('Network error:', error, context);
    this.showGlobalToast('네트워크 오류가 발생했습니다. 다시 시도해 주세요.', 'error', 4000);
  }
  
  // 예약 시 최소 인원 체크
  validateMinimumGuests(guestCount) {
    if (guestCount < 4) {
      return {
        allowed: false,
        message: '단체예약은 최소 4인 이상부터 가능합니다.'
      };
    }
    return { allowed: true };
  }
  
  // 가드가 적용된 주요 액션들
  guardedReservation() {
    return this.guardedNavigateTo('reservation', 'phone_verified');
  }
  
  guardedQRGeneration() {
    return this.guardedNavigateTo('qr', 'phone_verified');
  }
  
  guardedStoreDetail(storeId) {
    // 매장 상세는 로그인 없이도 가능하지만 예약은 제한
    this.navigateTo('store-detail');
  }

  // 기타 메서드들
  openSettingsMenu() {
    alert('설정 메뉴를 여는 중...');
  }

  // 포인트/수익 구조 안내 페이지 (STEP 15)
  renderRevenueStructure() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateBack()" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">포인트 & 수익 구조</h1>
            <div></div>
          </div>
        </div>
        
        <div class="p-4 space-y-6">
          <!-- 개요 -->
          <div class="card p-4">
            <div class="text-center mb-4">
              <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <i class="fas fa-chart-line text-blue-600 text-2xl"></i>
              </div>
              <h2 class="text-xl font-bold text-gray-900 mb-2">투명한 수익 구조</h2>
              <p class="text-sm text-gray-600">
                ORee는 투명하고 공정한 수익 구조를 통해<br>
                사용자와 업주 모두에게 최대의 가치를 제공합니다
              </p>
            </div>
          </div>
          
          <!-- 사용자 적립 구조 -->
          <div class="card p-0 overflow-hidden">
            <div class="bg-gradient-to-r from-green-500 to-emerald-600 text-white p-4">
              <h3 class="text-lg font-semibold mb-2">
                <i class="fas fa-coins mr-2"></i>사용자 적립 구조
              </h3>
              <p class="text-green-100 text-sm">이용 금액의 일정 비율을 포인트로 적립</p>
            </div>
            
            <div class="p-4 space-y-4">
              <!-- 기본 적립 -->
              <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h4 class="font-semibold text-gray-900">기본 적립</h4>
                  <p class="text-sm text-gray-600">모든 사용자 기본 제공</p>
                </div>
                <div class="text-right">
                  <div class="text-2xl font-bold text-gray-900">5%</div>
                  <div class="text-xs text-gray-500">이용금액의</div>
                </div>
              </div>
              
              <!-- 프리미엄 적립 -->
              <div class="relative p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border-2 border-purple-200">
                <div class="absolute -top-2 -right-2 bg-purple-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
                  HOT
                </div>
                <div class="flex items-center justify-between">
                  <div>
                    <div class="flex items-center space-x-2 mb-1">
                      <i class="fas fa-crown text-purple-600"></i>
                      <h4 class="font-semibold text-gray-900">프리미엄 적립</h4>
                    </div>
                    <p class="text-sm text-gray-600">월 5,500원 구독 시</p>
                    <p class="text-xs text-purple-600 font-medium">3% 추가 적립 혜택!</p>
                  </div>
                  <div class="text-right">
                    <div class="text-2xl font-bold text-purple-600">8%</div>
                    <div class="text-xs text-gray-500">이용금액의</div>
                  </div>
                </div>
                
                <button class="w-full mt-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white py-2 px-4 rounded-lg text-sm font-semibold hover:shadow-lg transition-all duration-200" 
                        onclick="OReeApp.instance.showPremiumPaymentPopup()">
                  <i class="fas fa-star mr-2"></i>지금 가입하고 3% 더 받기
                </button>
              </div>
              
              <!-- 적립 예시 -->
              <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 class="font-semibold text-blue-900 mb-3">적립 예시</h4>
                <div class="space-y-2 text-sm">
                  <div class="flex justify-between">
                    <span class="text-blue-700">10만원 모임 이용 시</span>
                    <div class="space-x-3">
                      <span class="text-gray-600">기본: 5,000P</span>
                      <span class="text-purple-600 font-semibold">프리미엄: 8,000P</span>
                    </div>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-blue-700">50만원 모임 이용 시</span>
                    <div class="space-x-3">
                      <span class="text-gray-600">기본: 25,000P</span>
                      <span class="text-purple-600 font-semibold">프리미엄: 40,000P</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- 업주 수수료 구조 -->
          <div class="card p-0 overflow-hidden">
            <div class="bg-gradient-to-r from-orange-500 to-red-600 text-white p-4">
              <h3 class="text-lg font-semibold mb-2">
                <i class="fas fa-store mr-2"></i>업주 수수료 구조
              </h3>
              <p class="text-orange-100 text-sm">매출 기반 공정한 수수료 정책</p>
            </div>
            
            <div class="p-4 space-y-4">
              <!-- 기본 수수료 -->
              <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h4 class="font-semibold text-gray-900">기본 수수료</h4>
                  <p class="text-sm text-gray-600">모든 업주 기본 정책</p>
                </div>
                <div class="text-right">
                  <div class="text-2xl font-bold text-gray-900">15%</div>
                  <div class="text-xs text-gray-500">총 거래액의 최대</div>
                </div>
              </div>
              
              <!-- 구독 수수료 -->
              <div class="relative p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border-2 border-blue-200">
                <div class="absolute -top-2 -right-2 bg-blue-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
                  SAVE
                </div>
                <div class="flex items-center justify-between">
                  <div>
                    <div class="flex items-center space-x-2 mb-1">
                      <i class="fas fa-handshake text-blue-600"></i>
                      <h4 class="font-semibold text-gray-900">구독 수수료</h4>
                    </div>
                    <p class="text-sm text-gray-600">월 33,000원 구독 시</p>
                    <p class="text-xs text-blue-600 font-medium">3% 수수료 절약!</p>
                  </div>
                  <div class="text-right">
                    <div class="text-2xl font-bold text-blue-600">12%</div>
                    <div class="text-xs text-gray-500">총 거래액의</div>
                  </div>
                </div>
              </div>
              
              <!-- 수수료 절약 예시 -->
              <div class="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <h4 class="font-semibold text-orange-900 mb-3">월 수수료 절약 예시</h4>
                <div class="space-y-2 text-sm">
                  <div class="flex justify-between">
                    <span class="text-orange-700">월 매출 300만원 시</span>
                    <div class="space-x-3">
                      <span class="text-gray-600 line-through">기본: 45만원</span>
                      <span class="text-blue-600 font-semibold">구독: 36만원 (-9만원)</span>
                    </div>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-orange-700">월 매출 500만원 시</span>
                    <div class="space-x-3">
                      <span class="text-gray-600 line-through">기본: 75만원</span>
                      <span class="text-blue-600 font-semibold">구독: 60만원 (-15만원)</span>
                    </div>
                  </div>
                  <div class="text-center mt-3 p-2 bg-blue-100 rounded text-blue-800 font-medium text-xs">
                    월 구독비 33,000원으로 최대 15만원까지 절약 가능!
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- 결제 플로우 -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-credit-card text-blue-600 mr-2"></i>결제 플로우
            </h3>
            
            <div class="space-y-4">
              <!-- 현장 직결제 -->
              <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                <div class="flex items-start space-x-3">
                  <div class="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                    1
                  </div>
                  <div class="flex-1">
                    <h4 class="font-semibold text-green-900 mb-1">현장 직결제</h4>
                    <p class="text-sm text-green-800 mb-2">
                      사용자는 매장에서 직접 결제합니다<br>
                      <span class="text-xs text-green-600">※ 플랫폼 결제가 아닌 현장 결제</span>
                    </p>
                  </div>
                </div>
              </div>
              
              <!-- 대시보드 입력 -->
              <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div class="flex items-start space-x-3">
                  <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                    2
                  </div>
                  <div class="flex-1">
                    <h4 class="font-semibold text-blue-900 mb-1">업주 대시보드 입력</h4>
                    <p class="text-sm text-blue-800 mb-2">
                      업주가 대시보드에서 인원 & 총금액 입력<br>
                      <span class="text-xs text-blue-600">※ 입력 즉시 사용자 적립 자동 반영</span>
                    </p>
                  </div>
                </div>
              </div>
              
              <!-- 포인트 적립 -->
              <div class="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div class="flex items-start space-x-3">
                  <div class="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                    3
                  </div>
                  <div class="flex-1">
                    <h4 class="font-semibold text-purple-900 mb-1">자동 포인트 적립</h4>
                    <p class="text-sm text-purple-800 mb-2">
                      이용 금액에 따른 포인트가 자동 적립<br>
                      <span class="text-xs text-purple-600">※ 적립 완료 시 푸시 알림 발송</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="mt-4 p-3 bg-gray-100 rounded-lg">
              <div class="flex items-center space-x-2 text-sm text-gray-700">
                <i class="fas fa-info-circle text-gray-500"></i>
                <span class="font-medium">간편하고 투명한 정산 시스템</span>
              </div>
              <p class="text-xs text-gray-600 mt-1">
                복잡한 온라인 결제 없이도 포인트 적립과 수수료 정산이 자동으로 처리됩니다
              </p>
            </div>
          </div>
          
          <!-- 정책 링크 -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-file-contract text-gray-600 mr-2"></i>관련 정책
            </h3>
            
            <div class="space-y-3">
              <button class="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors" 
                      onclick="OReeApp.instance.navigateTo('refund-policy')">
                <div class="flex items-center space-x-3">
                  <i class="fas fa-undo text-blue-600"></i>
                  <div class="text-left">
                    <h4 class="font-medium text-gray-900">환불 정책</h4>
                    <p class="text-xs text-gray-600">취소, 환불 관련 상세 정책</p>
                  </div>
                </div>
                <i class="fas fa-chevron-right text-gray-400"></i>
              </button>
              
              <button class="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors" 
                      onclick="OReeApp.instance.showSettlementOverview()">
                <div class="flex items-center space-x-3">
                  <i class="fas fa-calculator text-green-600"></i>
                  <div class="text-left">
                    <h4 class="font-medium text-gray-900">정산 개요</h4>
                    <p class="text-xs text-gray-600">수수료 계산 및 정산 일정</p>
                  </div>
                </div>
                <i class="fas fa-chevron-right text-gray-400"></i>
              </button>
              
              <button class="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors" 
                      onclick="OReeApp.instance.navigateTo('group-policy')">
                <div class="flex items-center space-x-3">
                  <i class="fas fa-users text-purple-600"></i>
                  <div class="text-left">
                    <h4 class="font-medium text-gray-900">단체예약 정책</h4>
                    <p class="text-xs text-gray-600">단체예약 이용 약관</p>
                  </div>
                </div>
                <i class="fas fa-chevron-right text-gray-400"></i>
              </button>
            </div>
          </div>
          
          <!-- 문의하기 -->
          <div class="card p-4 text-center">
            <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <i class="fas fa-headset text-blue-600 text-xl"></i>
            </div>
            <h3 class="font-semibold text-gray-900 mb-2">더 궁금한 점이 있으신가요?</h3>
            <p class="text-sm text-gray-600 mb-4">
              수익 구조나 정산에 대해 더 자세한 정보가 필요하시면<br>
              언제든 고객센터로 문의해 주세요
            </p>
            <div class="flex space-x-3">
              <button class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors" 
                      onclick="OReeApp.instance.contactSupport()">
                <i class="fas fa-phone mr-2"></i>전화 문의
              </button>
              <button class="flex-1 border border-blue-600 text-blue-600 py-2 px-4 rounded-lg text-sm font-medium hover:bg-blue-50 transition-colors" 
                      onclick="OReeApp.instance.openChat()">
                <i class="fas fa-comments mr-2"></i>채팅 문의
              </button>
            </div>
          </div>
        </div>
        
        <!-- 프리미엄 결제 팝업 -->
        ${this.renderPremiumPaymentPopup()}
      </div>
    `;
  }
  
  renderDevNotes() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('my')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">개발자 노트</h1>
            <div></div>
          </div>
        </div>
        
        <div class="p-4 space-y-6">
          <!-- 핸드오버 정보 -->
          <div class="card p-4 border-l-4 border-blue-600">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-handshake text-blue-600 mr-2"></i>📋 핸드오버 정보
            </h3>
            
            <!-- 앱 범위 -->
            <div class="mb-4">
              <h4 class="font-semibold text-gray-800 mb-2">🎯 앱 범위</h4>
              <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm">
                <p class="text-blue-800"><strong>사용자용 MVP</strong></p>
                <p class="text-blue-700 mt-1">• 단체예약(4인 이상) 전용 고객 앱</p>
                <p class="text-blue-700">• <strong>업주 대시보드는 별도 개발 필요</strong></p>
                <p class="text-blue-700">• 실시간 예약 관리, QR 인증, 매출 정산 등 업주 기능 미포함</p>
              </div>
            </div>
            
            <!-- 핵심 플로우 -->
            <div class="mb-4">
              <h4 class="font-semibold text-gray-800 mb-2">🔄 핵심 사용자 플로우</h4>
              <div class="bg-green-50 border border-green-200 rounded-lg p-3 text-sm space-y-1">
                <div class="flex items-center space-x-2">
                  <span class="w-5 h-5 bg-green-600 text-white rounded-full text-xs flex items-center justify-center font-semibold">1</span>
                  <span class="text-green-800">로그인/가입 (전화번호 인증)</span>
                </div>
                <div class="flex items-center space-x-2">
                  <span class="w-5 h-5 bg-green-600 text-white rounded-full text-xs flex items-center justify-center font-semibold">2</span>
                  <span class="text-green-800">온보딩 (3장 슬라이드)</span>
                </div>
                <div class="flex items-center space-x-2">
                  <span class="w-5 h-5 bg-green-600 text-white rounded-full text-xs flex items-center justify-center font-semibold">3</span>
                  <span class="text-green-800">위치권한 (맞춤 추천)</span>
                </div>
                <div class="flex items-center space-x-2">
                  <span class="w-5 h-5 bg-green-600 text-white rounded-full text-xs flex items-center justify-center font-semibold">4</span>
                  <span class="text-green-800">홈 (지도/목록/필터/알림)</span>
                </div>
                <div class="flex items-center space-x-2">
                  <span class="w-5 h-5 bg-green-600 text-white rounded-full text-xs flex items-center justify-center font-semibold">5</span>
                  <span class="text-green-800">업장상세 → 예약 (4인 이상/보증금/환불정책)</span>
                </div>
                <div class="flex items-center space-x-2">
                  <span class="w-5 h-5 bg-green-600 text-white rounded-full text-xs flex items-center justify-center font-semibold">6</span>
                  <span class="text-green-800">결제 Stub → 예약완료 안내</span>
                </div>
                <div class="flex items-center space-x-2">
                  <span class="w-5 h-5 bg-green-600 text-white rounded-full text-xs flex items-center justify-center font-semibold">7</span>
                  <span class="text-green-800">QR생성 (3분 갱신/PIN) → 마이 (적립/출금/레벨/멤버십)</span>
                </div>
              </div>
            </div>
            
            <!-- 수익 구조 -->
            <div class="mb-4">
              <h4 class="font-semibold text-gray-800 mb-2">💰 수익 구조</h4>
              <div class="bg-purple-50 border border-purple-200 rounded-lg p-3 text-sm">
                <div class="grid grid-cols-1 gap-2">
                  <div class="flex justify-between">
                    <span class="text-purple-700"><strong>업주 수수료</strong></span>
                    <span class="text-purple-800">15% → 구독 시 12%</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-purple-700"><strong>사용자 적립</strong></span>
                    <span class="text-purple-800">5% → 프리미엄 8%</span>
                  </div>
                  <div class="text-xs text-purple-600 mt-2">
                    * 업주는 월 구독으로 수수료 절약, 사용자는 프리미엄으로 적립률 향상
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- 프로젝트 정보 -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-info-circle text-blue-600 mr-2"></i>프로젝트 정보
            </h3>
            <div class="space-y-2 text-sm">
              <div class="flex justify-between">
                <span class="text-gray-600">프로젝트명</span>
                <span class="font-medium">ORee – 단체예약 MVP</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">버전</span>
                <span class="font-medium">v0.1-mvp</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">기술 스택</span>
                <span class="font-medium">Hono + Tailwind CSS + Vanilla JS</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">배포 플랫폼</span>
                <span class="font-medium">Cloudflare Pages</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">마지막 업데이트</span>
                <span class="font-medium">2024-08-29</span>
              </div>
            </div>
          </div>
          
          <!-- 엔티티 설계 (메모) -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-database text-indigo-600 mr-2"></i>🗂️ 엔티티 초안 (메모)
            </h3>
            <div class="space-y-4 text-sm">
              <!-- User 엔티티 -->
              <div class="bg-gray-50 rounded-lg p-3">
                <h4 class="font-semibold text-gray-800 mb-2">👤 User (사용자)</h4>
                <div class="font-mono text-xs text-gray-700 space-y-1">
                  <div>• <strong>id</strong>: 고유 식별자</div>
                  <div>• <strong>phoneVerified</strong>: 전화번호 인증 여부</div>
                  <div>• <strong>level</strong>: 오리 레벨 (1-5)</div>
                  <div>• <strong>premium</strong>: 프리미엄 멤버십 여부</div>
                  <div>• <strong>points</strong>: 누적 적립금</div>
                  <div>• <strong>email, name, phone</strong>: 기본 정보</div>
                  <div>• <strong>createdAt, updatedAt</strong>: 타임스탬프</div>
                </div>
              </div>
              
              <!-- Booking 엔티티 -->
              <div class="bg-gray-50 rounded-lg p-3">
                <h4 class="font-semibold text-gray-800 mb-2">📋 Booking (예약)</h4>
                <div class="font-mono text-xs text-gray-700 space-y-1">
                  <div>• <strong>id</strong>: 고유 식별자</div>
                  <div>• <strong>userId</strong>: 사용자 ID (FK)</div>
                  <div>• <strong>storeId</strong>: 업장 ID (FK)</div>
                  <div>• <strong>date, time</strong>: 예약 일시</div>
                  <div>• <strong>partySize</strong>: 예약 인원 (4명 이상)</div>
                  <div>• <strong>deposit</strong>: 보증금 (30%)</div>
                  <div>• <strong>status</strong>: 예약 상태 (pending/confirmed/completed/cancelled)</div>
                  <div>• <strong>qrCode, qrPin</strong>: QR 코드 정보</div>
                </div>
              </div>
              
              <!-- Visit 엔티티 -->
              <div class="bg-gray-50 rounded-lg p-3">
                <h4 class="font-semibold text-gray-800 mb-2">🏪 Visit (방문)</h4>
                <div class="font-mono text-xs text-gray-700 space-y-1">
                  <div>• <strong>id</strong>: 고유 식별자</div>
                  <div>• <strong>bookingId</strong>: 예약 ID (FK, nullable)</div>
                  <div>• <strong>storeId</strong>: 업장 ID (FK)</div>
                  <div>• <strong>partySize</strong>: 실제 방문 인원</div>
                  <div>• <strong>amount</strong>: 총 결제 금액</div>
                  <div>• <strong>confirmedByOwner</strong>: 업주 확인 여부</div>
                  <div>• <strong>pointsCalculated</strong>: 적립 완료 여부</div>
                  <div>• <strong>visitedAt</strong>: 방문 시각</div>
                </div>
              </div>
              
              <div class="text-xs text-gray-500 mt-3 p-2 bg-yellow-50 border border-yellow-200 rounded">
                <i class="fas fa-lightbulb text-yellow-600 mr-1"></i>
                <strong>참고:</strong> 현재는 메모리 기반 Mock 데이터 사용중. 실서비스 시 Cloudflare D1 (SQLite) 또는 외부 DB 연동 필요
              </div>
            </div>
          </div>

          <!-- 완료된 화면 -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-check-circle text-green-600 mr-2"></i>구현된 화면 (13개)
            </h3>
            <div class="grid grid-cols-1 gap-2 text-sm">
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>1. 온보딩 (팝업 슬라이드)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>2. 로그인/회원가입 + 전화번호 인증</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>3. 위치권한 요청 팝업</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>4. 홈 (지도/목록 전환 + 알림/필터)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>5. 업장상세 (원페이지)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>6. 예약 (달력/시간/인원/보증금)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>7. 결제 (Stub)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>8. QR 생성 (3분 갱신/PIN)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>9. 찜 (카테고리/2열 카드)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>10. 마이페이지 (프로필/적립/예약/멤버십)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>11. 레벨/미션 (다마고치식 오리 5단계)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>12. 전역 가드 & 예외 처리 시스템</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>13. 개발자 노트 (현재 화면)</span>
              </div>
            </div>
          </div>
          
          <!-- 오리 레벨 시스템 테스트 -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-gamepad text-orange-600 mr-2"></i>오리 레벨 시스템 테스트
            </h3>
            
            <!-- 현재 레벨 정보 -->
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
              <div class="flex items-center space-x-3">
                <span class="text-3xl">${this.getCurrentDuckLevel().emoji}</span>
                <div>
                  <h4 class="font-semibold text-blue-900">${this.getCurrentDuckLevel().name}</h4>
                  <p class="text-sm text-blue-700">적립률 ${(1 + this.getCurrentDuckLevel().bonusRate).toFixed(1)}%</p>
                </div>
              </div>
            </div>
            
            <!-- 현재 스탯 -->
            <div class="grid grid-cols-2 gap-3 mb-4 text-sm">
              <div class="bg-gray-50 rounded p-2">
                <span class="text-gray-600">누적인원:</span>
                <span class="font-semibold">${this.myPageState.duckLevel.currentStats.totalGuests}명</span>
              </div>
              <div class="bg-gray-50 rounded p-2">
                <span class="text-gray-600">매출:</span>
                <span class="font-semibold">${(this.myPageState.duckLevel.currentStats.totalRevenue / 10000).toFixed(0)}만원</span>
              </div>
              <div class="bg-gray-50 rounded p-2">
                <span class="text-gray-600">예약횟수:</span>
                <span class="font-semibold">${this.myPageState.duckLevel.currentStats.totalReservations}회</span>
              </div>
              <div class="bg-gray-50 rounded p-2">
                <span class="text-gray-600">완료모임:</span>
                <span class="font-semibold">${this.myPageState.duckLevel.currentStats.completedMeetings}회</span>
              </div>
            </div>
            
            <!-- 테스트 버튼들 -->
            <div class="space-y-2">
              <button class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors" 
                      onclick="OReeApp.instance.simulateActivity('reservation')">
                <i class="fas fa-plus mr-2"></i>예약 활동 시뮬레이션
              </button>
              
              <button class="w-full bg-green-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors" 
                      onclick="OReeApp.instance.simulateActivity('levelup_test')">
                <i class="fas fa-arrow-up mr-2"></i>레벨업 조건 충족 (테스트)
              </button>
              
              <button class="w-full bg-purple-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-purple-700 transition-colors" 
                      onclick="OReeApp.instance.showAllMissions()">
                <i class="fas fa-target mr-2"></i>전체 미션 보기
              </button>
              
              ${this.checkLevelUpConditions() ? `
                <button class="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-white py-3 px-4 rounded-lg font-semibold hover:shadow-lg transition-all duration-200 animate-pulse" 
                        onclick="OReeApp.instance.levelUp()">
                  <i class="fas fa-star mr-2"></i>레벨업 실행!
                </button>
              ` : ''}
            </div>
            
            <div class="mt-4 text-xs text-gray-500">
              * 테스트 기능입니다. 실제 서비스에서는 예약 완료 시 자동으로 스탯이 업데이트됩니다.
            </div>
          </div>
          
          <!-- 적용된 스타일 -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-palette text-purple-600 mr-2"></i>적용된 스타일
            </h3>
            <div class="space-y-2 text-sm">
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>라이트 모드 고정</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>시스템 폰트 사용</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>모든 버튼 12px 라운드 모서리</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>Tailwind CSS 기반 컴포넌트</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>반응형 모바일 우선 디자인</span>
              </div>
            </div>
          </div>
          
          <!-- 다음 개발 단계 -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-road text-orange-600 mr-2"></i>🚀 다음 개발 단계
            </h3>
            
            <div class="space-y-3 text-sm">
              <!-- 우선순위 높음 -->
              <div class="bg-red-50 border border-red-200 rounded p-2">
                <h4 class="font-semibold text-red-800 mb-2">🔴 우선순위 높음</h4>
                <div class="space-y-1">
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-circle text-red-500 text-xs"></i>
                    <span><strong>업주 대시보드</strong> - 예약 관리, QR 인증, 매출 정산</span>
                  </div>
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-circle text-red-500 text-xs"></i>
                    <span><strong>실제 결제 시스템</strong> - 아임포트/토스페이먼츠 연동</span>
                  </div>
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-circle text-red-500 text-xs"></i>
                    <span><strong>데이터베이스 연동</strong> - Cloudflare D1 또는 외부 DB</span>
                  </div>
                </div>
              </div>
              
              <!-- 우선순위 중간 -->
              <div class="bg-yellow-50 border border-yellow-200 rounded p-2">
                <h4 class="font-semibold text-yellow-800 mb-2">🟡 우선순위 중간</h4>
                <div class="space-y-1">
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-circle text-yellow-500 text-xs"></i>
                    <span><strong>실제 지도 API</strong> - 카카오맵/네이버맵 연동</span>
                  </div>
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-circle text-yellow-500 text-xs"></i>
                    <span><strong>업장 등록 시스템</strong> - 업주 온보딩 프로세스</span>
                  </div>
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-circle text-yellow-500 text-xs"></i>
                    <span><strong>리뷰 시스템</strong> - 업장 평점 및 후기 기능</span>
                  </div>
                </div>
              </div>
              
              <!-- 우선순위 낮음 -->
              <div class="bg-green-50 border border-green-200 rounded p-2">
                <h4 class="font-semibold text-green-800 mb-2">🟢 우선순위 낮음</h4>
                <div class="space-y-1">
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-circle text-green-500 text-xs"></i>
                    <span><strong>푸시 알림</strong> - 예약 확인, 리마인더</span>
                  </div>
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-circle text-green-500 text-xs"></i>
                    <span><strong>쿠폰/프로모션</strong> - 할인 및 이벤트 시스템</span>
                  </div>
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-circle text-green-500 text-xs"></i>
                    <span><strong>소셜 기능</strong> - 모임 공유, 친구 초대</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="mt-4 p-3 bg-blue-50 border border-blue-200 rounded">
              <div class="flex items-start space-x-2">
                <i class="fas fa-info-circle text-blue-600 mt-0.5"></i>
                <div class="text-xs text-blue-800">
                  <strong>MVP → Production 전환 시 고려사항:</strong><br>
                  • 현재 Mock 데이터를 실제 API로 교체<br>
                  • 인증 시스템을 JWT 기반으로 구축<br>
                  • 업주와 고객 간 실시간 소통 채널 구축<br>
                  • 수익 구조에 따른 정산 시스템 개발
                </div>
              </div>
            </div>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderBottomNav() {
    const navItems = [
      { screen: 'home', icon: 'fas fa-home', label: '홈', guard: 'guest' },
      { screen: 'wishlist', icon: 'fas fa-heart', label: '찜', guard: 'guest' },
      { screen: 'qr', icon: 'fas fa-qrcode', label: 'QR생성', guard: 'phone_verified' },
      { screen: 'my', icon: 'fas fa-user', label: '마이', guard: 'authenticated' }
    ];
    
    return `
      <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
        <div class="flex justify-around py-2">
          ${navItems.map(item => {
            const accessCheck = this.checkAccess(item.guard);
            const isRestricted = !accessCheck.allowed;
            
            return `
              <button class="nav-item flex flex-col items-center py-2 px-3 transition-colors duration-200 relative ${
                this.currentScreen === item.screen 
                  ? 'text-blue-600' 
                  : isRestricted 
                    ? 'text-gray-400' 
                    : 'text-gray-500 hover:text-gray-700'
              }" 
                      onclick="OReeApp.instance.handleBottomNavClick('${item.screen}', '${item.guard}')">
                <i class="${item.icon} text-lg mb-1 ${isRestricted ? 'opacity-60' : ''}"></i>
                <span class="text-xs font-medium">${item.label}</span>
                ${isRestricted ? `
                  <div class="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full flex items-center justify-center">
                    <i class="fas fa-lock text-white text-xs"></i>
                  </div>
                ` : ''}
              </button>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }
  
  // 하단 네비게이션 클릭 핸들러
  handleBottomNavClick(screen, requiredLevel) {
    this.guardedNavigateTo(screen, requiredLevel);
  }

  // 유틸리티 함수들
  renderCalendar() {
    let calendar = '';
    const today = new Date();
    const month = today.getMonth();
    const year = today.getFullYear();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    // 빈 칸
    for (let i = 0; i < firstDay; i++) {
      calendar += '<div class="p-2"></div>';
    }
    
    // 날짜
    for (let day = 1; day <= daysInMonth; day++) {
      const isToday = day === today.getDate();
      const isSelected = day === 15; // 예시로 15일 선택
      calendar += `
        <div class="p-2 cursor-pointer rounded ${isSelected ? 'bg-blue-600 text-white' : isToday ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'}">
          ${day}
        </div>
      `;
    }
    
    return calendar;
  }

  // === 이벤트 핸들러들 ===

  bindOnboardingEvents() {
    // 온보딩 관련 이벤트
  }

  bindLoginEvents() {
    // 로그인 관련 이벤트
  }

  bindLocationEvents() {
    // 위치 권한 관련 이벤트
  }

  bindHomeEvents() {
    // 홈 화면 이벤트 핸들러들
    
    // 알림 버튼 클릭
    const notificationBtn = document.querySelector('.notification-btn');
    if (notificationBtn) {
      notificationBtn.addEventListener('click', () => {
        this.toggleNotifications();
      });
    }
    
    // 알림 패널 닫기
    const closeNotificationBtn = document.querySelector('.close-notifications');
    if (closeNotificationBtn) {
      closeNotificationBtn.addEventListener('click', () => {
        this.toggleNotifications();
      });
    }
    
    // 지도/목록 뷰 전환
    const viewToggleButtons = document.querySelectorAll('.view-toggle');
    viewToggleButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const viewMode = e.target.closest('button').dataset.view;
        this.switchViewMode(viewMode);
      });
    });
    
    // 필터 버튼들
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const filter = e.target.closest('button').dataset.filter;
        this.handleFilterClick(filter);
      });
    });
    
    // 검색 입력
    const searchInput = document.querySelector('[data-action="search-input"]');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.homeState.searchQuery = e.target.value;
        this.handleSearch(e.target.value);
      });
    }
    
    // 업장 핀 클릭
    const storePins = document.querySelectorAll('.store-pin');
    storePins.forEach(pin => {
      pin.addEventListener('click', (e) => {
        const storeId = parseInt(e.target.closest('button').dataset.storeId);
        this.selectStorePin(storeId);
      });
    });
    
    // 알림 필터 버튼들
    const notificationFilters = document.querySelectorAll('.notification-filter');
    notificationFilters.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const filter = e.target.dataset.filter;
        this.filterNotifications(filter);
      });
    });
    
    // 모두 읽음 버튼
    const markAllReadBtn = document.querySelector('.mark-all-read');
    if (markAllReadBtn) {
      markAllReadBtn.addEventListener('click', () => {
        this.markAllNotificationsAsRead();
      });
    }
    
    // 알림 아이템 클릭 (읽음 처리)
    const notificationItems = document.querySelectorAll('.notification-item');
    notificationItems.forEach(item => {
      item.addEventListener('click', (e) => {
        const notificationId = parseInt(e.target.closest('.notification-item').dataset.notificationId);
        this.markNotificationAsRead(notificationId);
      });
    });
  }
  
  bindStoreDetailEvents() {
    // 업장 상세 화면 이벤트 핸들러들
    
    // 찜 버튼 (이미 onclick으로 처리되지만 동적 바인딩용)
    const wishlistBtn = document.querySelector('.wishlist-btn');
    if (wishlistBtn) {
      // onclick이 있으므로 별도 처리 불필요
    }
    
    // 이미지 더보기 버튼
    const moreImagesBtn = document.querySelector('.image-gallery button');
    if (moreImagesBtn) {
      moreImagesBtn.addEventListener('click', () => {
        this.openImageGallery();
      });
    }
    
    // 메뉴 전체보기 버튼들
    const menuButtons = document.querySelectorAll('.menu-section button');
    menuButtons.forEach(btn => {
      if (btn.textContent.includes('전체보기') || btn.textContent.includes('메뉴')) {
        btn.addEventListener('click', () => {
          this.openMenuModal();
        });
      }
    });
    
    // 길찾기 버튼
    const directionsBtn = document.querySelector('.location-section button');
    if (directionsBtn) {
      directionsBtn.addEventListener('click', () => {
        this.openDirections();
      });
    }
    
    // 리뷰 전체보기 버튼
    const reviewsBtn = document.querySelector('.reviews-section button');
    if (reviewsBtn && reviewsBtn.textContent.includes('전체보기')) {
      reviewsBtn.addEventListener('click', () => {
        this.openReviewsModal();
      });
    }
    
    // 리뷰 도움됨 버튼들
    const helpfulBtns = document.querySelectorAll('.review-item button');
    helpfulBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.markReviewHelpful(btn);
      });
    });
  }
  
  // 업장 상세 관련 메서드들
  openImageGallery() {
    // 이미지 갤러리 모달 열기
    this.showToast('이미지 갤러리 (준비중)');
  }
  
  openMenuModal() {
    // 메뉴 전체보기 모달 열기
    this.showToast('메뉴 전체보기 (준비중)');
  }
  
  openDirections() {
    // 길찾기 앱 연결 또는 지도 모달
    const store = this.homeState.currentStore || this.homeState.stores[0];
    const query = encodeURIComponent(store.location);
    
    // 모바일에서는 지도 앱 열기 시도
    if (navigator.userAgent.match(/iPhone|iPad|iPod|Android/i)) {
      // 네이버 지도 또는 구글 지도로 연결
      window.open(`https://map.naver.com/v5/search/${query}`, '_blank');
    } else {
      this.showToast('길찾기 (지도 앱 연결)');
    }
  }
  
  openReviewsModal() {
    // 리뷰 전체보기 모달 열기
    this.showToast('리뷰 전체보기 (준비중)');
  }
  
  markReviewHelpful(btn) {
    // 리뷰 도움됨 처리
    btn.classList.add('text-blue-600');
    const countSpan = btn.querySelector('span');
    if (countSpan) {
      const currentCount = parseInt(countSpan.textContent.match(/\d+/)[0]) || 0;
      countSpan.textContent = `도움됨 ${currentCount + 1}`;
    }
    this.showToast('리뷰가 도움이 되었다고 표시했습니다.');
  }
  
  bindReservationEvents() {
    // 예약 화면 이벤트 핸들러들
    
    // 날짜 선택 버튼들
    const dateBtns = document.querySelectorAll('.date-btn');
    dateBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        if (!btn.disabled) {
          this.selectDate(e.target.dataset.date);
        }
      });
    });
    
    // 시간 선택 버튼들
    const timeBtns = document.querySelectorAll('.time-btn');
    timeBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        if (!btn.disabled) {
          this.selectTime(e.target.dataset.time);
        }
      });
    });
    
    // 인원 조절 버튼들
    const guestBtns = document.querySelectorAll('.guest-btn');
    guestBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const action = e.target.closest('button').dataset.action;
        this.adjustGuests(action);
      });
    });
    
    // 메모 입력
    const memoInput = document.querySelector('[data-memo-input]');
    if (memoInput) {
      memoInput.addEventListener('input', (e) => {
        this.reservationState.memo = e.target.value;
      });
    }
    
    // 환불정책 동의 체크박스
    const refundPolicyCheckbox = document.querySelector('.refund-policy-checkbox');
    if (refundPolicyCheckbox) {
      refundPolicyCheckbox.addEventListener('change', (e) => {
        this.reservationState.agreeRefundPolicy = e.target.checked;
        this.render(); // CTA 버튼 상태 업데이트
      });
    }
  }
  
  // 예약 화면 상호작용 메서드들
  selectDate(date) {
    this.reservationState.selectedDate = date;
    this.render();
  }
  
  selectTime(time) {
    this.reservationState.selectedTime = time;
    this.render();
  }
  
  adjustGuests(action) {
    if (action === 'increase') {
      this.reservationState.selectedGuests++;
    } else if (action === 'decrease' && this.reservationState.selectedGuests > 1) {
      this.reservationState.selectedGuests--;
    }
    
    // 4인 미만일 때 경고 표시
    if (this.reservationState.selectedGuests < 4) {
      // 에러 메시지는 render에서 처리
    }
    
    this.render();
  }
  
  bindPaymentEvents() {
    // 결제 화면 이벤트 핸들러들
    
    // 결제수단 선택
    const paymentMethodRadios = document.querySelectorAll('.payment-method-radio');
    paymentMethodRadios.forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.paymentState.selectedMethod = e.target.value;
        this.render();
      });
    });
    
    // 카드 정보 입력
    const cardNumberInput = document.querySelector('.card-number-input');
    if (cardNumberInput) {
      cardNumberInput.addEventListener('input', (e) => {
        // 카드번호 포맷팅 (0000-0000-0000-0000)
        let value = e.target.value.replace(/\D/g, '');
        value = value.replace(/(\d{4})(?=\d)/g, '$1-');
        e.target.value = value;
        this.paymentState.cardNumber = value;
      });
    }
    
    const cardExpiryInput = document.querySelector('.card-expiry-input');
    if (cardExpiryInput) {
      cardExpiryInput.addEventListener('input', (e) => {
        // 유효기간 포맷팅 (MM/YY)
        let value = e.target.value.replace(/\D/g, '');
        if (value.length >= 2) {
          value = value.slice(0, 2) + '/' + value.slice(2, 4);
        }
        e.target.value = value;
        this.paymentState.cardExpiry = value;
      });
    }
    
    const cardCvcInput = document.querySelector('.card-cvc-input');
    if (cardCvcInput) {
      cardCvcInput.addEventListener('input', (e) => {
        this.paymentState.cardCVC = e.target.value;
      });
    }
    
    const cardHolderInput = document.querySelector('.card-holder-input');
    if (cardHolderInput) {
      cardHolderInput.addEventListener('input', (e) => {
        this.paymentState.cardHolder = e.target.value;
      });
    }
    
    // 카드 저장 체크박스
    const saveCardCheckbox = document.querySelector('.save-card-checkbox');
    if (saveCardCheckbox) {
      saveCardCheckbox.addEventListener('change', (e) => {
        this.paymentState.saveCard = e.target.checked;
      });
    }
  }

  bindModificationEvents() {
    // 예약 변경/취소 화면의 이벤트 바인딩
    // 인원 조정 버튼들은 onclick으로 처리됨
    // 결제 수단 선택 등의 추가 이벤트가 필요한 경우 여기에 추가
    
    // 추가 결제 화면에서 결제 수단 선택
    const additionalPaymentRadios = document.querySelectorAll('input[name="payment-method"]');
    additionalPaymentRadios.forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.paymentState.selectedMethod = e.target.value;
      });
    });
  }
  
  // 결제 관련 헬퍼 메서드들 (STEP 8)
  formatReservationDate() {
    if (!this.reservationState.selectedDate) return '';
    
    const date = new Date(this.reservationState.selectedDate);
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const dayNames = ['일', '월', '화', '수', '목', '금', '토'];
    const dayName = dayNames[date.getDay()];
    
    return `${year}년 ${month}월 ${day}일 (${dayName})`;
  }
  
  getReservationUserName() {
    // 실제로는 사용자 프로필에서 가져오지만 임시로 하드코딩
    return '홍길동';
  }
  
  getReservationPhoneNumber() {
    // 실제로는 인증된 전화번호를 가져오지만 임시로 하드코딩
    return '010-1234-5678';
  }
  
  validatePaymentForm() {
    if (this.paymentState.selectedMethod === 'card') {
      return (
        this.paymentState.cardNumber.length > 0 &&
        this.paymentState.cardExpiry.length > 0 &&
        this.paymentState.cardCVC.length > 0 &&
        this.paymentState.cardHolder.length > 0
      );
    }
    return true; // 간편결제는 선택만 하면 됨
  }
  
  cancelPayment() {
    if (confirm('결제를 취소하시겠습니까?')) {
      this.navigateTo('reservation');
    }
  }
  
  processPayment() {
    if (!this.validatePaymentForm()) {
      this.showToast('결제 정보를 확인해주세요.');
      return;
    }
    
    // 결제 처리 중 상태로 변경
    this.paymentState.isProcessing = true;
    this.render();
    
    // 1초 후 예약 완료 화면으로 이동 (Stub)
    setTimeout(() => {
      this.completeBooking();
    }, 1000);
  }
  
  completeBooking() {
    // 예약 정보를 완료된 예약 목록에 추가
    const booking = {
      id: this.generateBookingId(),
      storeId: (this.homeState.currentStore || this.homeState.stores[0]).id,
      storeName: (this.homeState.currentStore || this.homeState.stores[0]).name,
      storeLocation: (this.homeState.currentStore || this.homeState.stores[0]).location,
      date: this.reservationState.selectedDate,
      time: this.reservationState.selectedTime,
      endTime: this.calculateEndTime(),
      guests: this.reservationState.selectedGuests,
      memo: this.reservationState.memo,
      totalAmount: this.calculateTotalAmount(),
      depositAmount: this.calculateDepositAmount(),
      paymentMethod: this.paymentState.selectedMethod,
      status: 'confirmed', // 'confirmed', 'cancelled', 'completed'
      createdAt: new Date().toISOString(),
      userName: this.getReservationUserName(),
      userPhone: this.getReservationPhoneNumber()
    };
    
    this.bookingState.completedBookings.push(booking);
    this.saveCompletedBookings();
    
    // 결제 상태 초기화
    this.paymentState.isProcessing = false;
    
    // 예약 완료 화면으로 이동
    this.navigateTo('booking-complete');
  }
  
  generateBookingId() {
    const now = new Date();
    const dateStr = now.getFullYear().toString().substr(-2) + 
                   (now.getMonth() + 1).toString().padStart(2, '0') + 
                   now.getDate().toString().padStart(2, '0');
    const randomStr = Math.random().toString(36).substr(2, 4).toUpperCase();
    return `OR${dateStr}${randomStr}`;
  }
  
  loadCompletedBookings() {
    try {
      const saved = localStorage.getItem('oree_completed_bookings');
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error('예약 목록 로드 실패:', error);
      return [];
    }
  }
  
  saveCompletedBookings() {
    try {
      localStorage.setItem('oree_completed_bookings', JSON.stringify(this.bookingState.completedBookings));
    } catch (error) {
      console.error('예약 목록 저장 실패:', error);
    }
  }
  
  showRefundPolicyDetail() {
    // 환불정책 상세 모달 또는 페이지로 이동
    this.showToast('환불정책 상세 페이지 (준비중)');
  }
  
  renderMyReservations() {
    const bookings = this.bookingState.completedBookings;
    const upcomingBookings = bookings.filter(booking => {
      const bookingDate = new Date(booking.date + ' ' + booking.time);
      return bookingDate > new Date() && booking.status === 'confirmed';
    });
    
    if (upcomingBookings.length === 0) {
      return `
        <!-- 예약 현황 (예약 없음) -->
        <div class="card p-4">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-900">예약 현황</h3>
            <span class="text-sm text-gray-500">0개</span>
          </div>
          
          <div class="text-center py-8">
            <i class="fas fa-calendar-times text-4xl text-gray-300 mb-3"></i>
            <p class="text-gray-500 mb-4">예정된 예약이 없습니다</p>
            <button 
              class="btn btn-primary btn-sm"
              onclick="OReeApp.instance.navigateTo('home')"
            >
              새 예약하기
            </button>
          </div>
        </div>
      `;
    }
    
    return `
      <!-- 예약 현황 -->
      <div class="card p-4">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-lg font-semibold text-gray-900">예약 현황</h3>
          <span class="text-sm text-blue-600">${upcomingBookings.length}개</span>
        </div>
        
        <div class="space-y-4">
          ${upcomingBookings.map(booking => this.renderReservationCard(booking)).join('')}
        </div>
        
        ${bookings.length > upcomingBookings.length ? `
          <div class="text-center mt-4">
            <button class="text-sm text-blue-600 hover:text-blue-700">
              전체 예약 내역 보기
            </button>
          </div>
        ` : ''}
      </div>
    `;
  }
  
  renderReservationCard(booking) {
    const bookingDate = new Date(booking.date + ' ' + booking.time);
    const isUpcoming = bookingDate > new Date();
    const daysUntil = Math.ceil((bookingDate - new Date()) / (1000 * 60 * 60 * 24));
    
    return `
      <div class="border border-gray-200 rounded-button p-4 hover:shadow-md transition-shadow">
        <!-- 예약 상태 및 날짜 -->
        <div class="flex items-center justify-between mb-3">
          <div class="flex items-center space-x-2">
            <span class="w-2 h-2 bg-green-500 rounded-full"></span>
            <span class="text-sm font-medium text-green-800">예약 확정</span>
            ${daysUntil <= 3 ? `
              <span class="bg-red-100 text-red-800 text-xs px-2 py-1 rounded">D-${daysUntil}</span>
            ` : ''}
          </div>
          <span class="text-xs text-gray-500">예약번호: ${booking.id}</span>
        </div>
        
        <!-- 업장 및 예약 정보 -->
        <div class="space-y-2 mb-4">
          <div class="flex items-center justify-between">
            <h4 class="font-medium text-gray-900">${booking.storeName}</h4>
            <span class="text-sm text-gray-600">${booking.guests}명</span>
          </div>
          
          <div class="flex items-center text-sm text-gray-600 space-x-4">
            <div class="flex items-center space-x-1">
              <i class="fas fa-calendar text-xs"></i>
              <span>${this.formatBookingDate(booking.date)}</span>
            </div>
            <div class="flex items-center space-x-1">
              <i class="fas fa-clock text-xs"></i>
              <span>${booking.time} ~ ${booking.endTime}</span>
            </div>
          </div>
          
          <div class="flex items-center justify-between text-sm">
            <span class="text-gray-600">보증금 결제완료</span>
            <span class="font-medium text-blue-600">${booking.depositAmount.toLocaleString()}원</span>
          </div>
        </div>
        
        <!-- 액션 버튼들 -->
        <div class="flex space-x-2">
          <button 
            class="flex-1 py-2 px-3 bg-blue-50 text-blue-600 text-sm rounded-button hover:bg-blue-100 transition-colors"
            onclick="OReeApp.instance.modifyReservation('${booking.id}')"
          >
            예약변경
          </button>
          <button 
            class="flex-1 py-2 px-3 bg-red-50 text-red-600 text-sm rounded-button hover:bg-red-100 transition-colors"
            onclick="OReeApp.instance.cancelReservation('${booking.id}')"
          >
            예약취소
          </button>
        </div>
        
        <!-- 입장 QR 버튼 (예약일 당일 또는 1일 전부터) -->
        ${daysUntil <= 1 ? `
          <button 
            class="w-full mt-2 py-2 px-3 bg-green-600 text-white text-sm rounded-button hover:bg-green-700 transition-colors"
            onclick="OReeApp.instance.showQRCode('${booking.id}')"
          >
            <i class="fas fa-qrcode mr-1"></i>
            입장 QR코드 보기
          </button>
        ` : ''}
      </div>
    `;
  }
  
  formatBookingDate(dateStr) {
    const date = new Date(dateStr);
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const dayNames = ['일', '월', '화', '수', '목', '금', '토'];
    const dayName = dayNames[date.getDay()];
    
    return `${month}/${day}(${dayName})`;
  }
  
  modifyReservation(bookingId) {
    const booking = this.bookingState.completedBookings.find(b => b.id === bookingId);
    if (!booking) {
      this.showToast('예약 정보를 찾을 수 없습니다.');
      return;
    }
    
    // 예약일 3일 전까지만 변경 가능
    const bookingDate = new Date(booking.date + ' ' + booking.time);
    const hoursUntil = (bookingDate - new Date()) / (1000 * 60 * 60);
    
    if (hoursUntil < 72) {
      this.showToast('예약일 3일 전까지만 변경 가능합니다.');
      return;
    }
    
    // 기존 예약 정보를 수정 상태로 로드
    this.modificationState.currentBooking = booking;
    this.modificationState.originalGuests = booking.guests;
    this.modificationState.newGuests = booking.guests;
    this.modificationState.isModifying = true;
    
    // 예약 변경 화면으로 이동
    this.navigateTo('modify-reservation');
  }
  
  cancelReservation(bookingId) {
    const booking = this.bookingState.completedBookings.find(b => b.id === bookingId);
    if (!booking) {
      this.showToast('예약 정보를 찾을 수 없습니다.');
      return;
    }
    
    // 취소 상태 설정
    this.modificationState.currentBooking = booking;
    this.modificationState.isCancelling = true;
    
    // 취소 화면으로 이동
    this.navigateTo('cancel-reservation');
  }
  
  showQRCode(bookingId) {
    // QR 코드 화면으로 이동하면서 예약 정보 전달
    this.navigateTo('qr');
  }

  // STEP 10: 정책 페이지 연결
  showRefundPolicyDetail() {
    this.navigateTo('refund-policy');
  }

  // STEP 11: QR/PIN 생성 및 관리
  generateNewQR() {
    this.qrState.isGenerating = true;
    
    // QR 코드와 PIN 생성
    const timestamp = Date.now();
    const randomId = Math.random().toString(36).substring(2, 15);
    
    // QR 데이터 생성 (실제로는 암호화된 예약 정보)
    this.qrState.currentQR = `ORee-${timestamp}-${randomId}`;
    
    // 4자리 PIN 생성
    this.qrState.currentPIN = Math.floor(1000 + Math.random() * 9000).toString();
    
    // 유효기간 설정 (3분)
    this.qrState.expiryTime = new Date(Date.now() + this.qrState.validityMinutes * 60 * 1000);
    
    // 자동 갱신 타이머 설정
    this.setupQRRefreshTimer();
    
    this.qrState.isGenerating = false;
    
    // 화면 업데이트
    if (this.currentScreen === 'qr') {
      this.render();
    }
  }

  setupQRRefreshTimer() {
    // 기존 타이머 정리
    if (this.qrState.refreshInterval) {
      clearInterval(this.qrState.refreshInterval);
    }
    
    // 1초마다 체크하여 만료되면 자동 갱신
    this.qrState.refreshInterval = setInterval(() => {
      if (this.isQRExpired()) {
        this.generateNewQR();
      } else if (this.currentScreen === 'qr') {
        // 현재 QR 화면에 있으면 시간 표시 업데이트
        this.render();
      }
    }, 1000);
  }

  isQRExpired() {
    if (!this.qrState.expiryTime) return true;
    return new Date() >= this.qrState.expiryTime;
  }

  getRemainingTime() {
    if (!this.qrState.expiryTime) return 0;
    const remaining = Math.max(0, Math.floor((this.qrState.expiryTime - new Date()) / 1000));
    return remaining;
  }

  refreshQR() {
    if (this.qrState.isGenerating) return;
    this.generateNewQR();
    this.showToast('QR 코드가 갱신되었습니다');
  }

  renderQRPattern() {
    // QR 패턴을 QR 데이터를 기반으로 일관되게 생성
    const seed = this.qrState.currentQR;
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
      const char = seed.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    
    const pattern = [];
    for (let i = 0; i < 64; i++) {
      const isBlack = ((hash + i) * 2654435761) % 2 === 0;
      pattern.push(`<div class="bg-${isBlack ? 'gray-900' : 'white'} rounded-sm"></div>`);
    }
    
    return `
      <div class="w-48 h-48 rounded grid grid-cols-8 gap-1 p-2">
        ${pattern.join('')}
      </div>
    `;
  }

  renderLoadingQR() {
    return `
      <div class="w-48 h-48 flex items-center justify-center">
        <div class="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
      </div>
    `;
  }

  getActiveBooking() {
    // 현재 활성 예약 정보 반환 (가장 최근 예약)
    const bookings = this.bookingState.completedBookings;
    const activeBookings = bookings.filter(booking => {
      const bookingDate = new Date(booking.date + ' ' + booking.time);
      return bookingDate > new Date() && booking.status === 'confirmed';
    });
    
    return activeBookings.length > 0 ? activeBookings[0] : null;
  }

  // QR 화면 종료시 타이머 정리
  cleanupQRTimer() {
    if (this.qrState.refreshInterval) {
      clearInterval(this.qrState.refreshInterval);
      this.qrState.refreshInterval = null;
    }
  }

  // STEP 9: 예약변경/취소 관련 메서드들
  adjustNewGuests(change) {
    const newCount = this.modificationState.newGuests + change;
    if (newCount >= 4 && newCount <= 100) { // 최소 4명, 최대 100명
      this.modificationState.newGuests = newCount;
      
      // 보증금 차이 계산
      const guestDifference = newCount - this.modificationState.originalGuests;
      this.modificationState.guestDifference = guestDifference;
      this.modificationState.additionalDeposit = guestDifference > 0 ? guestDifference * 3000 : 0;
      this.modificationState.refundAmount = guestDifference < 0 ? Math.abs(guestDifference) * 3000 : 0;
      
      this.render();
    }
  }

  confirmModification() {
    const guestDifference = this.modificationState.guestDifference;
    
    if (guestDifference === 0) {
      this.showToast('변경사항이 없습니다.');
      return;
    }
    
    if (guestDifference > 0) {
      // 인원 증가 - 추가 결제 필요
      this.navigateTo('deposit-payment');
    } else {
      // 인원 감소 - 바로 변경 처리
      this.processModification();
    }
  }

  processAdditionalPayment() {
    // 1초 로딩 시뮬레이션
    this.paymentState.isProcessing = true;
    
    // 로딩 화면 표시
    const app = document.getElementById('app');
    app.innerHTML = this.renderPaymentProcessing('추가 보증금 결제 중...');
    
    setTimeout(() => {
      this.paymentState.isProcessing = false;
      this.processModification();
    }, 1000);
  }

  processModification() {
    const booking = this.modificationState.currentBooking;
    const newGuests = this.modificationState.newGuests;
    const guestDifference = this.modificationState.guestDifference;
    
    // 예약 정보 업데이트
    booking.guests = newGuests;
    booking.depositAmount += this.modificationState.additionalDeposit - this.modificationState.refundAmount;
    
    // 변경 이력 추가
    if (!booking.modifications) booking.modifications = [];
    booking.modifications.push({
      date: new Date().toISOString(),
      type: guestDifference > 0 ? 'increase' : 'decrease',
      guestChange: guestDifference,
      depositChange: this.modificationState.additionalDeposit - this.modificationState.refundAmount
    });
    
    // 저장
    this.saveCompletedBookings();
    
    // 상태 초기화
    this.resetModificationState();
    
    // 마이페이지로 돌아가기
    this.navigateTo('my');
    this.showToast(`예약이 변경되었습니다. (${newGuests}명)`);
  }

  confirmCancellation() {
    const booking = this.modificationState.currentBooking;
    if (!booking) return;
    
    const bookingDate = new Date(booking.date + ' ' + booking.time);
    const hoursUntil = (bookingDate - new Date()) / (1000 * 60 * 60);
    
    let refundRate = 0;
    if (hoursUntil >= 72) refundRate = 100;
    else if (hoursUntil >= 24) refundRate = 70;
    else if (hoursUntil >= 4) refundRate = 50;
    
    const refundAmount = Math.floor(booking.depositAmount * (refundRate / 100));
    
    if (confirm(`정말로 예약을 취소하시겠습니까?\n\n환불 금액: ${refundAmount.toLocaleString()}원 (${refundRate}%)\n\n취소 후에는 되돌릴 수 없습니다.`)) {
      // 예약 상태 변경
      booking.status = 'cancelled';
      booking.cancelledAt = new Date().toISOString();
      booking.refundAmount = refundAmount;
      
      // 저장
      this.saveCompletedBookings();
      
      // 상태 초기화
      this.resetModificationState();
      
      // 마이페이지로 돌아가기
      this.navigateTo('my');
      this.showToast('예약이 취소되었습니다.');
    }
  }

  showRefundGuide() {
    this.modificationState.showRefundGuide = true;
    
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50';
    modal.innerHTML = `
      <div class="bg-white rounded-lg max-w-md w-full p-6">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-lg font-semibold text-gray-900">환불 정책 안내</h3>
          <button onclick="this.closest('.fixed').remove()" class="text-gray-400 hover:text-gray-600">
            <i class="fas fa-times"></i>
          </button>
        </div>
        
        <div class="space-y-4 text-sm">
          <div>
            <h4 class="font-medium text-gray-900 mb-2">인원 감소 시 환불 절차</h4>
            <ul class="space-y-1 text-gray-600 list-disc list-inside">
              <li>변경 요청 즉시 처리</li>
              <li>환불금은 업주 승인 후 지급</li>
              <li>승인까지 최대 3영업일 소요</li>
              <li>원래 결제 수단으로 환불</li>
            </ul>
          </div>
          
          <div>
            <h4 class="font-medium text-gray-900 mb-2">환불 제한사항</h4>
            <ul class="space-y-1 text-gray-600 list-disc list-inside">
              <li>예약일 3일 전까지만 가능</li>
              <li>최소 4명 이상 유지 필수</li>
              <li>업주가 거부 시 환불 불가</li>
            </ul>
          </div>
          
          <div class="p-3 bg-yellow-50 border border-yellow-200 rounded">
            <p class="text-yellow-800 text-xs">
              <strong>주의:</strong> 업주 승인이 필요한 사항이므로 환불이 보장되지 않습니다.
            </p>
          </div>
        </div>
        
        <button 
          onclick="this.closest('.fixed').remove()"
          class="w-full mt-4 py-2 bg-blue-600 text-white rounded-button hover:bg-blue-700"
        >
          확인
        </button>
      </div>
    `;
    
    document.body.appendChild(modal);
  }

  toggleCancellationPolicy() {
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50';
    modal.innerHTML = `
      <div class="bg-white rounded-lg max-w-md w-full p-6">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-lg font-semibold text-gray-900">취소 정책 상세</h3>
          <button onclick="this.closest('.fixed').remove()" class="text-gray-400 hover:text-gray-600">
            <i class="fas fa-times"></i>
          </button>
        </div>
        
        <div class="space-y-4 text-sm">
          <div class="p-3 bg-green-50 border border-green-200 rounded">
            <div class="flex justify-between items-center">
              <span class="font-medium text-green-900">예약일 3일 전까지</span>
              <span class="text-green-600 font-bold">100% 환불</span>
            </div>
            <p class="text-green-800 text-xs mt-1">수수료 없이 전액 환불</p>
          </div>
          
          <div class="p-3 bg-blue-50 border border-blue-200 rounded">
            <div class="flex justify-between items-center">
              <span class="font-medium text-blue-900">예약일 1일 전까지</span>
              <span class="text-blue-600 font-bold">70% 환불</span>
            </div>
            <p class="text-blue-800 text-xs mt-1">30% 취소 수수료 적용</p>
          </div>
          
          <div class="p-3 bg-orange-50 border border-orange-200 rounded">
            <div class="flex justify-between items-center">
              <span class="font-medium text-orange-900">당일 4시간 전까지</span>
              <span class="text-orange-600 font-bold">50% 환불</span>
            </div>
            <p class="text-orange-800 text-xs mt-1">50% 취소 수수료 적용</p>
          </div>
          
          <div class="p-3 bg-red-50 border border-red-200 rounded">
            <div class="flex justify-between items-center">
              <span class="font-medium text-red-900">당일 4시간 이내</span>
              <span class="text-red-600 font-bold">환불 불가</span>
            </div>
            <p class="text-red-800 text-xs mt-1">정책상 환불 불가능</p>
          </div>
          
          <div class="p-3 bg-gray-50 border border-gray-200 rounded">
            <h4 class="font-medium text-gray-900 mb-2">추가 안내사항</h4>
            <ul class="space-y-1 text-gray-600 text-xs list-disc list-inside">
              <li>환불 처리: 3-5영업일</li>
              <li>환불 수단: 원래 결제 수단</li>
              <li>부분 취소: 불가 (전체 취소만)</li>
              <li>천재지변 시: 별도 정책 적용</li>
            </ul>
          </div>
        </div>
        
        <button 
          onclick="this.closest('.fixed').remove()"
          class="w-full mt-4 py-2 bg-blue-600 text-white rounded-button hover:bg-blue-700"
        >
          확인
        </button>
      </div>
    `;
    
    document.body.appendChild(modal);
  }

  resetModificationState() {
    this.modificationState = {
      currentBooking: null,
      originalGuests: 0,
      newGuests: 0,
      guestDifference: 0,
      additionalDeposit: 0,
      refundAmount: 0,
      isModifying: false,
      isCancelling: false,
      showDepositPopup: false,
      showRefundGuide: false,
      showCancellationPolicy: false
    };
  }

  renderError(message) {
    return `
      <div class="pb-20">
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('my')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">오류</h1>
            <div></div>
          </div>
        </div>
        
        <div class="p-4">
          <div class="card p-6 text-center">
            <i class="fas fa-exclamation-triangle text-4xl text-red-500 mb-4"></i>
            <h3 class="text-lg font-semibold text-gray-900 mb-2">오류가 발생했습니다</h3>
            <p class="text-gray-600 mb-6">${message}</p>
            <button 
              class="btn btn-primary"
              onclick="OReeApp.instance.navigateTo('my')"
            >
              돌아가기
            </button>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }
  
  // STEP 10: 정책 페이지들 렌더링
  renderPolicies() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('my')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">정책 및 약관</h1>
            <div></div>
          </div>
        </div>
        
        <div class="p-4 space-y-4">
          <!-- 정책 목록 -->
          <button 
            onclick="OReeApp.instance.navigateTo('refund-policy')"
            class="w-full flex items-center justify-between p-4 bg-white rounded-button border border-gray-200 hover:shadow-md transition-shadow"
          >
            <div class="flex items-center space-x-3">
              <div class="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <i class="fas fa-undo text-red-600"></i>
              </div>
              <div class="text-left">
                <h3 class="font-semibold text-gray-900">환불 정책</h3>
                <p class="text-sm text-gray-600">취소 시점별 환불 규정</p>
              </div>
            </div>
            <i class="fas fa-chevron-right text-gray-400"></i>
          </button>
          
          <button 
            onclick="OReeApp.instance.navigateTo('group-policy')"
            class="w-full flex items-center justify-between p-4 bg-white rounded-button border border-gray-200 hover:shadow-md transition-shadow"
          >
            <div class="flex items-center space-x-3">
              <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <i class="fas fa-users text-blue-600"></i>
              </div>
              <div class="text-left">
                <h3 class="font-semibold text-gray-900">인원 변동 정책</h3>
                <p class="text-sm text-gray-600">최소 인원 및 변동 규정</p>
              </div>
            </div>
            <i class="fas fa-chevron-right text-gray-400"></i>
          </button>
          
          <!-- 요약 카드 -->
          <div class="card p-4 bg-gray-50">
            <h3 class="font-semibold text-gray-900 mb-3">
              <i class="fas fa-info-circle text-blue-600 mr-2"></i>
              핵심 정책 요약
            </h3>
            
            <div class="space-y-3 text-sm">
              <div class="flex justify-between items-center">
                <span class="text-gray-600">최소 예약 인원</span>
                <span class="font-medium text-blue-600">4명 이상</span>
              </div>
              <div class="flex justify-between items-center">
                <span class="text-gray-600">3일 전 취소</span>
                <span class="font-medium text-green-600">100% 환불</span>
              </div>
              <div class="flex justify-between items-center">
                <span class="text-gray-600">1일 전 취소</span>
                <span class="font-medium text-orange-600">50% 환불</span>
              </div>
              <div class="flex justify-between items-center">
                <span class="text-gray-600">당일 취소/노쇼</span>
                <span class="font-medium text-red-600">환불 불가</span>
              </div>
            </div>
          </div>
          
          <!-- 중요 안내 -->
          <div class="card p-4 bg-orange-50 border border-orange-200">
            <div class="flex items-start space-x-3">
              <i class="fas fa-exclamation-triangle text-orange-600 mt-0.5"></i>
              <div class="text-sm">
                <p class="text-orange-900 font-medium mb-1">중요 안내</p>
                <p class="text-orange-800">
                  모든 정책은 예약 시점에 동의한 내용이 적용되며, 
                  변경 시 사전 공지를 통해 안내드립니다.
                </p>
              </div>
            </div>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderRefundPolicy() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('policies')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">환불 정책</h1>
            <button onclick="OReeApp.instance.navigateTo('group-policy')" class="text-blue-600">
              <i class="fas fa-users"></i>
            </button>
          </div>
        </div>
        
        <div class="p-4 space-y-6">
          <!-- 정책 개요 -->
          <div class="card p-4">
            <div class="flex items-center space-x-2 mb-3">
              <i class="fas fa-shield-alt text-blue-600"></i>
              <h2 class="text-lg font-semibold text-gray-900">환불 정책 개요</h2>
            </div>
            <p class="text-sm text-gray-600 leading-relaxed">
              예약 취소 시점에 따라 환불 금액이 차등 적용됩니다. 
              모든 환불은 보증금 기준으로 계산되며, 결제 수단으로 자동 환불됩니다.
            </p>
          </div>
          
          <!-- 환불 단계별 정책 -->
          <div class="space-y-4">
            <h2 class="text-lg font-semibold text-gray-900">시점별 환불 규정</h2>
            
            <!-- 3일 전 -->
            <div class="card p-4 border-l-4 border-green-500">
              <div class="flex items-center justify-between mb-2">
                <h3 class="font-semibold text-green-900">예약일 3일 전까지</h3>
                <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                  100% 환불
                </span>
              </div>
              <p class="text-sm text-green-800 mb-2">
                수수료 없이 전액 환불해드립니다.
              </p>
              <div class="text-xs text-green-700 bg-green-50 p-2 rounded">
                <strong>예시:</strong> 3월 15일 예약 → 3월 12일 23:59까지 취소 시
              </div>
            </div>
            
            <!-- 1일 전 -->
            <div class="card p-4 border-l-4 border-orange-500">
              <div class="flex items-center justify-between mb-2">
                <h3 class="font-semibold text-orange-900">예약일 1일 전까지</h3>
                <span class="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-sm font-medium">
                  50% 환불
                </span>
              </div>
              <p class="text-sm text-orange-800 mb-2">
                보증금의 50%를 환불하고, 50%는 취소 수수료로 적용됩니다.
              </p>
              <div class="text-xs text-orange-700 bg-orange-50 p-2 rounded">
                <strong>예시:</strong> 3월 15일 예약 → 3월 14일 23:59까지 취소 시
              </div>
            </div>
            
            <!-- 당일 취소 -->
            <div class="card p-4 border-l-4 border-red-500">
              <div class="flex items-center justify-between mb-2">
                <h3 class="font-semibold text-red-900">예약 당일 취소</h3>
                <span class="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">
                  환불 불가
                </span>
              </div>
              <p class="text-sm text-red-800 mb-2">
                당일 취소 시 보증금 전액이 취소 수수료로 적용됩니다.
              </p>
              <div class="text-xs text-red-700 bg-red-50 p-2 rounded">
                <strong>예시:</strong> 3월 15일 예약 → 3월 15일 00:00 이후 취소 시
              </div>
            </div>
            
            <!-- 노쇼 -->
            <div class="card p-4 border-l-4 border-gray-500">
              <div class="flex items-center justify-between mb-2">
                <h3 class="font-semibold text-gray-900">노쇼 (No-Show)</h3>
                <span class="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
                  보증금 소멸
                </span>
              </div>
              <p class="text-sm text-gray-800 mb-2">
                예약 시간 후 30분까지 입장하지 않을 경우 노쇼로 처리됩니다.
              </p>
              <div class="text-xs text-gray-700 bg-gray-50 p-2 rounded">
                <strong>적용:</strong> 예약 시간 + 30분 경과 시 자동 처리
              </div>
            </div>
          </div>
          
          <!-- 환불 처리 안내 -->
          <div class="card p-4">
            <h3 class="font-semibold text-gray-900 mb-3">
              <i class="fas fa-clock text-blue-600 mr-2"></i>
              환불 처리 안내
            </h3>
            
            <div class="space-y-3 text-sm">
              <div class="flex justify-between">
                <span class="text-gray-600">환불 처리 기간</span>
                <span class="font-medium">3-5 영업일</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">환불 방법</span>
                <span class="font-medium">원결제 수단</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">환불 수수료</span>
                <span class="font-medium">정책에 따라 차등 적용</span>
              </div>
            </div>
            
            <div class="mt-4 p-3 bg-blue-50 border border-blue-200 rounded">
              <p class="text-sm text-blue-800">
                <i class="fas fa-info-circle mr-1"></i>
                <strong>참고:</strong> 환불 처리 완료 시 SMS/앱 알림으로 안내해드립니다.
              </p>
            </div>
          </div>
          
          <!-- 특별 상황 -->
          <div class="card p-4">
            <h3 class="font-semibold text-gray-900 mb-3">
              <i class="fas fa-weather-rain text-purple-600 mr-2"></i>
              특별 상황 정책
            </h3>
            
            <div class="space-y-3 text-sm">
              <div class="p-3 bg-purple-50 border border-purple-200 rounded">
                <p class="text-purple-900 font-medium mb-1">천재지변 및 불가항력</p>
                <p class="text-purple-800">
                  태풍, 지진 등 천재지변이나 정부 방역 지침에 의한 취소 시 
                  별도 정책을 적용하여 환불해드립니다.
                </p>
              </div>
              
              <div class="p-3 bg-yellow-50 border border-yellow-200 rounded">
                <p class="text-yellow-900 font-medium mb-1">업장 사정으로 인한 취소</p>
                <p class="text-yellow-800">
                  업장 측 사정으로 예약이 취소되는 경우 전액 환불 및 
                  추가 보상을 제공합니다.
                </p>
              </div>
            </div>
          </div>
          
          <!-- 연관 정책 링크 -->
          <div class="flex space-x-3">
            <button 
              onclick="OReeApp.instance.navigateTo('group-policy')"
              class="flex-1 py-3 px-4 bg-blue-600 text-white rounded-button hover:bg-blue-700 transition-colors"
            >
              <i class="fas fa-users mr-2"></i>
              인원 변동 정책
            </button>
            <button 
              onclick="OReeApp.instance.navigateTo('policies')"
              class="flex-1 py-3 px-4 bg-gray-200 text-gray-700 rounded-button hover:bg-gray-300 transition-colors"
            >
              <i class="fas fa-list mr-2"></i>
              전체 정책
            </button>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderGroupPolicy() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('policies')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">인원 변동 정책</h1>
            <button onclick="OReeApp.instance.navigateTo('refund-policy')" class="text-blue-600">
              <i class="fas fa-undo"></i>
            </button>
          </div>
        </div>
        
        <div class="p-4 space-y-6">
          <!-- 정책 개요 -->
          <div class="card p-4">
            <div class="flex items-center space-x-2 mb-3">
              <i class="fas fa-users text-blue-600"></i>
              <h2 class="text-lg font-semibold text-gray-900">인원 변동 정책 개요</h2>
            </div>
            <p class="text-sm text-gray-600 leading-relaxed">
              ORee는 단체 예약 전용 서비스로, 최소 4인 이상만 예약이 가능합니다. 
              예약 후 인원 변동 시 아래 정책이 적용됩니다.
            </p>
          </div>
          
          <!-- 기본 원칙 -->
          <div class="card p-4 bg-blue-50 border border-blue-200">
            <h3 class="font-semibold text-blue-900 mb-3">
              <i class="fas fa-star text-blue-600 mr-2"></i>
              기본 원칙
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div class="flex items-center space-x-2">
                <i class="fas fa-check-circle text-blue-600"></i>
                <span class="text-blue-800">최소 4인 기준 유지</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check-circle text-blue-600"></i>
                <span class="text-blue-800">예약일 3일 전까지만 변경</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check-circle text-blue-600"></i>
                <span class="text-blue-800">보증금은 인당 기준 계산</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check-circle text-blue-600"></i>
                <span class="text-blue-800">업주 승인 시스템 적용</span>
              </div>
            </div>
          </div>
          
          <!-- 인원 증가 -->
          <div class="card p-4">
            <h3 class="font-semibold text-gray-900 mb-4">
              <i class="fas fa-plus-circle text-green-600 mr-2"></i>
              인원 증가 시 정책
            </h3>
            
            <div class="space-y-4">
              <div class="p-3 bg-green-50 border border-green-200 rounded">
                <h4 class="font-medium text-green-900 mb-2">추가 보증금 결제</h4>
                <div class="text-sm text-green-800 space-y-1">
                  <p>• 증가 인원수 × 개인 보증금(3,000원) 추가 결제</p>
                  <p>• 결제 완료 후 즉시 변경 확정</p>
                  <p>• 업장 수용 인원 내에서만 가능</p>
                </div>
              </div>
              
              <div class="bg-gray-50 p-3 rounded text-sm">
                <strong>예시:</strong> 10명 → 13명 증가 시
                <br>추가 보증금: 3명 × 3,000원 = 9,000원
              </div>
            </div>
          </div>
          
          <!-- 인원 감소 -->
          <div class="card p-4">
            <h3 class="font-semibold text-gray-900 mb-4">
              <i class="fas fa-minus-circle text-orange-600 mr-2"></i>
              인원 감소 시 정책
            </h3>
            
            <div class="space-y-4">
              <!-- 4인 이상 유지 -->
              <div class="p-3 bg-orange-50 border border-orange-200 rounded">
                <h4 class="font-medium text-orange-900 mb-2">최소 인원 조건</h4>
                <div class="text-sm text-orange-800 space-y-1">
                  <p>• 감소 후에도 최소 4인 이상 유지 필수</p>
                  <p>• 4인 미만으로 감소 불가 (예약 취소만 가능)</p>
                  <p>• 감소분 보증금은 조건부 환불</p>
                </div>
              </div>
              
              <!-- 보증금 처리 -->
              <div class="space-y-3">
                <h4 class="font-medium text-gray-900">보증금 처리 방식</h4>
                
                <div class="p-3 border border-gray-200 rounded">
                  <div class="flex items-center justify-between mb-2">
                    <span class="font-medium text-gray-900">충족 인원 내 감소</span>
                    <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-sm">환불 가능</span>
                  </div>
                  <p class="text-sm text-gray-600">
                    업장 최소 요구 인원을 충족하는 범위 내 감소 시 
                    업주 승인 후 부분 환불 가능
                  </p>
                </div>
                
                <div class="p-3 border border-gray-200 rounded">
                  <div class="flex items-center justify-between mb-2">
                    <span class="font-medium text-gray-900">부족 인원분 감소</span>
                    <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-sm">보증금 소멸</span>
                  </div>
                  <p class="text-sm text-gray-600">
                    업장이 요구하는 최소 인원 미달 시 
                    해당 부족분 보증금은 소멸 처리
                  </p>
                </div>
              </div>
              
              <div class="bg-gray-50 p-3 rounded text-sm">
                <strong>예시:</strong> 15명 → 8명 감소 시 (업장 최소 10명 요구)
                <br>• 환불 가능: 5명분 (15→10명)
                <br>• 보증금 소멸: 2명분 (10→8명 부족분)
              </div>
            </div>
          </div>
          
          <!-- 환불 절차 -->
          <div class="card p-4">
            <h3 class="font-semibold text-gray-900 mb-4">
              <i class="fas fa-process text-purple-600 mr-2"></i>
              환불 처리 절차
            </h3>
            
            <div class="space-y-3">
              <div class="flex items-start space-x-3">
                <div class="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span class="text-xs font-bold text-blue-600">1</span>
                </div>
                <div class="text-sm">
                  <p class="font-medium text-gray-900">인원 변경 요청</p>
                  <p class="text-gray-600">앱에서 인원 감소 신청</p>
                </div>
              </div>
              
              <div class="flex items-start space-x-3">
                <div class="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span class="text-xs font-bold text-blue-600">2</span>
                </div>
                <div class="text-sm">
                  <p class="font-medium text-gray-900">업주 검토</p>
                  <p class="text-gray-600">업장 운영진의 승인/거부 검토 (최대 24시간)</p>
                </div>
              </div>
              
              <div class="flex items-start space-x-3">
                <div class="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span class="text-xs font-bold text-blue-600">3</span>
                </div>
                <div class="text-sm">
                  <p class="font-medium text-gray-900">결과 안내</p>
                  <p class="text-gray-600">승인 시 환불 처리, 거부 시 사유 안내</p>
                </div>
              </div>
              
              <div class="flex items-start space-x-3">
                <div class="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span class="text-xs font-bold text-blue-600">4</span>
                </div>
                <div class="text-sm">
                  <p class="font-medium text-gray-900">환불 완료</p>
                  <p class="text-gray-600">승인된 금액 자동 환불 (3-5영업일)</p>
                </div>
              </div>
            </div>
          </div>
          
          <!-- 주의사항 -->
          <div class="card p-4 bg-red-50 border border-red-200">
            <h3 class="font-semibold text-red-900 mb-3">
              <i class="fas fa-exclamation-triangle text-red-600 mr-2"></i>
              주의사항
            </h3>
            
            <div class="space-y-2 text-sm text-red-800">
              <div class="flex items-start space-x-2">
                <i class="fas fa-dot-circle text-red-600 mt-1 text-xs"></i>
                <p>인원 변경은 예약일 3일 전까지만 가능합니다</p>
              </div>
              <div class="flex items-start space-x-2">
                <i class="fas fa-dot-circle text-red-600 mt-1 text-xs"></i>
                <p>업주 거부 시 환불이 불가능할 수 있습니다</p>
              </div>
              <div class="flex items-start space-x-2">
                <i class="fas fa-dot-circle text-red-600 mt-1 text-xs"></i>
                <p>4인 미만 감소 시 예약 전체 취소만 가능합니다</p>
              </div>
              <div class="flex items-start space-x-2">
                <i class="fas fa-dot-circle text-red-600 mt-1 text-xs"></i>
                <p>부족 인원분 보증금은 반환되지 않습니다</p>
              </div>
            </div>
          </div>
          
          <!-- 연관 정책 링크 -->
          <div class="flex space-x-3">
            <button 
              onclick="OReeApp.instance.navigateTo('refund-policy')"
              class="flex-1 py-3 px-4 bg-blue-600 text-white rounded-button hover:bg-blue-700 transition-colors"
            >
              <i class="fas fa-undo mr-2"></i>
              환불 정책
            </button>
            <button 
              onclick="OReeApp.instance.navigateTo('policies')"
              class="flex-1 py-3 px-4 bg-gray-200 text-gray-700 rounded-button hover:bg-gray-300 transition-colors"
            >
              <i class="fas fa-list mr-2"></i>
              전체 정책
            </button>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  // STEP 9: 예약변경/취소 화면 렌더링
  renderModifyReservation() {
    const booking = this.modificationState.currentBooking;
    if (!booking) {
      return this.renderError('예약 정보를 찾을 수 없습니다.');
    }
    
    const guestDifference = this.modificationState.newGuests - this.modificationState.originalGuests;
    const additionalDeposit = guestDifference > 0 ? guestDifference * 3000 : 0; // 인당 3천원 보증금
    const refundAmount = guestDifference < 0 ? Math.abs(guestDifference) * 3000 : 0;
    
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('my')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">예약 변경</h1>
            <div></div>
          </div>
        </div>
        
        <div class="p-4 space-y-6">
          <!-- 기존 예약 정보 -->
          <div class="card p-4">
            <div class="flex items-center space-x-2 mb-3">
              <i class="fas fa-info-circle text-blue-600"></i>
              <h3 class="font-semibold text-gray-900">기존 예약 정보</h3>
            </div>
            
            <div class="space-y-2 text-sm bg-gray-50 rounded-lg p-3">
              <div class="flex justify-between">
                <span class="text-gray-600">업장</span>
                <span class="font-medium">${booking.storeName}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">날짜</span>
                <span class="font-medium">${this.formatBookingDate(booking.date)}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">시간</span>
                <span class="font-medium">${booking.time} ~ ${booking.endTime}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">기존 인원</span>
                <span class="font-medium text-blue-600">${booking.guests}명</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">기존 보증금</span>
                <span class="font-medium">${booking.depositAmount.toLocaleString()}원</span>
              </div>
            </div>
            
            <div class="mt-3 p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <div class="flex items-start space-x-2">
                <i class="fas fa-exclamation-triangle text-orange-600 mt-0.5 text-sm"></i>
                <div class="text-sm">
                  <p class="text-orange-900 font-medium mb-1">변경 가능 기한</p>
                  <p class="text-orange-800">예약일 3일 전까지만 인원 변경이 가능합니다.</p>
                  <p class="text-orange-800">미 변경 시 보증금이 소멸될 수 있습니다.</p>
                </div>
              </div>
            </div>
          </div>
          
          <!-- 인원 수 변경 -->
          <div class="card p-4">
            <h3 class="font-semibold text-gray-900 mb-4">
              <i class="fas fa-users text-blue-600 mr-2"></i>
              인원 수 변경
            </h3>
            
            <div class="flex items-center justify-center space-x-4 mb-4">
              <button 
                class="w-10 h-10 rounded-full bg-gray-200 hover:bg-gray-300 flex items-center justify-center"
                onclick="OReeApp.instance.adjustNewGuests(-1)"
                ${this.modificationState.newGuests <= 4 ? 'disabled' : ''}
              >
                <i class="fas fa-minus text-gray-600"></i>
              </button>
              
              <div class="flex-1 text-center">
                <div class="text-2xl font-bold text-gray-900">${this.modificationState.newGuests}명</div>
                <div class="text-sm text-gray-500">변경할 인원</div>
              </div>
              
              <button 
                class="w-10 h-10 rounded-full bg-blue-600 hover:bg-blue-700 flex items-center justify-center"
                onclick="OReeApp.instance.adjustNewGuests(1)"
              >
                <i class="fas fa-plus text-white"></i>
              </button>
            </div>
            
            ${guestDifference !== 0 ? `
              <div class="p-3 rounded-lg ${guestDifference > 0 ? 'bg-blue-50 border border-blue-200' : 'bg-green-50 border border-green-200'}">
                <div class="flex items-center justify-between">
                  <span class="text-sm ${guestDifference > 0 ? 'text-blue-900' : 'text-green-900'}">
                    ${guestDifference > 0 ? '증가' : '감소'}: ${Math.abs(guestDifference)}명
                  </span>
                  <span class="font-medium ${guestDifference > 0 ? 'text-blue-600' : 'text-green-600'}">
                    ${guestDifference > 0 ? '+' : '-'}${Math.abs(guestDifference * 3000).toLocaleString()}원
                  </span>
                </div>
              </div>
            ` : ''}
          </div>
          
          <!-- 보증금 변경 안내 -->
          ${guestDifference !== 0 ? `
            <div class="card p-4">
              <h3 class="font-semibold text-gray-900 mb-3">
                <i class="fas fa-calculator text-green-600 mr-2"></i>
                보증금 변경 내역
              </h3>
              
              <div class="space-y-3">
                <div class="flex justify-between text-sm">
                  <span class="text-gray-600">기존 보증금 (${this.modificationState.originalGuests}명)</span>
                  <span>${booking.depositAmount.toLocaleString()}원</span>
                </div>
                
                ${guestDifference > 0 ? `
                  <div class="flex justify-between text-sm">
                    <span class="text-blue-600">추가 보증금 (${guestDifference}명)</span>
                    <span class="text-blue-600">+${additionalDeposit.toLocaleString()}원</span>
                  </div>
                  <hr>
                  <div class="flex justify-between font-semibold">
                    <span>총 보증금</span>
                    <span class="text-blue-600">${(booking.depositAmount + additionalDeposit).toLocaleString()}원</span>
                  </div>
                  
                  <div class="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <div class="flex items-start space-x-2">
                      <i class="fas fa-credit-card text-blue-600 mt-0.5"></i>
                      <div class="text-sm">
                        <p class="text-blue-900 font-medium mb-1">추가 결제 필요</p>
                        <p class="text-blue-800">인원 증가로 인해 ${additionalDeposit.toLocaleString()}원의 추가 보증금 결제가 필요합니다.</p>
                      </div>
                    </div>
                  </div>
                ` : `
                  <div class="flex justify-between text-sm">
                    <span class="text-green-600">감소분 (${Math.abs(guestDifference)}명)</span>
                    <span class="text-green-600">-${refundAmount.toLocaleString()}원</span>
                  </div>
                  <hr>
                  <div class="flex justify-between font-semibold">
                    <span>조정 후 보증금</span>
                    <span class="text-green-600">${(booking.depositAmount - refundAmount).toLocaleString()}원</span>
                  </div>
                  
                  <div class="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div class="flex items-start space-x-2">
                      <i class="fas fa-info-circle text-green-600 mt-0.5"></i>
                      <div class="text-sm">
                        <p class="text-green-900 font-medium mb-1">부분 환불 안내</p>
                        <p class="text-green-800">인원 감소분 ${refundAmount.toLocaleString()}원은 업주 승인 후 환불 처리됩니다.</p>
                        <button 
                          class="text-green-700 underline hover:text-green-800 mt-1"
                          onclick="OReeApp.instance.navigateTo('group-policy')"
                        >
                          인원 변동 정책 자세히 보기
                        </button>
                      </div>
                    </div>
                  </div>
                `}
              </div>
            </div>
          ` : ''}
        </div>
        
        <!-- 하단 버튼 -->
        <div class="fixed bottom-20 left-0 right-0 p-4 bg-white border-t border-gray-200">
          <div class="flex space-x-3">
            <button 
              class="flex-1 py-3 px-4 bg-gray-200 text-gray-700 rounded-button hover:bg-gray-300"
              onclick="OReeApp.instance.navigateTo('my')"
            >
              취소
            </button>
            <button 
              class="flex-1 py-3 px-4 bg-blue-600 text-white rounded-button hover:bg-blue-700"
              onclick="OReeApp.instance.confirmModification()"
              ${guestDifference === 0 ? 'disabled' : ''}
            >
              ${guestDifference > 0 ? `${additionalDeposit.toLocaleString()}원 추가 결제` : guestDifference < 0 ? '변경 확정' : '변경사항 없음'}
            </button>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderCancelReservation() {
    const booking = this.modificationState.currentBooking;
    if (!booking) {
      return this.renderError('예약 정보를 찾을 수 없습니다.');
    }
    
    // 취소 정책에 따른 환불율 계산
    const bookingDate = new Date(booking.date + ' ' + booking.time);
    const hoursUntil = (bookingDate - new Date()) / (1000 * 60 * 60);
    
    let refundRate = 0;
    let policyText = '';
    
    if (hoursUntil >= 72) {
      refundRate = 100;
      policyText = '3일 전 취소 - 전액 환불';
    } else if (hoursUntil >= 24) {
      refundRate = 70;
      policyText = '1일 전 취소 - 70% 환불';
    } else if (hoursUntil >= 4) {
      refundRate = 50;
      policyText = '당일 4시간 전 취소 - 50% 환불';
    } else {
      refundRate = 0;
      policyText = '당일 4시간 이내 - 환불 불가';
    }
    
    const refundAmount = Math.floor(booking.depositAmount * (refundRate / 100));
    const cancelFee = booking.depositAmount - refundAmount;
    
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('my')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">예약 취소</h1>
            <div></div>
          </div>
        </div>
        
        <div class="p-4 space-y-6">
          <!-- 예약 정보 -->
          <div class="card p-4">
            <div class="flex items-center space-x-2 mb-3">
              <i class="fas fa-calendar-times text-red-600"></i>
              <h3 class="font-semibold text-gray-900">취소할 예약</h3>
            </div>
            
            <div class="space-y-2 text-sm bg-gray-50 rounded-lg p-3">
              <div class="flex justify-between">
                <span class="text-gray-600">업장</span>
                <span class="font-medium">${booking.storeName}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">날짜</span>
                <span class="font-medium">${this.formatBookingDate(booking.date)}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">시간</span>
                <span class="font-medium">${booking.time} ~ ${booking.endTime}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">인원</span>
                <span class="font-medium">${booking.guests}명</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">결제한 보증금</span>
                <span class="font-medium">${booking.depositAmount.toLocaleString()}원</span>
              </div>
            </div>
          </div>
          
          <!-- 환불 정책 및 금액 -->
          <div class="card p-4">
            <div class="flex items-center space-x-2 mb-3">
              <i class="fas fa-shield-alt text-blue-600"></i>
              <h3 class="font-semibold text-gray-900">취소 정책 및 환불 안내</h3>
            </div>
            
            <div class="space-y-4">
              <!-- 정책 설명 -->
              <div class="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <div class="text-sm">
                  <p class="font-medium text-blue-900 mb-2">현재 적용되는 정책</p>
                  <div class="flex items-center justify-between">
                    <span class="text-blue-800">${policyText}</span>
                    <span class="font-bold text-blue-600">${refundRate}%</span>
                  </div>
                </div>
              </div>
              
              <!-- 환불 계산 -->
              <div class="space-y-3">
                <div class="flex justify-between text-sm">
                  <span class="text-gray-600">결제한 보증금</span>
                  <span>${booking.depositAmount.toLocaleString()}원</span>
                </div>
                
                ${cancelFee > 0 ? `
                  <div class="flex justify-between text-sm">
                    <span class="text-red-600">취소 수수료</span>
                    <span class="text-red-600">-${cancelFee.toLocaleString()}원</span>
                  </div>
                ` : ''}
                
                <hr class="my-2">
                
                <div class="flex justify-between text-lg font-bold">
                  <span>환불 예정 금액</span>
                  <span class="${refundAmount > 0 ? 'text-green-600' : 'text-red-600'}">
                    ${refundAmount.toLocaleString()}원
                  </span>
                </div>
              </div>
              
              ${refundAmount === 0 ? `
                <div class="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <div class="flex items-start space-x-2">
                    <i class="fas fa-exclamation-triangle text-red-600 mt-0.5"></i>
                    <div class="text-sm">
                      <p class="text-red-900 font-medium mb-1">환불 불가 안내</p>
                      <p class="text-red-800">당일 4시간 이내 취소는 정책상 환불이 불가능합니다.</p>
                    </div>
                  </div>
                </div>
              ` : `
                <div class="p-3 bg-green-50 border border-green-200 rounded-lg">
                  <div class="flex items-start space-x-2">
                    <i class="fas fa-info-circle text-green-600 mt-0.5"></i>
                    <div class="text-sm">
                      <p class="text-green-900 font-medium mb-1">환불 처리 안내</p>
                      <p class="text-green-800">환불금은 결제 수단으로 3-5영업일 내 자동 환불됩니다.</p>
                    </div>
                  </div>
                </div>
              `}
            </div>
          </div>
          
          <!-- 전체 취소 정책 -->
          <div class="card p-4">
            <div class="flex items-center justify-between mb-3">
              <h3 class="font-semibold text-gray-900">취소 정책 전체</h3>
              <button 
                class="text-sm text-blue-600 hover:text-blue-700"
                onclick="OReeApp.instance.navigateTo('refund-policy')"
              >
                자세히 보기
              </button>
            </div>
            
            <div class="space-y-2 text-sm text-gray-600">
              <div class="flex justify-between">
                <span>3일 전까지</span>
                <span class="text-green-600 font-medium">100% 환불</span>
              </div>
              <div class="flex justify-between">
                <span>1일 전까지</span>
                <span class="text-blue-600 font-medium">70% 환불</span>
              </div>
              <div class="flex justify-between">
                <span>당일 4시간 전까지</span>
                <span class="text-orange-600 font-medium">50% 환불</span>
              </div>
              <div class="flex justify-between">
                <span>당일 4시간 이내</span>
                <span class="text-red-600 font-medium">환불 불가</span>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 하단 버튼 -->
        <div class="fixed bottom-20 left-0 right-0 p-4 bg-white border-t border-gray-200">
          <div class="flex space-x-3">
            <button 
              class="flex-1 py-3 px-4 bg-gray-200 text-gray-700 rounded-button hover:bg-gray-300"
              onclick="OReeApp.instance.navigateTo('my')"
            >
              유지하기
            </button>
            <button 
              class="flex-1 py-3 px-4 bg-red-600 text-white rounded-button hover:bg-red-700"
              onclick="OReeApp.instance.confirmCancellation()"
            >
              ${refundAmount.toLocaleString()}원 환불받고 취소
            </button>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderDepositPayment() {
    const additionalDeposit = this.modificationState.additionalDeposit;
    const booking = this.modificationState.currentBooking;
    
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('modify-reservation')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">추가 보증금 결제</h1>
            <div></div>
          </div>
        </div>
        
        <div class="p-4 space-y-6">
          <!-- 결제 정보 -->
          <div class="card p-4">
            <div class="flex items-center space-x-2 mb-3">
              <i class="fas fa-plus-circle text-blue-600"></i>
              <h3 class="font-semibold text-gray-900">추가 결제 정보</h3>
            </div>
            
            <div class="space-y-3">
              <div class="flex justify-between text-sm">
                <span class="text-gray-600">인원 증가</span>
                <span class="font-medium">${this.modificationState.originalGuests}명 → ${this.modificationState.newGuests}명 (+${this.modificationState.newGuests - this.modificationState.originalGuests}명)</span>
              </div>
              
              <div class="flex justify-between text-sm">
                <span class="text-gray-600">기존 보증금</span>
                <span>${booking.depositAmount.toLocaleString()}원</span>
              </div>
              
              <div class="flex justify-between text-sm">
                <span class="text-blue-600">추가 보증금</span>
                <span class="text-blue-600 font-medium">+${additionalDeposit.toLocaleString()}원</span>
              </div>
              
              <hr>
              
              <div class="flex justify-between text-lg font-bold">
                <span>총 결제 금액</span>
                <span class="text-blue-600">${additionalDeposit.toLocaleString()}원</span>
              </div>
            </div>
          </div>
          
          <!-- 결제 수단 선택 -->
          <div class="card p-4">
            <h3 class="font-semibold text-gray-900 mb-4">결제 수단</h3>
            
            <div class="space-y-2">
              <label class="flex items-center space-x-3 p-3 border border-gray-200 rounded-button hover:bg-gray-50 cursor-pointer">
                <input type="radio" name="payment-method" value="card" checked class="text-blue-600">
                <div class="flex items-center space-x-2">
                  <i class="fas fa-credit-card text-blue-600"></i>
                  <span>카드 결제</span>
                </div>
              </label>
              
              <label class="flex items-center space-x-3 p-3 border border-gray-200 rounded-button hover:bg-gray-50 cursor-pointer">
                <input type="radio" name="payment-method" value="paybook" class="text-blue-600">
                <div class="flex items-center space-x-2">
                  <i class="fas fa-book text-green-600"></i>
                  <span>페이북</span>
                </div>
              </label>
              
              <label class="flex items-center space-x-3 p-3 border border-gray-200 rounded-button hover:bg-gray-50 cursor-pointer">
                <input type="radio" name="payment-method" value="kakaopay" class="text-blue-600">
                <div class="flex items-center space-x-2">
                  <i class="fas fa-comment text-yellow-600"></i>
                  <span>카카오페이</span>
                </div>
              </label>
            </div>
          </div>
          
          <!-- 안내사항 -->
          <div class="card p-4 bg-blue-50 border border-blue-200">
            <div class="flex items-start space-x-2">
              <i class="fas fa-info-circle text-blue-600 mt-0.5"></i>
              <div class="text-sm">
                <p class="text-blue-900 font-medium mb-1">결제 안내</p>
                <p class="text-blue-800">추가 보증금 결제 완료 후 예약 변경이 최종 확정됩니다.</p>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 하단 버튼 -->
        <div class="fixed bottom-20 left-0 right-0 p-4 bg-white border-t border-gray-200">
          <button 
            class="w-full py-3 px-4 bg-blue-600 text-white rounded-button hover:bg-blue-700"
            onclick="OReeApp.instance.processAdditionalPayment()"
          >
            ${additionalDeposit.toLocaleString()}원 결제하기
          </button>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  // 홈 화면 관련 메서드들
  toggleNotifications() {
    this.homeState.showNotifications = !this.homeState.showNotifications;
    this.render();
  }
  
  switchViewMode(viewMode) {
    this.homeState.viewMode = viewMode;
    this.render();
  }
  
  handleFilterClick(filter) {
    if (filter === 'reservation-available') {
      this.homeState.filters.reservationAvailable = !this.homeState.filters.reservationAvailable;
    } else if (filter === 'sort') {
      // 정렬 옵션 순환: distance -> rating -> price -> distance
      const sortOptions = ['distance', 'rating', 'price'];
      const currentIndex = sortOptions.indexOf(this.homeState.filters.sortBy);
      const nextIndex = (currentIndex + 1) % sortOptions.length;
      this.homeState.filters.sortBy = sortOptions[nextIndex];
    }
    this.render();
  }
  
  handleSearch(query) {
    // 실제 구현에서는 디바운싱 적용
    console.log('검색:', query);
  }
  
  selectStorePin(storeId) {
    this.homeState.selectedPin = storeId;
    this.render();
  }
  
  filterNotifications(filter) {
    // 알림 필터링 로직
    const filterButtons = document.querySelectorAll('.notification-filter');
    filterButtons.forEach(btn => {
      btn.classList.remove('bg-blue-600', 'text-white');
      btn.classList.add('bg-gray-100', 'text-gray-700');
    });
    
    // 클릭된 버튼 활성화
    const clickedBtn = document.querySelector(`[data-filter="${filter}"]`);
    if (clickedBtn) {
      clickedBtn.classList.remove('bg-gray-100', 'text-gray-700');
      clickedBtn.classList.add('bg-blue-600', 'text-white');
    }
    
    console.log('알림 필터:', filter);
  }
  
  markAllNotificationsAsRead() {
    this.homeState.notifications.forEach(notification => {
      notification.isRead = true;
    });
    this.render();
  }
  
  markNotificationAsRead(notificationId) {
    const notification = this.homeState.notifications.find(n => n.id === notificationId);
    if (notification) {
      notification.isRead = true;
      this.render();
    }
  }
  
  // 찜 기능 관련 메서드들 (STEP 6)
  loadUserWishlist() {
    try {
      const savedWishlist = localStorage.getItem('oree_user_wishlist');
      if (savedWishlist) {
        this.homeState.userWishlist = JSON.parse(savedWishlist);
      } else {
        // 데모용 기본 찜 목록 (각 카테고리별로 하나씩)
        this.homeState.userWishlist = [1, 3, 4]; // 강남 카페(식당), 이태원 파티룸(레저), 게스트하우스(숙박)
        this.saveUserWishlist();
      }
    } catch (error) {
      console.error('찜 목록 로드 실패:', error);
      this.homeState.userWishlist = [];
    }
  }
  
  saveUserWishlist() {
    try {
      localStorage.setItem('oree_user_wishlist', JSON.stringify(this.homeState.userWishlist));
    } catch (error) {
      console.error('찜 목록 저장 실패:', error);
    }
  }
  
  isStoreInWishlist(storeId) {
    return this.homeState.userWishlist.includes(storeId);
  }
  
  toggleWishlist(storeId) {
    // 로그인 상태 확인
    if (!this.authState.isLoggedIn) {
      alert('로그인이 필요한 기능입니다.');
      this.navigateTo('login');
      return;
    }
    
    const isCurrentlyWishlisted = this.isStoreInWishlist(storeId);
    
    if (isCurrentlyWishlisted) {
      // 찜 해제
      this.homeState.userWishlist = this.homeState.userWishlist.filter(id => id !== storeId);
      this.showToast('찜 목록에서 제거되었습니다.');
    } else {
      // 찜 추가
      this.homeState.userWishlist.push(storeId);
      this.showToast('찜 목록에 추가되었습니다.');
    }
    
    this.saveUserWishlist();
    this.render();
  }
  
  shareStore(storeId) {
    const store = this.homeState.stores.find(s => s.id === storeId);
    if (!store) return;
    
    if (navigator.share) {
      navigator.share({
        title: store.name,
        text: `${store.name} - ${store.category} (${store.capacity})`,
        url: window.location.href
      }).catch(console.error);
    } else {
      // 웹 공유 API가 지원되지 않는 경우
      const shareUrl = window.location.href;
      navigator.clipboard.writeText(shareUrl).then(() => {
        this.showToast('링크가 복사되었습니다.');
      }).catch(() => {
        alert(`공유 링크: ${shareUrl}`);
      });
    }
  }
  
  startReservation() {
    // 로그인 상태 확인
    if (!this.authState.isLoggedIn) {
      alert('로그인이 필요한 기능입니다.');
      this.navigateTo('login');
      return;
    }
    
    this.navigateTo('reservation');
  }
  
  showToast(message) {
    // 간단한 토스트 메시지 표시
    const toast = document.createElement('div');
    toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white px-4 py-2 rounded-button text-sm z-50';
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s ease-out';
      setTimeout(() => {
        document.body.removeChild(toast);
      }, 300);
    }, 2000);
  }
  
  // 예약 관련 헬퍼 메서드들 (STEP 7)
  generateAvailableDates() {
    const dates = [];
    const today = new Date();
    
    for (let i = 0; i < 30; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      
      const dateString = date.toISOString().split('T')[0];
      const dayOfWeek = date.getDay();
      
      dates.push({
        date: dateString,
        day: date.getDate(),
        available: i > 0 && dayOfWeek !== 0 // 오늘은 불가, 일요일 불가
      });
    }
    
    return dates;
  }
  
  calculateEndTime() {
    if (!this.reservationState.selectedTime) return '';
    
    const [hour] = this.reservationState.selectedTime.split(':').map(Number);
    const endHour = hour + this.reservationState.minimumHours;
    return `${endHour.toString().padStart(2, '0')}:00`;
  }
  
  calculateTotalAmount() {
    const baseAmount = this.reservationState.pricePerHour * this.reservationState.minimumHours;
    const extraGuestFee = this.calculateExtraGuestFee();
    return baseAmount + extraGuestFee;
  }
  
  calculateExtraGuestFee() {
    // 10명 초과시 1명당 5,000원 추가
    const extraGuests = Math.max(0, this.reservationState.selectedGuests - 10);
    return extraGuests * 5000;
  }
  
  calculateDepositAmount() {
    return Math.floor(this.calculateTotalAmount() * 0.5);
  }
  
  validateReservationForm() {
    return (
      this.reservationState.selectedDate &&
      this.reservationState.selectedTime &&
      this.reservationState.selectedGuests >= 4 &&
      this.reservationState.agreeRefundPolicy &&
      this.authState.isPhoneVerified
    );
  }
  
  // 예약 화면 이벤트 핸들러들
  cancelReservation() {
    if (confirm('예약을 취소하시겠습니까?')) {
      this.navigateTo('store-detail');
    }
  }
  
  proceedToPayment() {
    if (!this.validateReservationForm()) {
      if (!this.reservationState.selectedDate) {
        this.showToast('날짜를 선택해주세요.');
      } else if (!this.reservationState.selectedTime) {
        this.showToast('시간을 선택해주세요.');
      } else if (this.reservationState.selectedGuests < 4) {
        this.showToast('4인 이하 예약은 불가합니다.');
      } else if (!this.reservationState.agreeRefundPolicy) {
        this.showToast('환불정책에 동의해주세요.');
      }
      return;
    }
    
    this.navigateTo('payment');
  }

  renderPhoneAuth() {
    return `
      <div class="min-h-screen bg-white flex flex-col">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('login')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">전화번호 인증</h1>
            <div></div>
          </div>
        </div>
        
        <div class="flex-1 px-6 py-8">
          <div class="max-w-sm mx-auto">
            <!-- 안내 문구 -->
            <div class="text-center mb-8">
              <div class="w-16 h-16 mx-auto bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <i class="fas fa-mobile-alt text-2xl text-blue-600"></i>
              </div>
              <h2 class="text-xl font-bold text-gray-900 mb-2">전화번호를 인증해주세요</h2>
              <p class="text-gray-600 text-sm">안전한 서비스 이용을 위해<br>본인 확인이 필요합니다</p>
            </div>
            
            <!-- 전화번호 입력 -->
            <div class="space-y-6">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">전화번호</label>
                <div class="flex space-x-2">
                  <input 
                    type="tel" 
                    id="phone-number"
                    class="input-field flex-1" 
                    placeholder="010-0000-0000"
                    maxlength="13"
                    oninput="OReeApp.instance.formatPhoneNumber(this)"
                  >
                  <button 
                    id="send-code-btn"
                    class="btn btn-primary px-4 whitespace-nowrap" 
                    onclick="OReeApp.instance.sendVerificationCode()"
                  >
                    인증번호 전송
                  </button>
                </div>
              </div>
              
              <!-- 인증번호 입력 (처음에는 숨김) -->
              <div id="verification-section" class="hidden">
                <label class="block text-sm font-medium text-gray-700 mb-2">인증번호</label>
                <div class="flex space-x-2">
                  <input 
                    type="text" 
                    id="verification-code"
                    class="input-field flex-1" 
                    placeholder="6자리 인증번호"
                    maxlength="6"
                  >
                  <button 
                    id="verify-code-btn"
                    class="btn btn-primary px-4 whitespace-nowrap" 
                    onclick="OReeApp.instance.verifyCode()"
                  >
                    인증
                  </button>
                </div>
                
                <!-- 타이머 -->
                <div class="flex justify-between items-center mt-2 text-sm">
                  <span id="timer-text" class="text-gray-500">03:00</span>
                  <button id="resend-btn" class="text-blue-600 hover:underline hidden" onclick="OReeApp.instance.resendCode()">
                    재전송
                  </button>
                </div>
              </div>
              
              <!-- 인증 상태 표시 -->
              <div id="auth-status" class="hidden">
                <div id="auth-success" class="hidden p-3 bg-green-50 border border-green-200 rounded-button">
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-check-circle text-green-600"></i>
                    <span class="text-green-800 font-medium">인증 완료</span>
                  </div>
                </div>
                
                <div id="auth-error" class="hidden p-3 bg-red-50 border border-red-200 rounded-button">
                  <div class="flex items-center space-x-2">
                    <i class="fas fa-exclamation-circle text-red-600"></i>
                    <span id="error-message" class="text-red-800 font-medium">인증번호가 올바르지 않습니다</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 완료 버튼 -->
        <div class="p-6">
          <button 
            id="complete-auth-btn"
            class="btn btn-primary w-full py-4 disabled:opacity-50 disabled:cursor-not-allowed" 
            onclick="OReeApp.instance.completePhoneAuth()"
            disabled
          >
            인증 완료
          </button>
        </div>
      </div>
    `;
  }

  renderSocialConsent() {
    return `
      <div class="min-h-screen bg-white flex flex-col">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('login')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">${this.currentSocialType === 'kakao' ? '카카오' : '네이버'} 로그인</h1>
            <div></div>
          </div>
        </div>
        
        <div class="flex-1 px-6 py-8">
          <div class="max-w-sm mx-auto">
            <!-- 소셜 로그인 안내 -->
            <div class="text-center mb-8">
              <div class="w-16 h-16 mx-auto ${this.currentSocialType === 'kakao' ? 'bg-yellow-400' : 'bg-green-500'} rounded-full flex items-center justify-center mb-4">
                ${this.currentSocialType === 'kakao' 
                  ? '<i class="fas fa-comment text-xl text-gray-900"></i>'
                  : '<span class="text-xl font-bold text-white">N</span>'
                }
              </div>
              <h2 class="text-xl font-bold text-gray-900 mb-2">${this.currentSocialType === 'kakao' ? '카카오' : '네이버'} 계정으로 로그인</h2>
              <p class="text-gray-600 text-sm">서비스 이용을 위해<br>다음 정보 제공에 동의해주세요</p>
            </div>
            
            <!-- 동의 항목 -->
            <div class="space-y-4 mb-8">
              <div class="space-y-3">
                <h3 class="text-sm font-semibold text-gray-900">필수 동의 항목</h3>
                
                <label class="flex items-start space-x-3 cursor-pointer">
                  <input type="checkbox" id="required-service" class="mt-1 text-blue-600 rounded" checked disabled>
                  <div>
                    <span class="text-sm text-gray-900">서비스 이용약관 동의</span>
                    <span class="text-red-500 ml-1">(필수)</span>
                    <p class="text-xs text-gray-500 mt-1">ORee 서비스 기본 이용에 필요합니다</p>
                  </div>
                </label>
                
                <label class="flex items-start space-x-3 cursor-pointer">
                  <input type="checkbox" id="required-privacy" class="mt-1 text-blue-600 rounded" checked disabled>
                  <div>
                    <span class="text-sm text-gray-900">개인정보 처리방침 동의</span>
                    <span class="text-red-500 ml-1">(필수)</span>
                    <p class="text-xs text-gray-500 mt-1">프로필 정보, 예약 정보 처리에 필요합니다</p>
                  </div>
                </label>
                
                <label class="flex items-start space-x-3 cursor-pointer">
                  <input type="checkbox" id="required-phone" class="mt-1 text-blue-600 rounded" checked>
                  <div>
                    <span class="text-sm text-gray-900">전화번호 제공 동의</span>
                    <span class="text-red-500 ml-1">(필수)</span>
                    <p class="text-xs text-gray-500 mt-1">예약 확인 및 본인 인증에 필요합니다</p>
                  </div>
                </label>
              </div>
              
              <div class="space-y-3 pt-4 border-t border-gray-200">
                <h3 class="text-sm font-semibold text-gray-900">선택 동의 항목</h3>
                
                <label class="flex items-start space-x-3 cursor-pointer">
                  <input type="checkbox" id="optional-marketing" class="mt-1 text-blue-600 rounded">
                  <div>
                    <span class="text-sm text-gray-900">마케팅 정보 수신 동의</span>
                    <span class="text-gray-500 ml-1">(선택)</span>
                    <p class="text-xs text-gray-500 mt-1">할인 혜택, 이벤트 정보를 받아보실 수 있습니다</p>
                  </div>
                </label>
                
                <label class="flex items-start space-x-3 cursor-pointer">
                  <input type="checkbox" id="optional-push" class="mt-1 text-blue-600 rounded">
                  <div>
                    <span class="text-sm text-gray-900">푸시 알림 수신 동의</span>
                    <span class="text-gray-500 ml-1">(선택)</span>
                    <p class="text-xs text-gray-500 mt-1">예약 알림, 리뷰 요청 등을 받아보실 수 있습니다</p>
                  </div>
                </label>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 동의 및 로그인 버튼 -->
        <div class="p-6">
          <button 
            class="btn btn-primary w-full py-4" 
            onclick="OReeApp.instance.processSocialLogin()"
          >
            동의하고 ${this.currentSocialType === 'kakao' ? '카카오' : '네이버'}로 시작하기
          </button>
        </div>
      </div>
    `;
  }

  renderVerificationRequired() {
    return `
      <div class="modal-overlay">
        <div class="modal-content fade-in p-6 max-w-sm">
          <div class="text-center">
            <div class="w-16 h-16 mx-auto bg-red-100 rounded-full flex items-center justify-center mb-4">
              <i class="fas fa-shield-alt text-2xl text-red-600"></i>
            </div>
            
            <h2 class="text-xl font-bold text-gray-900 mb-2">인증이 필요합니다</h2>
            <p class="text-gray-600 text-sm mb-6">
              ${this.authState.isGuest 
                ? '회원가입과 전화번호 인증 후 이용 가능한 서비스입니다.'
                : '전화번호 인증자에 한해 서비스 이용이 가능합니다.'
              }
            </p>
            
            <div class="space-y-3">
              ${this.authState.isGuest 
                ? `
                <button class="btn btn-primary w-full" onclick="OReeApp.instance.goToLogin()">
                  로그인 / 회원가입
                </button>
                ` 
                : `
                <button class="btn btn-primary w-full" onclick="OReeApp.instance.goToPhoneAuth()">
                  전화번호 인증하기
                </button>
                `
              }
              
              <button class="btn btn-secondary w-full" onclick="OReeApp.instance.closeVerificationModal()">
                돌아가기
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // === 액션 함수들 ===

  // === 온보딩 관련 함수들 ===

  nextSlide() {
    if (this.onboardingState.currentSlide < this.onboardingState.totalSlides - 1) {
      this.onboardingState.currentSlide++;
      this.render();
    }
  }

  prevSlide() {
    if (this.onboardingState.currentSlide > 0) {
      this.onboardingState.currentSlide--;
      this.render();
    }
  }

  skipOnboarding() {
    localStorage.setItem('onboarding_completed', 'true');
    this.showOnboarding = false;
    
    // 이미 로그인된 사용자라면 홈으로, 아니면 로그인으로
    if (this.authState.isLoggedIn) {
      this.navigateTo('location-permission');
    } else {
      this.navigateTo('login');
    }
  }

  completeOnboarding() {
    localStorage.setItem('onboarding_completed', 'true');
    this.showOnboarding = false;
    
    // 온보딩에서 "시작하기"를 눌렀을 때는 로그인 화면으로 이동
    // 이미 로그인된 사용자는 위치권한 화면으로
    if (this.authState.isLoggedIn) {
      this.navigateTo('location-permission');
    } else {
      this.navigateTo('login');
    }
  }

  // === 로그인 관련 함수들 ===

  handleSocialLogin(provider) {
    this.currentSocialType = provider;
    this.navigateTo('social-consent');
  }

  processSocialLogin() {
    // 필수 항목 체크
    const requiredPhone = document.getElementById('required-phone');
    if (!requiredPhone.checked) {
      alert('전화번호 제공 동의는 필수입니다.');
      return;
    }

    // 소셜 로그인 처리 (OAuth Stub)
    const button = event.target;
    button.innerHTML = '<div class="spinner mr-2"></div>로그인 중...';
    button.disabled = true;

    setTimeout(() => {
      // 소셜 로그인 성공 시뮬레이션
      this.authState.isLoggedIn = true;
      this.authState.loginType = 'social';
      this.authState.socialProvider = this.currentSocialType;
      this.authState.isPhoneVerified = false; // 전화번호는 아직 미인증

      // 소셜에서 가져온 가상 정보
      this.user = {
        name: this.currentSocialType === 'kakao' ? '카카오사용자' : '네이버사용자',
        email: `user@${this.currentSocialType}.com`,
        socialId: `${this.currentSocialType}_123456`,
        phoneNumber: null // 소셜에서는 전화번호를 바로 가져올 수 없음
      };

      // 로컬 스토리지에 상태 저장
      localStorage.setItem('authState', JSON.stringify(this.authState));
      localStorage.setItem('user', JSON.stringify(this.user));

      alert(`${this.currentSocialType === 'kakao' ? '카카오' : '네이버'} 로그인이 완료되었습니다!\n전화번호 인증을 진행해주세요.`);
      
      // 전화번호 인증이 필요하므로 전화번호 인증 화면으로
      this.navigateTo('phone-auth');
    }, 2000);
  }

  handleGuestLogin() {
    // 게스트 로그인
    this.authState.isLoggedIn = true;
    this.authState.loginType = 'guest';
    this.authState.isGuest = true;
    this.authState.isPhoneVerified = false;

    this.user = {
      name: '게스트',
      email: null,
      phoneNumber: null
    };

    localStorage.setItem('authState', JSON.stringify(this.authState));
    localStorage.setItem('user', JSON.stringify(this.user));

    alert('게스트로 입장합니다.\n일부 기능은 제한될 수 있습니다.');
    this.navigateTo('location-permission');
  }

  showPhoneAuth() {
    this.navigateTo('phone-auth');
  }

  // === 전화번호 인증 관련 함수들 ===

  formatPhoneNumber(input) {
    let value = input.value.replace(/\D/g, '');
    if (value.length >= 3 && value.length <= 7) {
      value = value.replace(/(\d{3})(\d+)/, '$1-$2');
    } else if (value.length > 7) {
      value = value.replace(/(\d{3})(\d{4})(\d+)/, '$1-$2-$3');
    }
    input.value = value;
    this.phoneAuthState.phoneNumber = value;
  }

  sendVerificationCode() {
    const phoneInput = document.getElementById('phone-number');
    const sendBtn = document.getElementById('send-code-btn');
    const verificationSection = document.getElementById('verification-section');

    if (!phoneInput.value || phoneInput.value.length < 13) {
      alert('올바른 전화번호를 입력해주세요.');
      return;
    }

    // 버튼 상태 변경
    sendBtn.innerHTML = '<div class="spinner mr-2"></div>전송중...';
    sendBtn.disabled = true;

    setTimeout(() => {
      // 인증번호 전송 성공 시뮬레이션
      this.phoneAuthState.codeSent = true;
      this.phoneAuthState.phoneNumber = phoneInput.value;

      // UI 업데이트
      sendBtn.innerHTML = '재전송';
      sendBtn.disabled = false;
      verificationSection.classList.remove('hidden');

      // 타이머 시작 (3분)
      this.startVerificationTimer();

      alert('인증번호가 전송되었습니다.\n(테스트용: 123456)');
    }, 1500);
  }

  startVerificationTimer() {
    this.phoneAuthState.timer = 180; // 3분
    const timerText = document.getElementById('timer-text');
    const resendBtn = document.getElementById('resend-btn');

    this.phoneAuthState.timerInterval = setInterval(() => {
      const minutes = Math.floor(this.phoneAuthState.timer / 60);
      const seconds = this.phoneAuthState.timer % 60;
      timerText.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

      if (this.phoneAuthState.timer === 0) {
        clearInterval(this.phoneAuthState.timerInterval);
        timerText.textContent = '시간 만료';
        timerText.classList.add('text-red-500');
        resendBtn.classList.remove('hidden');
      }

      this.phoneAuthState.timer--;
    }, 1000);
  }

  resendCode() {
    // 타이머 리셋하고 재전송
    clearInterval(this.phoneAuthState.timerInterval);
    const timerText = document.getElementById('timer-text');
    const resendBtn = document.getElementById('resend-btn');
    
    timerText.classList.remove('text-red-500');
    resendBtn.classList.add('hidden');
    
    this.sendVerificationCode();
  }

  verifyCode() {
    const codeInput = document.getElementById('verification-code');
    const verifyBtn = document.getElementById('verify-code-btn');
    const authStatus = document.getElementById('auth-status');
    const authSuccess = document.getElementById('auth-success');
    const authError = document.getElementById('auth-error');
    const completeBtn = document.getElementById('complete-auth-btn');

    if (!codeInput.value || codeInput.value.length !== 6) {
      alert('6자리 인증번호를 입력해주세요.');
      return;
    }

    verifyBtn.innerHTML = '<div class="spinner mr-2"></div>확인중...';
    verifyBtn.disabled = true;

    setTimeout(() => {
      // 인증번호 확인 (테스트용: 123456)
      if (codeInput.value === '123456') {
        // 인증 성공
        this.authState.isPhoneVerified = true;
        this.phoneAuthState.isVerifying = false;

        // 타이머 정지
        clearInterval(this.phoneAuthState.timerInterval);

        // UI 업데이트
        authStatus.classList.remove('hidden');
        authSuccess.classList.remove('hidden');
        authError.classList.add('hidden');
        completeBtn.disabled = false;

        verifyBtn.innerHTML = '인증 완료';
        verifyBtn.disabled = true;
        verifyBtn.classList.remove('btn-primary');
        verifyBtn.classList.add('btn-success');

      } else {
        // 인증 실패
        authStatus.classList.remove('hidden');
        authError.classList.remove('hidden');
        authSuccess.classList.add('hidden');

        verifyBtn.innerHTML = '인증';
        verifyBtn.disabled = false;
      }
    }, 1500);
  }

  completePhoneAuth() {
    // 전화번호 인증 완료
    this.user.phoneNumber = this.phoneAuthState.phoneNumber;
    
    // 상태 저장
    localStorage.setItem('authState', JSON.stringify(this.authState));
    localStorage.setItem('user', JSON.stringify(this.user));

    alert('전화번호 인증이 완료되었습니다!');
    
    // 인증 완료 후 위치 권한으로 이동
    this.navigateTo('location-permission');
  }

  handleLogin() {
    // 기존 이메일/비밀번호 로그인 (삭제 예정)
    this.user = { name: '김사용자', email: 'user@example.com' };
    this.navigateTo('location-permission');
  }

  toggleSignup() {
    alert('소셜 로그인 또는 전화번호 인증을 이용해주세요.');
  }

  // === 인증 확인 및 차단 로직 ===

  checkPhoneVerification() {
    return this.authState.isPhoneVerified;
  }

  requirePhoneVerification(action) {
    if (!this.checkPhoneVerification()) {
      this.previousScreen = this.currentScreen; // 돌아갈 화면 저장
      this.navigateTo('verification-required');
      return false;
    }
    return true;
  }

  goToLogin() {
    this.navigateTo('login');
  }

  goToPhoneAuth() {
    this.navigateTo('phone-auth');
  }

  closeVerificationModal() {
    if (this.previousScreen) {
      this.navigateTo(this.previousScreen);
    } else {
      this.navigateTo('home');
    }
  }

  // === 예약 관련 인증 체크 함수들 ===

  startReservation() {
    if (!this.requirePhoneVerification()) {
      return;
    }
    this.navigateTo('reservation');
  }

  goToPayment() {
    if (!this.requirePhoneVerification()) {
      return;
    }
    this.navigateTo('payment');
  }

  // === 개발용 함수들 ===

  getCurrentLocationText() {
    if (this.locationState.permissionGranted && this.locationState.address) {
      return this.locationState.address;
    } else if (this.locationState.permissionAsked && !this.locationState.permissionGranted) {
      return this.locationState.defaultLocation.address + ' (기본위치)';
    } else {
      return this.locationState.defaultLocation.address;
    }
  }

  manageLocationSettings() {
    const currentStatus = this.locationState.permissionGranted ? '허용됨' : '거부됨';
    const currentLocation = this.getCurrentLocationText();
    
    const message = `현재 위치 설정: ${currentStatus}\n현재 위치: ${currentLocation}\n\n위치 권한을 다시 설정하시겠습니까?`;
    
    if (confirm(message)) {
      // 위치 상태 초기화 후 위치 권한 화면으로 이동
      this.locationState.permissionAsked = false;
      this.locationState.permissionGranted = false;
      this.locationState.coordinates = null;
      this.locationState.address = null;
      this.saveLocationState();
      
      this.navigateTo('location-permission');
    }
  }

  resetOnboarding() {
    localStorage.removeItem('onboarding_completed');
    this.showOnboarding = true;
    this.onboardingState.currentSlide = 0;
    alert('온보딩이 초기화되었습니다. 새로고침하면 다시 볼 수 있습니다.');
  }

  // === 위치 권한 관련 함수들 ===

  allowLocationAndSave() {
    const button = event.target;
    const originalText = button.innerHTML;
    
    // 버튼 상태 변경
    button.innerHTML = '<div class="spinner mr-2"></div>위치 확인 중...';
    button.disabled = true;
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // 위치 정보 성공적으로 가져옴
          const coords = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            accuracy: position.coords.accuracy
          };
          
          this.locationState.permissionGranted = true;
          this.locationState.permissionAsked = true;
          this.locationState.coordinates = coords;
          
          // 역 지오코딩으로 주소 가져오기 (시뮬레이션)
          this.getAddressFromCoords(coords).then(address => {
            this.locationState.address = address;
            this.saveLocationState();
            
            // 성공 메시지
            button.innerHTML = '<i class="fas fa-check mr-2"></i>위치 저장 완료!';
            button.classList.remove('btn-primary');
            button.classList.add('btn-success');
            
            setTimeout(() => {
              this.navigateTo('home');
            }, 1500);
          });
        },
        (error) => {
          // 위치 접근 실패 (사용자 거부, 시간 초과 등)
          console.log('위치 접근 실패:', error);
          
          this.locationState.permissionGranted = false;
          this.locationState.permissionAsked = true;
          this.saveLocationState();
          
          // 실패 메시지
          button.innerHTML = '<i class="fas fa-exclamation-circle mr-2"></i>위치 접근 실패';
          button.classList.remove('btn-primary');
          button.classList.add('btn-danger');
          
          setTimeout(() => {
            alert('위치 접근이 거부되었습니다.\\n기본 위치(서울)로 설정됩니다.');
            this.navigateTo('home');
          }, 1500);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      );
    } else {
      // 브라우저에서 위치 서비스 미지원
      this.locationState.permissionGranted = false;
      this.locationState.permissionAsked = true;
      this.saveLocationState();
      
      button.innerHTML = '위치 서비스 미지원';
      button.classList.remove('btn-primary');
      button.classList.add('btn-secondary');
      
      setTimeout(() => {
        alert('브라우저에서 위치 서비스를 지원하지 않습니다.\\n기본 위치로 설정됩니다.');
        this.navigateTo('home');
      }, 1500);
    }
  }

  skipLocationLater() {
    // 나중에 하기 선택
    this.locationState.permissionGranted = false;
    this.locationState.permissionAsked = false; // 다음에 다시 물어볼 수 있도록
    this.saveLocationState();
    
    this.navigateTo('home');
  }

  async getAddressFromCoords(coords) {
    try {
      // 실제 환경에서는 카카오맵 API나 구글맵 API 사용
      // 여기서는 시뮬레이션 (네트워크 오류 가능성 포함)
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          // 10% 확률로 네트워크 오류 시뮬레이션
          if (Math.random() < 0.1) {
            reject(new Error('Network timeout'));
            return;
          }
          
          // 서울 지역 구분 시뮬레이션
          const districts = [
            '강남구', '서초구', '송파구', '강동구', 
            '마포구', '용산구', '성동구', '광진구',
            '종로구', '중구', '영등포구', '구로구'
          ];
          
          const randomDistrict = districts[Math.floor(Math.random() * districts.length)];
          const address = `서울특별시 ${randomDistrict}`;
          
          resolve(address);
        }, 1000);
      });
    } catch (error) {
      this.handleNetworkError(error, '주소 변환');
      throw error;
    }
  }

  saveLocationState() {
    localStorage.setItem('locationState', JSON.stringify(this.locationState));
  }

  loadLocationState() {
    const savedState = localStorage.getItem('locationState');
    if (savedState) {
      this.locationState = { ...this.locationState, ...JSON.parse(savedState) };
    }
  }

  // 기존 함수들 (호환성 유지)
  requestLocation() {
    this.allowLocationAndSave();
  }

  skipLocation() {
    this.skipLocationLater();
  }

  processPayment() {
    // 전화번호 인증 확인
    if (!this.requirePhoneVerification()) {
      return;
    }

    // 결제 처리 시뮬레이션
    const button = event.target;
    button.innerHTML = '<div class="spinner mr-2"></div>결제 처리중...';
    button.disabled = true;
    
    setTimeout(() => {
      alert('결제가 완료되었습니다!');
      this.navigateTo('qr');
    }, 2000);
  }
}

// 앱 초기화
document.addEventListener('DOMContentLoaded', () => {
  OReeApp.instance = new OReeApp();
});

// CSS 스타일 동적 추가
const style = document.createElement('style');
style.textContent = `
  .btn-toggle.active {
    background-color: #2563eb;
    color: white;
  }
  .btn-sm {
    padding: 0.375rem 0.75rem;
    font-size: 0.875rem;
  }
  
  /* 온보딩 슬라이드 애니메이션 */
  .slide-fade-in {
    animation: slideFadeIn 0.4s ease-out;
  }
  
  @keyframes slideFadeIn {
    from {
      opacity: 0;
      transform: translateX(20px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }
  
  /* 온보딩 아이콘 애니메이션 */
  .icon-bounce {
    animation: iconBounce 0.6s ease-out 0.2s both;
  }
  
  @keyframes iconBounce {
    0% {
      opacity: 0;
      transform: scale(0.3);
    }
    50% {
      transform: scale(1.1);
    }
    100% {
      opacity: 1;
      transform: scale(1);
    }
  }
  
  /* 인디케이터 애니메이션 */
  .indicator-active {
    transform: scale(1.2);
  }
`;
document.head.appendChild(style);

// ORee MVP 애플리케이션 초기화
document.addEventListener('DOMContentLoaded', () => {
  try {
    console.log('OReeApp 초기화 시작...');
    
    // 전역 OReeApp 인스턴스 생성
    window.OReeApp = {
      instance: new OReeApp()
    };
    
    console.log('OReeApp 인스턴스 생성 완료');
    
    // 앱 시작
    OReeApp.instance.init();
    
    console.log('OReeApp 초기화 완료');
  } catch (error) {
    console.error('OReeApp 초기화 실패:', error);
    document.getElementById('app').innerHTML = `
      <div class="p-4 text-center">
        <h2 class="text-xl font-bold text-red-600 mb-2">앱 로딩 실패</h2>
        <p class="text-gray-600">${error.message}</p>
        <button onclick="window.location.reload()" class="mt-4 px-4 py-2 bg-blue-600 text-white rounded">
          다시 시도
        </button>
      </div>
    `;
  }
});