// ORee MVP - 메인 애플리케이션
class OReeApp {
  constructor() {
    this.currentScreen = 'login'; // 최초 진입점: 로그인/가입
    this.user = null;
    this.showOnboarding = !localStorage.getItem('onboarding_completed');
    
    this.init();
  }

  init() {
    // 온보딩 체크
    if (this.showOnboarding) {
      this.currentScreen = 'onboarding';
    }
    
    this.render();
    this.bindEvents();
  }

  // 화면 전환
  navigateTo(screen) {
    this.currentScreen = screen;
    this.render();
  }

  // 메인 렌더링
  render() {
    const app = document.getElementById('app');
    
    switch (this.currentScreen) {
      case 'onboarding':
        app.innerHTML = this.renderOnboarding();
        break;
      case 'login':
        app.innerHTML = this.renderLogin();
        break;
      case 'location-permission':
        app.innerHTML = this.renderLocationPermission();
        break;
      case 'home':
        app.innerHTML = this.renderHome();
        break;
      case 'store-detail':
        app.innerHTML = this.renderStoreDetail();
        break;
      case 'reservation':
        app.innerHTML = this.renderReservation();
        break;
      case 'payment':
        app.innerHTML = this.renderPayment();
        break;
      case 'qr':
        app.innerHTML = this.renderQR();
        break;
      case 'wishlist':
        app.innerHTML = this.renderWishlist();
        break;
      case 'my':
        app.innerHTML = this.renderMy();
        break;
      case 'dev-notes':
        app.innerHTML = this.renderDevNotes();
        break;
      default:
        app.innerHTML = this.renderLogin();
    }
    
    this.bindScreenEvents();
  }

  // 이벤트 바인딩
  bindEvents() {
    // 전역 이벤트 리스너
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('nav-item')) {
        const screen = e.target.dataset.screen;
        this.navigateTo(screen);
      }
    });
  }

  bindScreenEvents() {
    // 각 화면별 이벤트 바인딩
    this.bindOnboardingEvents();
    this.bindLoginEvents();
    this.bindLocationEvents();
    this.bindHomeEvents();
  }

  // === 화면 렌더링 함수들 ===

  renderOnboarding() {
    return `
      <div class="modal-overlay">
        <div class="modal-content fade-in p-6">
          <div class="text-center">
            <div class="mb-6">
              <i class="fas fa-users text-4xl text-blue-600 mb-4"></i>
              <h2 class="text-2xl font-bold text-gray-900 mb-2">ORee에 오신 것을 환영합니다!</h2>
              <p class="text-gray-600">단체예약을 쉽고 빠르게</p>
            </div>
            
            <div class="space-y-4 mb-6">
              <div class="flex items-center space-x-3">
                <i class="fas fa-map-marker-alt text-blue-600"></i>
                <span class="text-sm text-gray-700">내 주변 단체 가능한 업장 찾기</span>
              </div>
              <div class="flex items-center space-x-3">
                <i class="fas fa-calendar-check text-blue-600"></i>
                <span class="text-sm text-gray-700">실시간 예약 및 보증금 결제</span>
              </div>
              <div class="flex items-center space-x-3">
                <i class="fas fa-qrcode text-blue-600"></i>
                <span class="text-sm text-gray-700">QR코드로 간편 입장</span>
              </div>
            </div>
            
            <button class="btn btn-primary w-full" onclick="OReeApp.instance.completeOnboarding()">
              시작하기
            </button>
          </div>
        </div>
      </div>
    `;
  }

  renderLogin() {
    return `
      <div class="min-h-screen bg-gradient-to-br from-blue-50 to-white flex items-center justify-center p-4">
        <div class="card p-8 w-full max-w-md">
          <div class="text-center mb-8">
            <i class="fas fa-users text-4xl text-blue-600 mb-4"></i>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">ORee</h1>
            <p class="text-gray-600">단체예약 플랫폼</p>
          </div>
          
          <div class="space-y-4">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">이메일 또는 전화번호</label>
              <input type="text" class="input-field" placeholder="이메일 또는 전화번호를 입력하세요">
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-2">비밀번호</label>
              <input type="password" class="input-field" placeholder="비밀번호를 입력하세요">
            </div>
            
            <button class="btn btn-primary w-full" onclick="OReeApp.instance.handleLogin()">
              로그인
            </button>
            
            <div class="text-center">
              <span class="text-gray-600">계정이 없으신가요? </span>
              <button class="text-blue-600 font-medium" onclick="OReeApp.instance.toggleSignup()">
                회원가입
              </button>
            </div>
            
            <div class="pt-4 border-t border-gray-200">
              <button class="btn btn-secondary w-full mb-2">
                <i class="fab fa-google mr-2"></i>구글로 계속하기
              </button>
              <button class="btn btn-secondary w-full">
                <i class="fab fa-apple mr-2"></i>Apple로 계속하기
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderLocationPermission() {
    return `
      <div class="modal-overlay">
        <div class="modal-content fade-in p-6">
          <div class="text-center">
            <i class="fas fa-map-marker-alt text-4xl text-blue-600 mb-4"></i>
            <h2 class="text-xl font-bold text-gray-900 mb-4">위치 권한이 필요합니다</h2>
            <p class="text-gray-600 mb-6">내 주변 단체예약 가능한 업장을 찾기 위해 위치 권한을 허용해주세요.</p>
            
            <div class="space-y-3">
              <button class="btn btn-primary w-full" onclick="OReeApp.instance.requestLocation()">
                위치 권한 허용
              </button>
              <button class="btn btn-secondary w-full" onclick="OReeApp.instance.skipLocation()">
                나중에 하기
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderHome() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <div>
              <h1 class="text-xl font-bold text-gray-900">ORee</h1>
              <p class="text-sm text-gray-600"><i class="fas fa-map-marker-alt mr-1"></i>서울 강남구</p>
            </div>
            <div class="flex space-x-3">
              <button class="text-gray-600"><i class="fas fa-search text-xl"></i></button>
              <button class="text-gray-600"><i class="fas fa-bell text-xl"></i></button>
            </div>
          </div>
        </div>
        
        <!-- 지도/목록 전환 -->
        <div class="px-4 mb-4">
          <div class="flex bg-gray-100 rounded-button p-1">
            <button class="btn-toggle active flex-1 py-2 text-center rounded-button" data-view="map">
              <i class="fas fa-map mr-2"></i>지도
            </button>
            <button class="btn-toggle flex-1 py-2 text-center rounded-button" data-view="list">
              <i class="fas fa-list mr-2"></i>목록
            </button>
          </div>
        </div>
        
        <!-- 필터 -->
        <div class="px-4 mb-4">
          <div class="flex space-x-2 overflow-x-auto">
            <button class="btn btn-secondary whitespace-nowrap">전체</button>
            <button class="btn btn-secondary whitespace-nowrap">카페</button>
            <button class="btn btn-secondary whitespace-nowrap">레스토랑</button>
            <button class="btn btn-secondary whitespace-nowrap">펜션</button>
            <button class="btn btn-secondary whitespace-nowrap">스터디룸</button>
          </div>
        </div>
        
        <!-- 지도 영역 (임시) -->
        <div id="map-view" class="px-4 mb-4">
          <div class="bg-gray-200 rounded-button h-64 flex items-center justify-center">
            <p class="text-gray-600"><i class="fas fa-map mr-2"></i>지도가 여기에 표시됩니다</p>
          </div>
        </div>
        
        <!-- 업장 목록 -->
        <div class="px-4">
          <h3 class="text-lg font-semibold text-gray-900 mb-4">추천 업장</h3>
          <div class="space-y-4">
            ${this.renderStoreCard()}
            ${this.renderStoreCard()}
            ${this.renderStoreCard()}
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderStoreCard() {
    return `
      <div class="card p-4 cursor-pointer" onclick="OReeApp.instance.navigateTo('store-detail')">
        <div class="flex space-x-4">
          <div class="w-20 h-20 bg-gray-200 rounded-button flex-shrink-0">
            <i class="fas fa-image text-gray-400 w-full h-full flex items-center justify-center"></i>
          </div>
          <div class="flex-1">
            <div class="flex justify-between items-start mb-2">
              <h4 class="font-semibold text-gray-900">강남 프라이빗 카페</h4>
              <button class="text-gray-400 hover:text-red-500">
                <i class="far fa-heart"></i>
              </button>
            </div>
            <p class="text-sm text-gray-600 mb-2">20-30명 단체 가능 • 강남구 테헤란로</p>
            <div class="flex items-center justify-between">
              <div class="flex items-center space-x-2">
                <span class="text-yellow-500"><i class="fas fa-star"></i></span>
                <span class="text-sm text-gray-700">4.8 (128)</span>
              </div>
              <span class="text-blue-600 font-semibold">시간당 15만원</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderStoreDetail() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('home')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">업장 상세</h1>
            <button class="text-gray-600">
              <i class="fas fa-share text-xl"></i>
            </button>
          </div>
        </div>
        
        <!-- 이미지 갤러리 -->
        <div class="mb-4">
          <div class="h-64 bg-gray-200 relative">
            <div class="absolute inset-0 flex items-center justify-center">
              <p class="text-gray-600"><i class="fas fa-image mr-2"></i>업장 이미지</p>
            </div>
            <button class="absolute top-4 right-4 bg-black bg-opacity-50 text-white px-2 py-1 rounded-button text-sm">
              1 / 8
            </button>
          </div>
        </div>
        
        <!-- 업장 정보 -->
        <div class="px-4 mb-6">
          <div class="flex justify-between items-start mb-4">
            <div>
              <h2 class="text-2xl font-bold text-gray-900 mb-2">강남 프라이빗 카페</h2>
              <div class="flex items-center space-x-4">
                <div class="flex items-center space-x-1">
                  <span class="text-yellow-500"><i class="fas fa-star"></i></span>
                  <span class="font-semibold">4.8</span>
                  <span class="text-gray-600">(128)</span>
                </div>
                <span class="text-gray-600">20-30명 가능</span>
              </div>
            </div>
            <button class="text-red-500 text-2xl">
              <i class="far fa-heart"></i>
            </button>
          </div>
          
          <div class="space-y-4">
            <div>
              <h3 class="font-semibold text-gray-900 mb-2">위치</h3>
              <p class="text-gray-700"><i class="fas fa-map-marker-alt mr-2"></i>서울 강남구 테헤란로 123</p>
            </div>
            
            <div>
              <h3 class="font-semibold text-gray-900 mb-2">소개</h3>
              <p class="text-gray-700">깔끔하고 모던한 분위기의 프라이빗 카페입니다. 단체 모임, 회의, 파티 등 다양한 용도로 활용 가능합니다.</p>
            </div>
            
            <div>
              <h3 class="font-semibold text-gray-900 mb-2">편의시설</h3>
              <div class="flex flex-wrap gap-2">
                <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-button text-sm">WiFi</span>
                <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-button text-sm">프로젝터</span>
                <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-button text-sm">주차가능</span>
                <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-button text-sm">음향시설</span>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 예약 버튼 -->
        <div class="fixed bottom-20 left-0 right-0 p-4 bg-white border-t border-gray-200">
          <div class="flex items-center justify-between mb-3">
            <div>
              <span class="text-2xl font-bold text-gray-900">시간당 15만원</span>
              <p class="text-sm text-gray-600">최소 2시간</p>
            </div>
          </div>
          <button class="btn btn-primary w-full" onclick="OReeApp.instance.navigateTo('reservation')">
            예약하기
          </button>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderReservation() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('store-detail')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">예약하기</h1>
            <div></div>
          </div>
        </div>
        
        <div class="p-4 space-y-6">
          <!-- 날짜 선택 -->
          <div>
            <h3 class="text-lg font-semibold text-gray-900 mb-4">날짜 선택</h3>
            <div class="card p-4">
              <div class="grid grid-cols-7 gap-1 text-center text-sm">
                <div class="p-2 text-gray-500">일</div>
                <div class="p-2 text-gray-500">월</div>
                <div class="p-2 text-gray-500">화</div>
                <div class="p-2 text-gray-500">수</div>
                <div class="p-2 text-gray-500">목</div>
                <div class="p-2 text-gray-500">금</div>
                <div class="p-2 text-gray-500">토</div>
                ${this.renderCalendar()}
              </div>
            </div>
          </div>
          
          <!-- 시간 선택 -->
          <div>
            <h3 class="text-lg font-semibold text-gray-900 mb-4">시간 선택</h3>
            <div class="grid grid-cols-3 gap-2">
              <button class="btn btn-secondary">10:00</button>
              <button class="btn btn-primary">14:00</button>
              <button class="btn btn-secondary">16:00</button>
              <button class="btn btn-secondary">18:00</button>
              <button class="btn btn-secondary">20:00</button>
            </div>
            <p class="text-sm text-gray-600 mt-2">최소 2시간 이용</p>
          </div>
          
          <!-- 인원 선택 -->
          <div>
            <h3 class="text-lg font-semibold text-gray-900 mb-4">인원 선택</h3>
            <div class="card p-4">
              <div class="flex justify-between items-center">
                <span class="text-gray-700">인원</span>
                <div class="flex items-center space-x-4">
                  <button class="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">-</button>
                  <span class="font-semibold">25명</span>
                  <button class="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center">+</button>
                </div>
              </div>
            </div>
          </div>
          
          <!-- 보증금 정보 -->
          <div>
            <h3 class="text-lg font-semibold text-gray-900 mb-4">결제 정보</h3>
            <div class="card p-4 space-y-3">
              <div class="flex justify-between">
                <span class="text-gray-700">이용 시간</span>
                <span class="font-semibold">2시간</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-700">시간당 요금</span>
                <span class="font-semibold">150,000원</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-700">총 요금</span>
                <span class="font-semibold">300,000원</span>
              </div>
              <hr>
              <div class="flex justify-between">
                <span class="text-gray-700">보증금 (30%)</span>
                <span class="font-semibold text-blue-600">90,000원</span>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 예약 확정 버튼 -->
        <div class="fixed bottom-20 left-0 right-0 p-4 bg-white border-t border-gray-200">
          <button class="btn btn-primary w-full" onclick="OReeApp.instance.navigateTo('payment')">
            보증금 결제하기 (90,000원)
          </button>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderPayment() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('reservation')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">결제</h1>
            <div></div>
          </div>
        </div>
        
        <div class="p-4 space-y-6">
          <!-- 예약 정보 확인 -->
          <div class="card p-4">
            <h3 class="font-semibold text-gray-900 mb-4">예약 정보</h3>
            <div class="space-y-2 text-sm">
              <div class="flex justify-between">
                <span class="text-gray-600">업장</span>
                <span>강남 프라이빗 카페</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">날짜</span>
                <span>2024년 3월 15일 (금)</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">시간</span>
                <span>14:00 - 16:00 (2시간)</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">인원</span>
                <span>25명</span>
              </div>
            </div>
          </div>
          
          <!-- 결제 방법 -->
          <div>
            <h3 class="text-lg font-semibold text-gray-900 mb-4">결제 방법</h3>
            <div class="space-y-2">
              <label class="card p-4 flex items-center space-x-3 cursor-pointer">
                <input type="radio" name="payment" value="card" class="text-blue-600" checked>
                <i class="fas fa-credit-card text-blue-600"></i>
                <span>신용/체크카드</span>
              </label>
              <label class="card p-4 flex items-center space-x-3 cursor-pointer">
                <input type="radio" name="payment" value="account" class="text-blue-600">
                <i class="fas fa-university text-blue-600"></i>
                <span>계좌이체</span>
              </label>
              <label class="card p-4 flex items-center space-x-3 cursor-pointer">
                <input type="radio" name="payment" value="kakao" class="text-blue-600">
                <i class="fas fa-comment text-yellow-500"></i>
                <span>카카오페이</span>
              </label>
            </div>
          </div>
          
          <!-- 결제 금액 -->
          <div class="card p-4">
            <div class="space-y-2">
              <div class="flex justify-between text-sm">
                <span class="text-gray-600">총 이용료</span>
                <span>300,000원</span>
              </div>
              <div class="flex justify-between text-sm">
                <span class="text-gray-600">현재 결제 (보증금)</span>
                <span class="text-blue-600">90,000원</span>
              </div>
              <div class="flex justify-between text-sm">
                <span class="text-gray-600">현장 결제</span>
                <span>210,000원</span>
              </div>
              <hr class="my-2">
              <div class="flex justify-between text-lg font-bold">
                <span>결제 금액</span>
                <span class="text-blue-600">90,000원</span>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 결제 버튼 -->
        <div class="fixed bottom-20 left-0 right-0 p-4 bg-white border-t border-gray-200">
          <div class="mb-3">
            <label class="flex items-center space-x-2">
              <input type="checkbox" class="text-blue-600 rounded">
              <span class="text-sm text-gray-600">예약 조건 및 취소 정책에 동의합니다</span>
            </label>
          </div>
          <button class="btn btn-primary w-full" onclick="OReeApp.instance.processPayment()">
            90,000원 결제하기
          </button>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderQR() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('my')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">입장 QR코드</h1>
            <div></div>
          </div>
        </div>
        
        <div class="p-4 text-center">
          <!-- QR 코드 -->
          <div class="mb-6">
            <div class="w-64 h-64 mx-auto bg-white border-2 border-gray-200 rounded-button flex items-center justify-center mb-4">
              <div class="w-48 h-48 bg-gray-900 rounded grid grid-cols-8 gap-1 p-2">
                <!-- QR 패턴 시뮬레이션 -->
                ${Array(64).fill(0).map((_, i) => 
                  `<div class="bg-${Math.random() > 0.5 ? 'white' : 'gray-900'} rounded-sm"></div>`
                ).join('')}
              </div>
            </div>
            <p class="text-sm text-gray-600">업장에서 이 QR코드를 제시해주세요</p>
          </div>
          
          <!-- 예약 정보 -->
          <div class="card p-4 mb-6">
            <h3 class="font-semibold text-gray-900 mb-4">예약 정보</h3>
            <div class="space-y-3 text-left">
              <div class="flex justify-between">
                <span class="text-gray-600">업장</span>
                <span class="font-medium">강남 프라이빗 카페</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">날짜</span>
                <span class="font-medium">2024년 3월 15일 (금)</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">시간</span>
                <span class="font-medium">14:00 - 16:00</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">인원</span>
                <span class="font-medium">25명</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">예약번호</span>
                <span class="font-medium text-blue-600">OR240315001</span>
              </div>
            </div>
          </div>
          
          <!-- 안내 사항 -->
          <div class="bg-blue-50 rounded-button p-4 text-left">
            <h4 class="font-semibold text-blue-900 mb-2">
              <i class="fas fa-info-circle mr-2"></i>이용 안내
            </h4>
            <ul class="text-sm text-blue-800 space-y-1">
              <li>• 예약 시간 10분 전까지 도착해주세요</li>
              <li>• 현장에서 잔금 210,000원을 결제해주세요</li>
              <li>• 이용 시간 연장은 현장에서 문의 가능합니다</li>
              <li>• 취소는 24시간 전까지만 가능합니다</li>
            </ul>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderWishlist() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <h1 class="text-xl font-semibold text-gray-900">찜한 업장</h1>
            <button class="text-gray-600">
              <i class="fas fa-ellipsis-h text-xl"></i>
            </button>
          </div>
        </div>
        
        <div class="p-4">
          <div class="space-y-4">
            ${this.renderWishlistItem()}
            ${this.renderWishlistItem()}
            ${this.renderWishlistItem()}
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderWishlistItem() {
    return `
      <div class="card p-4">
        <div class="flex space-x-4">
          <div class="w-20 h-20 bg-gray-200 rounded-button flex-shrink-0">
            <i class="fas fa-image text-gray-400 w-full h-full flex items-center justify-center"></i>
          </div>
          <div class="flex-1">
            <div class="flex justify-between items-start mb-2">
              <h4 class="font-semibold text-gray-900">강남 프라이빗 카페</h4>
              <button class="text-red-500">
                <i class="fas fa-heart"></i>
              </button>
            </div>
            <p class="text-sm text-gray-600 mb-2">20-30명 단체 가능 • 강남구 테헤란로</p>
            <div class="flex items-center justify-between">
              <div class="flex items-center space-x-2">
                <span class="text-yellow-500"><i class="fas fa-star"></i></span>
                <span class="text-sm text-gray-700">4.8 (128)</span>
              </div>
              <button class="btn btn-primary btn-sm" onclick="OReeApp.instance.navigateTo('store-detail')">
                예약하기
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderMy() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <h1 class="text-xl font-semibold text-gray-900">마이페이지</h1>
            <button class="text-gray-600">
              <i class="fas fa-cog text-xl"></i>
            </button>
          </div>
        </div>
        
        <div class="p-4 space-y-6">
          <!-- 프로필 -->
          <div class="card p-4">
            <div class="flex items-center space-x-4">
              <div class="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
                <i class="fas fa-user text-white text-xl"></i>
              </div>
              <div class="flex-1">
                <h3 class="text-lg font-semibold text-gray-900">김사용자</h3>
                <p class="text-sm text-gray-600">user@example.com</p>
                <div class="flex items-center space-x-2 mt-1">
                  <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">VIP</span>
                  <span class="text-xs text-gray-600">다음 등급까지 3회</span>
                </div>
              </div>
              <button class="text-gray-400">
                <i class="fas fa-chevron-right"></i>
              </button>
            </div>
          </div>
          
          <!-- 포인트 & 쿠폰 -->
          <div class="grid grid-cols-2 gap-4">
            <div class="card p-4 text-center">
              <div class="text-2xl font-bold text-blue-600 mb-1">12,500</div>
              <div class="text-sm text-gray-600">적립 포인트</div>
            </div>
            <div class="card p-4 text-center">
              <div class="text-2xl font-bold text-green-600 mb-1">3</div>
              <div class="text-sm text-gray-600">보유 쿠폰</div>
            </div>
          </div>
          
          <!-- 메뉴 -->
          <div class="space-y-2">
            <button class="w-full flex items-center justify-between p-4 bg-white rounded-button border border-gray-200 hover:bg-gray-50">
              <div class="flex items-center space-x-3">
                <i class="fas fa-calendar-check text-blue-600"></i>
                <span class="text-gray-900">예약 내역</span>
              </div>
              <i class="fas fa-chevron-right text-gray-400"></i>
            </button>
            
            <button class="w-full flex items-center justify-between p-4 bg-white rounded-button border border-gray-200 hover:bg-gray-50" onclick="OReeApp.instance.navigateTo('qr')">
              <div class="flex items-center space-x-3">
                <i class="fas fa-qrcode text-blue-600"></i>
                <span class="text-gray-900">입장 QR코드</span>
              </div>
              <i class="fas fa-chevron-right text-gray-400"></i>
            </button>
            
            <button class="w-full flex items-center justify-between p-4 bg-white rounded-button border border-gray-200 hover:bg-gray-50">
              <div class="flex items-center space-x-3">
                <i class="fas fa-coins text-blue-600"></i>
                <span class="text-gray-900">적립금 관리</span>
              </div>
              <i class="fas fa-chevron-right text-gray-400"></i>
            </button>
            
            <button class="w-full flex items-center justify-between p-4 bg-white rounded-button border border-gray-200 hover:bg-gray-50">
              <div class="flex items-center space-x-3">
                <i class="fas fa-crown text-blue-600"></i>
                <span class="text-gray-900">멤버십</span>
              </div>
              <i class="fas fa-chevron-right text-gray-400"></i>
            </button>
            
            <button class="w-full flex items-center justify-between p-4 bg-white rounded-button border border-gray-200 hover:bg-gray-50">
              <div class="flex items-center space-x-3">
                <i class="fas fa-money-bill-wave text-blue-600"></i>
                <span class="text-gray-900">출금 신청</span>
              </div>
              <i class="fas fa-chevron-right text-gray-400"></i>
            </button>
            
            <button class="w-full flex items-center justify-between p-4 bg-white rounded-button border border-gray-200 hover:bg-gray-50" onclick="OReeApp.instance.navigateTo('dev-notes')">
              <div class="flex items-center space-x-3">
                <i class="fas fa-code text-blue-600"></i>
                <span class="text-gray-900">개발자 노트</span>
              </div>
              <i class="fas fa-chevron-right text-gray-400"></i>
            </button>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderDevNotes() {
    return `
      <div class="pb-20">
        <!-- 헤더 -->
        <div class="header p-4">
          <div class="flex justify-between items-center">
            <button onclick="OReeApp.instance.navigateTo('my')" class="text-gray-600">
              <i class="fas fa-arrow-left text-xl"></i>
            </button>
            <h1 class="text-lg font-semibold">개발자 노트</h1>
            <div></div>
          </div>
        </div>
        
        <div class="p-4 space-y-6">
          <!-- 프로젝트 정보 -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-info-circle text-blue-600 mr-2"></i>프로젝트 정보
            </h3>
            <div class="space-y-2 text-sm">
              <div class="flex justify-between">
                <span class="text-gray-600">프로젝트명</span>
                <span class="font-medium">ORee – 단체예약 MVP</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">버전</span>
                <span class="font-medium">1.0.0</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">기술 스택</span>
                <span class="font-medium">Hono + Tailwind CSS</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">배포 플랫폼</span>
                <span class="font-medium">Cloudflare Pages</span>
              </div>
            </div>
          </div>
          
          <!-- 완료된 화면 -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-check-circle text-green-600 mr-2"></i>구현된 화면 (11개)
            </h3>
            <div class="grid grid-cols-1 gap-2 text-sm">
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>1. 온보딩 (팝업 슬라이드)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>2. 로그인/회원가입</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>3. 위치권한 요청 팝업</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>4. 홈 (지도/목록 전환)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>5. 업장상세 (원페이지)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>6. 예약 (달력/시간/인원/보증금)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>7. 결제 (Stub)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>8. QR 생성</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>9. 찜</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>10. 마이페이지</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>11. 개발자 노트 (현재 화면)</span>
              </div>
            </div>
          </div>
          
          <!-- 적용된 스타일 -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-palette text-purple-600 mr-2"></i>적용된 스타일
            </h3>
            <div class="space-y-2 text-sm">
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>라이트 모드 고정</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>시스템 폰트 사용</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>모든 버튼 12px 라운드 모서리</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>Tailwind CSS 기반 컴포넌트</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-check text-green-600"></i>
                <span>반응형 모바일 우선 디자인</span>
              </div>
            </div>
          </div>
          
          <!-- 다음 단계 -->
          <div class="card p-4">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">
              <i class="fas fa-road text-orange-600 mr-2"></i>다음 개발 단계
            </h3>
            <div class="space-y-2 text-sm">
              <div class="flex items-center space-x-2">
                <i class="fas fa-circle text-orange-500"></i>
                <span>실제 지도 API 연동 (카카오맵/네이버맵)</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-circle text-orange-500"></i>
                <span>실제 결제 시스템 연동</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-circle text-orange-500"></i>
                <span>사용자 인증 시스템 구축</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-circle text-orange-500"></i>
                <span>업장 데이터베이스 연동</span>
              </div>
              <div class="flex items-center space-x-2">
                <i class="fas fa-circle text-orange-500"></i>
                <span>예약 시스템 백엔드 구축</span>
              </div>
            </div>
          </div>
        </div>
        
        ${this.renderBottomNav()}
      </div>
    `;
  }

  renderBottomNav() {
    const navItems = [
      { screen: 'home', icon: 'fas fa-home', label: '홈' },
      { screen: 'wishlist', icon: 'fas fa-heart', label: '찜' },
      { screen: 'reservation', icon: 'fas fa-calendar-plus', label: '예약' },
      { screen: 'my', icon: 'fas fa-user', label: '마이' }
    ];
    
    return `
      <div class="bottom-nav p-2">
        <div class="flex justify-around">
          ${navItems.map(item => `
            <button class="nav-item flex flex-col items-center py-2 px-3 ${this.currentScreen === item.screen ? 'text-blue-600' : 'text-gray-600'}" data-screen="${item.screen}">
              <i class="${item.icon} text-lg mb-1"></i>
              <span class="text-xs">${item.label}</span>
            </button>
          `).join('')}
        </div>
      </div>
    `;
  }

  // 유틸리티 함수들
  renderCalendar() {
    let calendar = '';
    const today = new Date();
    const month = today.getMonth();
    const year = today.getFullYear();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    // 빈 칸
    for (let i = 0; i < firstDay; i++) {
      calendar += '<div class="p-2"></div>';
    }
    
    // 날짜
    for (let day = 1; day <= daysInMonth; day++) {
      const isToday = day === today.getDate();
      const isSelected = day === 15; // 예시로 15일 선택
      calendar += `
        <div class="p-2 cursor-pointer rounded ${isSelected ? 'bg-blue-600 text-white' : isToday ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'}">
          ${day}
        </div>
      `;
    }
    
    return calendar;
  }

  // === 이벤트 핸들러들 ===

  bindOnboardingEvents() {
    // 온보딩 관련 이벤트
  }

  bindLoginEvents() {
    // 로그인 관련 이벤트
  }

  bindLocationEvents() {
    // 위치 권한 관련 이벤트
  }

  bindHomeEvents() {
    // 홈 화면 이벤트 (지도/목록 전환 등)
    const toggleButtons = document.querySelectorAll('.btn-toggle');
    toggleButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        toggleButtons.forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
      });
    });
  }

  // === 액션 함수들 ===

  completeOnboarding() {
    localStorage.setItem('onboarding_completed', 'true');
    this.showOnboarding = false;
    this.navigateTo('login');
  }

  handleLogin() {
    // 로그인 처리 (임시)
    this.user = { name: '김사용자', email: 'user@example.com' };
    this.navigateTo('location-permission');
  }

  toggleSignup() {
    alert('회원가입 화면으로 전환 (구현 예정)');
  }

  requestLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          console.log('위치 허용:', position);
          this.navigateTo('home');
        },
        (error) => {
          console.log('위치 거부:', error);
          this.navigateTo('home'); // 거부해도 홈으로 이동
        }
      );
    } else {
      this.navigateTo('home');
    }
  }

  skipLocation() {
    this.navigateTo('home');
  }

  processPayment() {
    // 결제 처리 시뮬레이션
    const button = event.target;
    button.innerHTML = '<div class="spinner mr-2"></div>결제 처리중...';
    button.disabled = true;
    
    setTimeout(() => {
      alert('결제가 완료되었습니다!');
      this.navigateTo('qr');
    }, 2000);
  }
}

// 앱 초기화
document.addEventListener('DOMContentLoaded', () => {
  OReeApp.instance = new OReeApp();
});

// CSS 스타일 동적 추가
const style = document.createElement('style');
style.textContent = `
  .btn-toggle.active {
    background-color: #2563eb;
    color: white;
  }
  .btn-sm {
    padding: 0.375rem 0.75rem;
    font-size: 0.875rem;
  }
`;
document.head.appendChild(style);