import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

// Enable CORS for all routes
app.use('*', cors({
  origin: ['*'],
  allowHeaders: ['Content-Type', 'Authorization'],
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
}))

// API Routes (향후 확장용)
app.get('/api/health', (c) => {
  return c.json({ status: 'ok', service: 'ORee MVP' })
})

// Serve static files - MUST be before catch-all route
app.use('/static/*', serveStatic({ root: './public' }))

// Main SPA route
app.get('/', (c) => {
  return c.html(`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ORee – 단체예약 MVP</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <link href="/static/style.css" rel="stylesheet">
</head>
<body class="bg-white text-gray-900 font-system antialiased">
    <div id="app">
        <!-- ORee MVP 앱이 여기에 로드됩니다 -->
    </div>
    
    <script>
      // Tailwind 커스텀 설정
      tailwind.config = {
        theme: {
          extend: {
            fontFamily: {
              'system': ['-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'system-ui', 'sans-serif']
            },
            borderRadius: {
              'DEFAULT': '12px',
              'button': '12px'
            }
          }
        }
      }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
    <script src="/static/app_v2.js"></script>
</body>
</html>`)
})

// 모든 다른 경로는 SPA로 처리 - MUST be last
app.get('*', (c) => {
  return c.redirect('/')
})

export default app
